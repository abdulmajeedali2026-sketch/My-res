export type Language = 'ar' | 'en';

export interface Translations {
  appName: string;
  appSubtitle: string;
  toggleLang: string;
  dir: 'rtl' | 'ltr';

  // Common UI labels
  common: {
    save: string;
    cancel: string;
    confirm: string;
    close: string;
    delete: string;
    edit: string;
    search: string;
    all: string;
    filter: string;
    loading: string;
    success: string;
    error: string;
  };

  // Navigation
  nav: {
    pos: string;
    sales: string;
    purchases: string;
    inventory: string;
    accounting: string;
    customers: string;
    suppliers: string;
    employees: string;
    reports: string;
    settings: string;
    architecture: string;
    kds: string;
    activeBadge: string;
  };

  // Header
  header: {
    tillBalance: string;
    openKds: string;
    architectureHub: string;
    clockIn: string;
    clockOut: string;
    clockedIn: string;
    clockedOut: string;
    staffRole: string;
    lowStockWarning: string;
    openRegister: string;
    systemOnline: string;
    backendActive: string;
  };

  // POS
  pos: {
    dineIn: string;
    takeaway: string;
    delivery: string;
    searchPlaceholder: string;
    allDishes: string;
    starters: string;
    steaks: string;
    pizzaPasta: string;
    seafood: string;
    desserts: string;
    beverages: string;
    orderTicket: string;
    ticketNum: string;
    emptyCartTitle: string;
    emptyCartSubtitle: string;
    subtotal: string;
    tax: string;
    serviceCharge: string;
    discount: string;
    total: string;
    tableNum: string;
    selectGuestTable: string;
    guests: string;
    available: string;
    occupied: string;
    reserved: string;
    payAndPrint: string;
    sendToKitchen: string;
    holdOrder: string;
    clearCart: string;
    paymentModalTitle: string;
    amountToPay: string;
    selectPaymentMethod: string;
    cash: string;
    card: string;
    mobilePay: string;
    customerCredit: string;
    tenderedAmount: string;
    changeDue: string;
    confirmPayment: string;
    cancel: string;
    receiptPreview: string;
    printReceipt: string;
    orderSuccess: string;
    orderSentKds: string;
  };

  // Sales
  sales: {
    title: string;
    subtitle: string;
    totalSales: string;
    ordersCount: string;
    avgTicket: string;
    filterAll: string;
    filterCompleted: string;
    filterPending: string;
    filterVoided: string;
    orderNumber: string;
    type: string;
    table: string;
    itemsCount: string;
    total: string;
    payment: string;
    status: string;
    time: string;
    actions: string;
    viewDetails: string;
    printReceipt: string;
    unpaid: string;
    paid: string;
    refunded: string;
    statusPending: string;
    statusPreparing: string;
    statusReady: string;
    statusServed: string;
    statusCompleted: string;
    statusVoided: string;
  };

  // Purchases
  purchases: {
    title: string;
    subtitle: string;
    createPO: string;
    totalPurchases: string;
    pendingDeliveries: string;
    poNumber: string;
    supplier: string;
    date: string;
    totalAmount: string;
    status: string;
    receiveStock: string;
    draft: string;
    ordered: string;
    received: string;
    cancelled: string;
    newPurchaseOrder: string;
    selectSupplier: string;
    addItem: string;
    quantity: string;
    unitPrice: string;
    lineTotal: string;
    savePO: string;
  };

  // Inventory
  inventory: {
    title: string;
    subtitle: string;
    rawIngredients: string;
    recipeBOM: string;
    totalValuation: string;
    lowStockItems: string;
    code: string;
    ingredientName: string;
    category: string;
    currentStock: string;
    unit: string;
    reorderLevel: string;
    costPerUnit: string;
    valuation: string;
    status: string;
    adjustStock: string;
    newStock: string;
    reason: string;
    saveAdjustment: string;
    bomDescription: string;
    dishName: string;
    portionCost: string;
    sellingPrice: string;
    marginPercent: string;
    ingredientsUsed: string;
    bomRecipes: string;
    transactions: string;
    ingredientCode: string;
    unitCost: string;
    addIngredient: string;
    lowStockAlert: string;
    rawMaterials: string;
  };

  // Accounting
  accounting: {
    title: string;
    subtitle: string;
    chartOfAccounts: string;
    journalEntries: string;
    trialBalance: string;
    profitAndLoss: string;
    pnl: string;
    balanceSheet: string;
    code: string;
    accountName: string;
    type: string;
    subCategory: string;
    balance: string;
    totalDebits: string;
    totalCredits: string;
    variance: string;
    balanced: string;
    unbalanced: string;
    entryNumber: string;
    date: string;
    description: string;
    lines: string;
    recordExpense: string;
    expenseVoucher: string;
    expenseAccount: string;
    amount: string;
    paidFrom: string;
    notes: string;
  };

  // Customers
  customers: {
    title: string;
    subtitle: string;
    addCustomer: string;
    totalCustomers: string;
    vipMembers: string;
    totalPoints: string;
    name: string;
    phone: string;
    email: string;
    tier: string;
    loyaltyPoints: string;
    visits: string;
    totalSpent: string;
    creditBalance: string;
    newCustomerModal: string;
    saveCustomer: string;
  };

  // Suppliers
  suppliers: {
    title: string;
    subtitle: string;
    addSupplier: string;
    totalPayables: string;
    activeSuppliers: string;
    supplierName: string;
    contactPerson: string;
    phone: string;
    category: string;
    paymentTerms: string;
    balanceOwed: string;
    makePayment: string;
    paymentModal: string;
    payAmount: string;
    confirmPayment: string;
  };

  // Employees
  employees: {
    title: string;
    subtitle: string;
    addEmployee: string;
    activeOnShift: string;
    todayShiftSales: string;
    staffName: string;
    role: string;
    hourlyWage: string;
    status: string;
    clockIn: string;
    clockOut: string;
    tablesServed: string;
    todaySales: string;
    newEmployeeModal: string;
    activeStaff: string;
    clockedIn: string;
    totalStaff: string;
    clockedOut: string;
    salesHandled: string;
    hourlyRate: string;
    pin: string;
  };

  // Reports
  reports: {
    title: string;
    subtitle: string;
    todayRevenue: string;
    totalOrders: string;
    netProfit: string;
    foodCostPercent: string;
    salesByCategory: string;
    hourlyDistribution: string;
    topSellingItems: string;
    category: string;
    salesVolume: string;
    revenue: string;
    staffPerformance: string;
    today: string;
    thisWeek: string;
    thisMonth: string;
    hourlySales: string;
    topDishes: string;
    serverPerformance: string;
  };

  // Settings
  settings: {
    title: string;
    subtitle: string;
    businessIdentity: string;
    restaurantProfile: string;
    restaurantName: string;
    tagline: string;
    address: string;
    phone: string;
    vatNumber: string;
    taxNumber: string;
    taxesAndCharges: string;
    taxAndServices: string;
    vatRate: string;
    taxRate: string;
    serviceCharge: string;
    currencySymbol: string;
    receiptCustomization: string;
    receiptFooter: string;
    systemLanguage: string;
    language: string;
    saveSettings: string;
    resetDatabase: string;
    resetData: string;
    resetWarning: string;
    confirmReset: string;
    resetSuccess: string;
    saveSuccess: string;
  };

  // Architecture
  architecture: {
    title: string;
    subtitle: string;
    backendTab: string;
    databaseTab: string;
    filesList: string;
    copyCode: string;
    copied: string;
    sqlConsole: string;
    sqlConsoleSubtitle: string;
    executeSql: string;
    quickQueries: string;
  };

  // KDS Modal
  kds: {
    title: string;
    subtitle: string;
    activeTickets: string;
    table: string;
    elapsed: string;
    items: string;
    markCooking: string;
    markReady: string;
    completed: string;
    soundAlert: string;
    allClear: string;
  };

  // Register Modal
  register: {
    title: string;
    subtitle: string;
    openingFloat: string;
    cashSales: string;
    paidOut: string;
    expectedCash: string;
    actualCount: string;
    variance: string;
    balanced: string;
    overage: string;
    shortage: string;
    reconcileNotes: string;
    confirmReconcile: string;
    cancel: string;
  };
}

export const translations: Record<Language, Translations> = {
  ar: {
    appName: 'RestaurantERP',
    appSubtitle: 'نظام إدارة المطاعم المتكامل ونقاط البيع السحابية',
    toggleLang: 'English',
    dir: 'rtl',

    common: {
      save: 'حفظ',
      cancel: 'إلغاء',
      confirm: 'تأكيد',
      close: 'إغلاق',
      delete: 'حذف',
      edit: 'تعديل',
      search: 'بحث...',
      all: 'الكل',
      filter: 'تصفية',
      loading: 'جاري التحميل...',
      success: 'تمت العملية بنجاح',
      error: 'حدث خطأ',
    },

    nav: {
      pos: 'نقطة البيع (الكاشير)',
      sales: 'المبيعات والطلبات',
      purchases: 'المشتريات والتوريد',
      inventory: 'المخزون والمقادير (BOM)',
      accounting: 'المحاسبة والشجرة المالية',
      customers: 'العملاء وبرامج الولاء',
      suppliers: 'الموردين والحسابات الدائنة',
      employees: 'الموظفين وسجل الورديات',
      reports: 'التقارير ومؤشرات الأداء',
      settings: 'الإعدادات العامة والضريبة',
      architecture: 'معمارية ASP.NET & SQL',
      kds: 'شاشة المطبخ (KDS)',
      activeBadge: 'نشط',
    },

    header: {
      tillBalance: 'رصيد الصندوق',
      openKds: 'شاشة المطبخ KDS',
      architectureHub: 'كود C# و T-SQL',
      clockIn: 'تسجيل دخول',
      clockOut: 'تسجيل خروج',
      clockedIn: 'على رأس العمل',
      clockedOut: 'غير متواجد',
      staffRole: 'الموظف الحالي',
      lowStockWarning: 'تنبيه نقص في المخزون',
      openRegister: 'إغلاق وتسوية الدرج',
      systemOnline: 'النظام متصل',
      backendActive: 'ASP.NET Core Web API',
    },

    pos: {
      dineIn: 'تناول بالصالة',
      takeaway: 'طلب سفري',
      delivery: 'طلب توصيل',
      searchPlaceholder: 'ابحث باسم الوجبة أو الكود (مثال: برجر، ستيك، بيتزا)...',
      allDishes: 'جميع الأصناف',
      starters: 'المقبلات',
      steaks: 'المشاوي والستيك',
      pizzaPasta: 'البيتزا والباستا',
      seafood: 'المأكولات البحرية',
      desserts: 'الحلويات',
      beverages: 'المشروبات',
      orderTicket: 'فاتورة الطلب الحالية',
      ticketNum: 'طلب رقم',
      emptyCartTitle: 'السلة فارغة حالياً',
      emptyCartSubtitle: 'اضغط على الأصناف من القائمة لإضافتها إلى الفاتورة',
      subtotal: 'المجموع قبل الضريبة',
      tax: 'ضريبة القيمة المضافة',
      serviceCharge: 'رسوم الخدمة',
      discount: 'الخصم المطبق',
      total: 'الإجمالي المستحق',
      tableNum: 'رقم الطاولة',
      selectGuestTable: 'تحديد طاولة الصالة',
      guests: 'عدد الضيوف',
      available: 'متاحة',
      occupied: 'مشغولة',
      reserved: 'محجوزة',
      payAndPrint: 'الدفع وإصدار الفاتورة',
      sendToKitchen: 'إرسال للمطبخ (KDS)',
      holdOrder: 'تعليق الطلب',
      clearCart: 'إفراغ الفاتورة',
      paymentModalTitle: 'نافذة التحصيل وإتمام الدفع',
      amountToPay: 'المبلغ المطلوب سداده',
      selectPaymentMethod: 'اختر طريقة الدفع',
      cash: 'نقدي (كاش)',
      card: 'بطاقة ائتمانية / مدى',
      mobilePay: 'دفع إلكتروني (Apple Pay / STC)',
      customerCredit: 'آجل / حساب العميل',
      tenderedAmount: 'المبلغ المستلم من العميل',
      changeDue: 'المتبقي للعميل (الفكة)',
      confirmPayment: 'تأكيد التحصيل وطباعة الإيصال',
      cancel: 'إلغاء',
      receiptPreview: 'معاينة الفاتورة الضريبية المبسطة',
      printReceipt: 'طباعة الفاتورة الفورية',
      orderSuccess: 'تم إتمام الدفع بنجاح وتحديث قيود اليومية المحاسبية واستنزاف المخزون.',
      orderSentKds: 'تم إرسال الطلب لشاشة المطبخ KDS بنجاح.',
    },

    sales: {
      title: 'سجل المبيعات والطلبات',
      subtitle: 'متابعة الفواتير المكتملة والمعلقة وحالات التسليم مع الربط المحاسبي التلقائي',
      totalSales: 'إجمالي المبيعات اليومية',
      ordersCount: 'عدد الفواتير المنفذة',
      avgTicket: 'متوسط قيمة الفاتورة',
      filterAll: 'كافة الحالات',
      filterCompleted: 'المكتملة والمدفوعة',
      filterPending: 'قيد التحضير والانتظار',
      filterVoided: 'الملغاة',
      orderNumber: 'رقم الفاتورة',
      type: 'نوع الطلب',
      table: 'الطاولة / العميل',
      itemsCount: 'الأصناف',
      total: 'المبلغ الإجمالي',
      payment: 'طريقة السداد',
      status: 'حالة الطلب',
      time: 'التوقيت',
      actions: 'خيارات',
      viewDetails: 'عرض التفاصيل',
      printReceipt: 'إعادة طباعة',
      unpaid: 'غير مدفوع',
      paid: 'مسدد بالكامل',
      refunded: 'مسترجع',
      statusPending: 'بانتظار التحضير',
      statusPreparing: 'جاري الطهي',
      statusReady: 'جاهز للاستلام',
      statusServed: 'تم التقديم',
      statusCompleted: 'مكتمل ومغلق',
      statusVoided: 'ملغي',
    },

    purchases: {
      title: 'إدارة المشتريات والتوريد',
      subtitle: 'أوامر الشراء واستلام بضائع الموردين وتحديث تكلفة وأرصدة المخزون تلقائياً',
      createPO: 'إنشاء أمر شراء جديد',
      totalPurchases: 'إجمالي المشتريات الشهرية',
      pendingDeliveries: 'شحنات قيد الاستلام',
      poNumber: 'رقم أمر الشراء',
      supplier: 'المورد التجاري',
      date: 'تاريخ الإنشاء',
      totalAmount: 'القيمة الإجمالية',
      status: 'حالة أمر الشراء',
      receiveStock: 'استلام البضاعة وإدخال المخزن',
      draft: 'مسودة',
      ordered: 'تم إرسال الطلب',
      received: 'تم الاستلام وإيداع المخزن',
      cancelled: 'ملغي',
      newPurchaseOrder: 'إصدار أمر شراء رسمي',
      selectSupplier: 'اختر المورد',
      addItem: 'إضافة مادة أولية',
      quantity: 'الكمية المطلوبة',
      unitPrice: 'سعر الوحدة',
      lineTotal: 'الإجمالي',
      savePO: 'حفظ أمر الشراء',
    },

    inventory: {
      title: 'إدارة المخزون والمقادير (Recipe BOM)',
      subtitle: 'تتبع كميات المواد الأولية، تكاليف الوصفات واستنزاف المخزون اللحظي مع كل عملية بيع',
      rawIngredients: 'المواد الأولية والمستودع',
      recipeBOM: 'مقادير الأطباق (BOM)',
      totalValuation: 'القيمة الإجمالية للمخزون',
      lowStockItems: 'أصناف بلغت حد إعادة الطلب',
      code: 'كود المادة',
      ingredientName: 'اسم المادة الأولية',
      category: 'التصنيف المخزني',
      currentStock: 'الرصيد المتاح',
      unit: 'وحدة القياس',
      reorderLevel: 'حد إعادة الطلب',
      costPerUnit: 'تكلفة الوحدة',
      valuation: 'قيمة الرصيد',
      status: 'حالة الصنف',
      adjustStock: 'تسوية الجرد اليدوي',
      newStock: 'الكمية الفعلية الجديدة',
      reason: 'سبب التسوية (تلف، عجز، تصحيح جرد)',
      saveAdjustment: 'اعتماد التسوية وقيد الفارق محاسبياً',
      bomDescription: 'معادلات التكلفة لكل طبق وربطها التلقائي بمكونات المستودع',
      dishName: 'اسم الطبق / الوجبة',
      portionCost: 'تكلفة المقادير (BOM Cost)',
      sellingPrice: 'سعر البيع للزبون',
      marginPercent: 'هامش الربح الإجمالي',
      ingredientsUsed: 'المقادير المكونة للطبق',
      bomRecipes: 'معادلات المقادير والتكاليف (BOM)',
      transactions: 'سجل حركات المخزون والمستودع',
      ingredientCode: 'كود المادة الأولية',
      unitCost: 'تكلفة الوحدة',
      addIngredient: 'إضافة مادة أولية جديدة',
      lowStockAlert: 'أصناف بلغت حد إعادة الطلب',
      rawMaterials: 'المواد الأولية والمستودع',
    },

    accounting: {
      title: 'النظام المحاسبي ودفتر الأستاذ العام',
      subtitle: 'دليل الحسابات المتكامل، القيود المحاسبية التلقائية المزدوجة، ميزان المراجعة والأرباح',
      chartOfAccounts: 'شجرة الحسابات (Chart of Accounts)',
      journalEntries: 'سجل القيود اليومية الآلية',
      trialBalance: 'ميزان المراجعة المحاسبي',
      profitAndLoss: 'قائمة الأرباح والخسائر (P&L)',
      pnl: 'قائمة الأرباح والخسائر (P&L)',
      balanceSheet: 'الميزانية العمومية (Balance Sheet)',
      code: 'رقم الحساب',
      accountName: 'اسم الحساب المالي',
      type: 'النوع المحاسبي',
      subCategory: 'التصنيف الفرعي',
      balance: 'الرصيد الدفتري',
      totalDebits: 'إجمالي حركات المدين',
      totalCredits: 'إجمالي حركات الدائن',
      variance: 'فارق التوازن',
      balanced: 'القيود متوازنة بدقة (Balanced)',
      unbalanced: 'يوجد عدم توازن',
      entryNumber: 'رقم القيد',
      date: 'تاريخ القيد',
      description: 'البيان والوصف',
      lines: 'أطراف القيد المزدوج',
      recordExpense: 'تسجيل سند صرف مصروفات',
      expenseVoucher: 'سند صرف مصروفات',
      expenseAccount: 'حساب المصروف',
      amount: 'المبلغ المسدد',
      paidFrom: 'طريقة الدفع (صندوق النقدية / البنك)',
      notes: 'البيان وملاحظات السند',
    },

    customers: {
      title: 'إدارة العملاء وبرامج الولاء (CRM)',
      subtitle: 'سجل بيانات العملاء، احتساب نقاط المكافآت، الأرصدة الآجلة ومتابعة تكرار الزيارات',
      addCustomer: 'تسجيل عميل جديد',
      totalCustomers: 'إجمالي قاعدة العملاء',
      vipMembers: 'أعضاء الفئات المميزة',
      totalPoints: 'مجموع نقاط الولاء النشطة',
      name: 'اسم العميل',
      phone: 'رقم الجوال',
      email: 'البريد الإلكتروني',
      tier: 'فئة العضوية',
      loyaltyPoints: 'رصيد النقاط',
      visits: 'مرات الزيارة',
      totalSpent: 'إجمالي المشتريات',
      creditBalance: 'الرصيد الآجل المسموح',
      newCustomerModal: 'إضافة عميل إلى قاعدة البيانات',
      saveCustomer: 'حفظ بيانات العميل',
    },

    suppliers: {
      title: 'سجل الموردين والحسابات الدائنة (AP)',
      subtitle: 'بيانات جهات التوريد، شروط السداد، ومتابعة الأرصدة المستحقة وسندات الصرف',
      addSupplier: 'إضافة مورد جديد',
      totalPayables: 'إجمالي المستحقات للموردين',
      activeSuppliers: 'عدد الموردين المعتمدين',
      supplierName: 'اسم المورد / الشركة',
      contactPerson: 'المسؤول / جهة الاتصال',
      phone: 'رقم الهاتف',
      category: 'مجال التوريد',
      paymentTerms: 'شروط الدفع والائتمان',
      balanceOwed: 'الرصيد المستحق دفعه',
      makePayment: 'سداد دفعة للمورد',
      paymentModal: 'إصدار سند سداد دفعة لمورد',
      payAmount: 'المبلغ المراد سداده',
      confirmPayment: 'تأكيد السداد وترحيل القيد المحاسبي',
    },

    employees: {
      title: 'الموارد البشرية والورديات (HR & Shifts)',
      subtitle: 'سجل الموظفين، الحضور والانصراف اللحظي، احتساب ساعات العمل وأداء المبيعات',
      addEmployee: 'إضافة موظف جديد',
      activeOnShift: 'موظفين بالوردية حالياً',
      todayShiftSales: 'مبيعات الوردية الإجمالية',
      staffName: 'اسم الموظف',
      role: 'المسمى الوظيفي',
      hourlyWage: 'الأجر بالساعة',
      status: 'حالة الدوام',
      clockIn: 'تسجيل الحضور',
      clockOut: 'تسجيل الانصراف',
      tablesServed: 'طاولات مخدومة',
      todaySales: 'مبيعات الموظف اليوم',
      newEmployeeModal: 'تسجيل موظف جديد بالنظام',
      activeStaff: 'طاقم العمل المناوب حالياً',
      clockedIn: 'حاضر بالدوام',
      totalStaff: 'إجمالي الكادر الوظيفي',
      clockedOut: 'منصرف / غير مناوب',
      salesHandled: 'مبيعات الكاشير / النادل',
      hourlyRate: 'الأجر بالساعة',
      pin: 'رمز المرور PIN',
    },

    reports: {
      title: 'التقارير التحليلية والذكاء التشغيلي',
      subtitle: 'مؤشرات الأداء المالي والتشغيلي، نسب تكلفة الطعام، والمبيعات حسب الأقسام والساعات',
      todayRevenue: 'صافي إيرادات اليوم',
      totalOrders: 'إجمالي الفواتير الصادرة',
      netProfit: 'صافي الربح التشغيلي',
      foodCostPercent: 'نسبة تكلفة الطعام (Food Cost %)',
      salesByCategory: 'توزيع المبيعات حسب أقسام القائمة',
      hourlyDistribution: 'حركة المبيعات حسب ساعات اليوم',
      topSellingItems: 'الأصناف الأكثر طلباً ومبيعاً',
      category: 'القسم',
      salesVolume: 'الكمية المباعة',
      revenue: 'قيمة الإيراد',
      staffPerformance: 'إنتاجية ومبيعات طاقم الخدمة',
      today: 'اليوم',
      thisWeek: 'هذا الأسبوع',
      thisMonth: 'هذا الشهر',
      hourlySales: 'حركة المبيعات بالساعة',
      topDishes: 'الأطباق الأكثر مبيعاً',
      serverPerformance: 'أداء طاقم الخدمة',
    },

    settings: {
      title: 'إعدادات النظام والمنشأة',
      subtitle: 'بيانات المطعم الرسمية، معدلات الضريبة والخدمة، تذييل الفاتورة وإدارة بيئة العمل',
      businessIdentity: 'البيانات التجارية والقانونية',
      restaurantProfile: 'هوية وبيانات المطعم التجارية',
      restaurantName: 'اسم المطعم / المنشأة',
      tagline: 'الشعار التسويقي (Slogan)',
      address: 'العنوان الجغرافي للفرع',
      phone: 'هاتف التواصل الرسمي',
      vatNumber: 'الرقم الضريبي للمنشأة',
      taxNumber: 'الرقم الضريبي للمنشأة (VAT ID)',
      taxesAndCharges: 'الضرائب ورسوم الخدمة',
      taxAndServices: 'الضرائب ورسوم الخدمة',
      vatRate: 'نسبة ضريبة القيمة المضافة (%)',
      taxRate: 'نسبة ضريبة القيمة المضافة (%)',
      serviceCharge: 'نسبة رسوم الخدمة (%)',
      currencySymbol: 'رمز العملة الافتراضية',
      receiptCustomization: 'تخصيص الفاتورة الحرارية للزبون',
      receiptFooter: 'رسالة الشكر أسفل الفاتورة',
      systemLanguage: 'لغة الواجهة الافتراضية',
      language: 'لغة واجهة النظام',
      saveSettings: 'حفظ التغييرات في الإعدادات',
      resetDatabase: 'استعادة البيانات الافتراضية التجريبية',
      resetData: 'إعادة تعيين قاعدة البيانات',
      resetWarning: 'سيؤدي هذا الخيار إلى إعادة تهيئة الفواتير والمخزون والحسابات إلى الحالة الأصلية.',
      confirmReset: 'تأكيد استعادة بيانات المصنع',
      resetSuccess: 'تم إعادة تهيئة بيانات النظام بنجاح.',
      saveSuccess: 'تم حفظ كافة الإعدادات بنجاح.',
    },

    architecture: {
      title: 'معمارية النظام C# ASP.NET Core & SQL Server',
      subtitle: 'استعراض الهيكلية البرمجية للواجهة الخلفية (Clean Architecture) ومخطط قاعدة بيانات SQL Server',
      backendTab: 'مشروع ASP.NET Core Web API',
      databaseTab: 'مخطط SQL Server (T-SQL)',
      filesList: 'ملفات المعمارية وقواعد البيانات',
      copyCode: 'نسخ الكود البرمجي',
      copied: 'تم النسخ!',
      sqlConsole: 'منصة استعلامات T-SQL الحية (Direct Engine)',
      sqlConsoleSubtitle: 'تنفيذ استعلامات SQL حية مباشرة على بيانات النظام في الذاكرة',
      executeSql: 'تنفيذ الاستعلام (Execute Query)',
      quickQueries: 'استعلامات سريعة جاهزة',
    },

    kds: {
      title: 'شاشة المطبخ الذكية (Kitchen Display System)',
      subtitle: 'متابعة وتحديث تذاكر التحضير الفورية الصادرة من أجهزة الكاشير وتنبيه الطهاة',
      activeTickets: 'تذاكر قيد التحضير حالياً',
      table: 'طاولة / طلب',
      elapsed: 'الوقت المنقضي',
      items: 'الوجبات المطلوبة',
      markCooking: 'بدء الطهي',
      markReady: 'جاهز للتسليم',
      completed: 'تم التسليم بالكامل',
      soundAlert: 'تنبيه صوتي للطلبات الجديدة',
      allClear: 'المطبخ خالٍ من أي طلبات معلقة حالياً!',
    },

    register: {
      title: 'درج النقدية وإغلاق الوردية (Cash Till)',
      subtitle: 'تسجيل رصيد الافتتاح، المبيعات النقدية، المصروفات، والعد الفعلي وإقفال الصندوق',
      openingFloat: 'رصيد الافتتاح (عهدة البداية):',
      cashSales: 'المبيعات النقدية اليوم:',
      paidOut: 'المصروفات النقدية الخارجة:',
      expectedCash: 'الرصيد الدفتري المتوقع بالدرج:',
      actualCount: 'العد الفعلي للنقدية الموجودة بالدرج:',
      variance: 'الفارق المحاسبي:',
      balanced: 'الصندوق متطابق تماماً دون عجز أو زيادة',
      overage: 'فائض نقدي بالدرج',
      shortage: 'عجز نقدي بالدرج',
      reconcileNotes: 'ملاحظات إغلاق الوردية:',
      confirmReconcile: 'اعتماد تسوية الدرج وإغلاق الوردية',
      cancel: 'إلغاء',
    },
  },

  en: {
    appName: 'RestaurantERP',
    appSubtitle: 'Enterprise Web POS & Operations Management System',
    toggleLang: 'العربية',
    dir: 'ltr',

    common: {
      save: 'Save',
      cancel: 'Cancel',
      confirm: 'Confirm',
      close: 'Close',
      delete: 'Delete',
      edit: 'Edit',
      search: 'Search...',
      all: 'All',
      filter: 'Filter',
      loading: 'Loading...',
      success: 'Operation completed successfully',
      error: 'An error occurred',
    },

    nav: {
      pos: 'POS Terminal',
      sales: 'Sales & Orders',
      purchases: 'Purchases',
      inventory: 'Inventory & BOM',
      accounting: 'Accounting & Ledger',
      customers: 'Customers & Loyalty',
      suppliers: 'Suppliers',
      employees: 'Staff & Shifts',
      reports: 'Reports & Analytics',
      settings: 'Settings & VAT',
      architecture: 'ASP.NET & SQL Hub',
      kds: 'Kitchen Display (KDS)',
      activeBadge: 'Active',
    },

    header: {
      tillBalance: 'Till Balance',
      openKds: 'Kitchen KDS',
      architectureHub: 'C# & T-SQL Code',
      clockIn: 'Clock In',
      clockOut: 'Clock Out',
      clockedIn: 'On Shift',
      clockedOut: 'Off Shift',
      staffRole: 'Current Staff',
      lowStockWarning: 'low stock alerts',
      openRegister: 'Cash Till & Close',
      systemOnline: 'System Online',
      backendActive: 'ASP.NET Core Web API',
    },

    pos: {
      dineIn: 'Dine-In Table',
      takeaway: 'Takeaway',
      delivery: 'Delivery',
      searchPlaceholder: 'Search dishes by name or code (e.g., Burger, Steak, Pasta)...',
      allDishes: 'All Items',
      starters: 'Starters',
      steaks: 'Steaks & Grills',
      pizzaPasta: 'Pizza & Pasta',
      seafood: 'Seafood',
      desserts: 'Desserts',
      beverages: 'Beverages',
      orderTicket: 'Current Order Ticket',
      ticketNum: 'Order #',
      emptyCartTitle: 'No items in order yet',
      emptyCartSubtitle: 'Select menu items from the menu grid to begin',
      subtotal: 'Subtotal',
      tax: 'VAT / Tax',
      serviceCharge: 'Service Surcharge',
      discount: 'Discount',
      total: 'Grand Total',
      tableNum: 'Table #',
      selectGuestTable: 'Select Table',
      guests: 'Guests',
      available: 'Available',
      occupied: 'Occupied',
      reserved: 'Reserved',
      payAndPrint: 'Checkout & Pay',
      sendToKitchen: 'Send to KDS',
      holdOrder: 'Hold Ticket',
      clearCart: 'Clear Order',
      paymentModalTitle: 'Payment & Settlement',
      amountToPay: 'Amount Payable',
      selectPaymentMethod: 'Select Payment Method',
      cash: 'Cash Tender',
      card: 'Credit / Debit Card',
      mobilePay: 'Apple Pay / Mobile',
      customerCredit: 'Customer Credit Account',
      tenderedAmount: 'Cash Tendered',
      changeDue: 'Change Due',
      confirmPayment: 'Complete Payment & Print Receipt',
      cancel: 'Cancel',
      receiptPreview: 'Simplified Tax Receipt Preview',
      printReceipt: 'Print Instant Receipt',
      orderSuccess: 'Order paid successfully. Inventory depleted and journal entries posted.',
      orderSentKds: 'Order sent to Kitchen Display System.',
    },

    sales: {
      title: 'Sales Orders & Invoices',
      subtitle: 'Monitor completed and pending orders, payment reconciliation and guest records',
      totalSales: "Today's Total Sales",
      ordersCount: 'Orders Count',
      avgTicket: 'Average Ticket Value',
      filterAll: 'All Orders',
      filterCompleted: 'Completed / Paid',
      filterPending: 'Pending / In-Prep',
      filterVoided: 'Voided',
      orderNumber: 'Order #',
      type: 'Order Type',
      table: 'Table / Guest',
      itemsCount: 'Items',
      total: 'Total Amount',
      payment: 'Payment Method',
      status: 'Status',
      time: 'Time',
      actions: 'Actions',
      viewDetails: 'View Details',
      printReceipt: 'Reprint Receipt',
      unpaid: 'Unpaid',
      paid: 'Paid in Full',
      refunded: 'Refunded',
      statusPending: 'Pending',
      statusPreparing: 'Preparing',
      statusReady: 'Ready for Service',
      statusServed: 'Served',
      statusCompleted: 'Completed',
      statusVoided: 'Voided',
    },

    purchases: {
      title: 'Purchases & Inbound Deliveries',
      subtitle: 'Purchase orders, stock receiving, supplier invoice settlement and automated stock replenishment',
      createPO: 'New Purchase Order',
      totalPurchases: 'Monthly Purchases',
      pendingDeliveries: 'Pending Deliveries',
      poNumber: 'PO Number',
      supplier: 'Supplier',
      date: 'Order Date',
      totalAmount: 'Total Value',
      status: 'Status',
      receiveStock: 'Receive Delivery & Restock',
      draft: 'Draft',
      ordered: 'Ordered',
      received: 'Received & Restocked',
      cancelled: 'Cancelled',
      newPurchaseOrder: 'Issue Purchase Order',
      selectSupplier: 'Select Supplier',
      addItem: 'Add Raw Material',
      quantity: 'Quantity',
      unitPrice: 'Unit Price',
      lineTotal: 'Line Total',
      savePO: 'Save Purchase Order',
    },

    inventory: {
      title: 'Inventory & Recipe BOM Management',
      subtitle: 'Raw ingredient levels, recipe yields, automated stock depletion and stocktaking variance',
      rawIngredients: 'Raw Ingredients',
      recipeBOM: 'Recipe BOM Formulas',
      totalValuation: 'Total Stock Valuation',
      lowStockItems: 'Low Stock Alerts',
      code: 'Code',
      ingredientName: 'Ingredient Name',
      category: 'Category',
      currentStock: 'Current Stock',
      unit: 'Unit',
      reorderLevel: 'Reorder Level',
      costPerUnit: 'Cost / Unit',
      valuation: 'Valuation',
      status: 'Status',
      adjustStock: 'Adjust Stock Balance',
      newStock: 'Actual Physical Count',
      reason: 'Adjustment Reason (Spoilage, Audit, Shrinkage)',
      saveAdjustment: 'Apply Adjustment & Post Journal',
      bomDescription: 'Recipe costing formulas and direct inventory depletion mapping',
      dishName: 'Dish Name',
      portionCost: 'BOM Portion Cost',
      sellingPrice: 'Selling Price',
      marginPercent: 'Gross Margin %',
      ingredientsUsed: 'Recipe Ingredients',
      bomRecipes: 'Recipe BOM Costing',
      transactions: 'Stock Movement Logs',
      ingredientCode: 'Ingredient Code',
      unitCost: 'Unit Cost',
      addIngredient: 'Add Raw Ingredient',
      lowStockAlert: 'Low Stock Alerts',
      rawMaterials: 'Raw Ingredients & Stock',
    },

    accounting: {
      title: 'Accounting & General Ledger',
      subtitle: 'Complete Chart of Accounts, automated double-entry journal entries, trial balance and P&L',
      chartOfAccounts: 'Chart of Accounts',
      journalEntries: 'Automated Journal Entries',
      trialBalance: 'Trial Balance',
      profitAndLoss: 'Profit & Loss (P&L)',
      pnl: 'Profit & Loss (P&L)',
      balanceSheet: 'Balance Sheet',
      code: 'Account Code',
      accountName: 'Account Name',
      type: 'Account Type',
      subCategory: 'Sub-Category',
      balance: 'Balance',
      totalDebits: 'Total Debits',
      totalCredits: 'Total Credits',
      variance: 'Variance',
      balanced: 'Balanced',
      unbalanced: 'Unbalanced',
      entryNumber: 'Entry #',
      date: 'Date',
      description: 'Description',
      lines: 'Journal Lines',
      recordExpense: 'Record Expense Voucher',
      expenseVoucher: 'Expense Voucher',
      expenseAccount: 'Expense Account',
      amount: 'Amount',
      paidFrom: 'Paid From (Cash / Bank)',
      notes: 'Voucher Notes',
    },

    customers: {
      title: 'Customer Relationship Management (CRM)',
      subtitle: 'Guest profiles, loyalty points calculation, credit accounts and visit history',
      addCustomer: 'Add New Customer',
      totalCustomers: 'Total Guests',
      vipMembers: 'VIP Tier Members',
      totalPoints: 'Active Loyalty Points',
      name: 'Guest Name',
      phone: 'Phone',
      email: 'Email',
      tier: 'Membership Tier',
      loyaltyPoints: 'Loyalty Points',
      visits: 'Visit Count',
      totalSpent: 'Lifetime Spend',
      creditBalance: 'Credit Balance',
      newCustomerModal: 'Register New Guest',
      saveCustomer: 'Save Customer',
    },

    suppliers: {
      title: 'Suppliers & Accounts Payable (AP)',
      subtitle: 'Vendor directories, payment terms, outstanding invoices and balance disbursements',
      addSupplier: 'Add Supplier',
      totalPayables: 'Total Accounts Payable',
      activeSuppliers: 'Active Vendors',
      supplierName: 'Vendor Name',
      contactPerson: 'Contact Person',
      phone: 'Phone',
      category: 'Category',
      paymentTerms: 'Payment Terms',
      balanceOwed: 'Balance Due',
      makePayment: 'Disburse Payment',
      paymentModal: 'Disburse Supplier Payment',
      payAmount: 'Payment Amount',
      confirmPayment: 'Confirm Payment & Post Journal',
    },

    employees: {
      title: 'Human Resources & Shifts (HR)',
      subtitle: 'Staff directory, time clock management, shift tracking and server sales volume',
      addEmployee: 'Register Employee',
      activeOnShift: 'Active on Shift',
      todayShiftSales: 'Shift Sales Total',
      staffName: 'Employee Name',
      role: 'Role',
      hourlyWage: 'Base Hourly Wage',
      status: 'Shift Status',
      clockIn: 'Clock In',
      clockOut: 'Clock Out',
      tablesServed: 'Tables Served',
      todaySales: 'Today Sales',
      newEmployeeModal: 'Add New Employee',
      activeStaff: 'Active on Shift',
      clockedIn: 'Clocked In',
      totalStaff: 'Total Staff',
      clockedOut: 'Off Shift / Clocked Out',
      salesHandled: 'Sales Handled',
      hourlyRate: 'Hourly Wage',
      pin: 'Staff PIN',
    },

    reports: {
      title: 'Reports & Business Intelligence',
      subtitle: 'Financial statements, sales mix by menu category, food cost ratios and labor productivity',
      todayRevenue: "Today's Revenue",
      totalOrders: 'Total Orders',
      netProfit: 'Net Operating Profit',
      foodCostPercent: 'Food Cost Ratio',
      salesByCategory: 'Sales by Menu Category',
      hourlyDistribution: 'Hourly Sales Volume',
      topSellingItems: 'Top Selling Menu Items',
      category: 'Category',
      salesVolume: 'Volume Sold',
      revenue: 'Gross Revenue',
      staffPerformance: 'Staff Shift Performance',
      today: 'Today',
      thisWeek: 'This Week',
      thisMonth: 'This Month',
      hourlySales: 'Hourly Sales Volume',
      topDishes: 'Top Selling Menu Items',
      serverPerformance: 'Staff Shift Performance',
    },

    settings: {
      title: 'System Settings & Operations',
      subtitle: 'Store profile, tax schedules, currency symbols, receipt templates & demo data maintenance',
      businessIdentity: 'Restaurant Business Identity',
      restaurantProfile: 'Restaurant Business Identity',
      restaurantName: 'Restaurant Name',
      tagline: 'Tagline / Slogan',
      address: 'Street Address',
      phone: 'Phone Number',
      vatNumber: 'Tax Registration / VAT ID',
      taxNumber: 'Tax Registration / VAT ID',
      taxesAndCharges: 'Taxes & Service Surcharges',
      taxAndServices: 'Taxes & Service Surcharges',
      vatRate: 'Sales Tax / VAT Rate (%)',
      taxRate: 'Sales Tax / VAT Rate (%)',
      serviceCharge: 'Service Charge (%)',
      currencySymbol: 'Currency Symbol',
      receiptCustomization: 'Thermal POS Receipt Customization',
      receiptFooter: 'Footer Thank You Message',
      systemLanguage: 'System Language',
      language: 'System Language',
      saveSettings: 'Save All Settings',
      resetDatabase: 'Reset Database to Initial State',
      resetData: 'Reset Database to Initial State',
      resetWarning: 'This will restore all orders, inventory, accounts and customers to factory initial state.',
      confirmReset: 'Confirm Reset',
      resetSuccess: 'Database successfully reset to initial demo state.',
      saveSuccess: 'Restaurant ERP configuration updated successfully.',
    },

    architecture: {
      title: 'ASP.NET Core & SQL Server Architecture Reference',
      subtitle: 'Production C# backend controllers, services, EF Core repositories & SQL Server T-SQL schema',
      backendTab: 'ASP.NET Core Web API',
      databaseTab: 'SQL Server (T-SQL)',
      filesList: 'Architecture & Schema Files',
      copyCode: 'Copy Code',
      copied: 'Copied!',
      sqlConsole: 'Interactive T-SQL Query Console (Live Data Engine)',
      sqlConsoleSubtitle: 'Direct query execution on in-memory relational dataset',
      executeSql: 'Execute SQL',
      quickQueries: 'Quick Queries',
    },

    kds: {
      title: 'Kitchen Display System (KDS)',
      subtitle: 'Real-time kitchen order tickets, prep timers and cook station handoffs',
      activeTickets: 'Active Kitchen Tickets',
      table: 'Table / Order',
      elapsed: 'Prep Time',
      items: 'Items to Cook',
      markCooking: 'Start Cooking',
      markReady: 'Mark Ready',
      completed: 'All Dishes Served',
      soundAlert: 'Sound Alert on New Ticket',
      allClear: 'All clear! No active kitchen orders right now.',
    },

    register: {
      title: 'Cash Register Drawer Till',
      subtitle: 'Opening float & end-of-shift reconciliation',
      openingFloat: 'Opening Float (Cash In):',
      cashSales: "Today's Cash Sales:",
      paidOut: 'Paid Out / Petty Cash:',
      expectedCash: 'Expected Cash in Drawer:',
      actualCount: 'Actual Physical Cash Count ($):',
      variance: 'Cash Variance:',
      balanced: 'Drawer Perfectly Balanced',
      overage: 'Overage',
      shortage: 'Shortage',
      reconcileNotes: 'Shift Reconciliation Notes:',
      confirmReconcile: 'Save Drawer Reconciliation',
      cancel: 'Cancel',
    },
  },
};
