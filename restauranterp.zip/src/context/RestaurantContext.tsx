import React, { createContext, useContext, useState, useEffect } from 'react';
import { Language, translations, Translations } from '../locales/translations';
import {
  RestaurantTable,
  MenuItem,
  Ingredient,
  Order,
  OrderItem,
  Supplier,
  Customer,
  Employee,
  PurchaseOrder,
  Account,
  JournalEntry,
  CashRegisterSession,
  RestaurantSettings,
  OrderType,
  PaymentMethod,
  InventoryTransaction,
  ErpModule,
} from '../types/erp';
import {
  initialTables,
  initialMenuItems,
  initialIngredients,
  initialSuppliers,
  initialCustomers,
  initialEmployees,
  initialOrders,
  initialPurchaseOrders,
  initialAccounts,
  initialJournalEntries,
  initialCashRegister,
  initialSettings,
} from '../mockData/initialData';

interface CartItemState {
  menuItemId: string;
  name: string;
  price: number;
  cost: number;
  quantity: number;
  selectedModifiers?: string[];
  kitchenNotes?: string;
}

interface RestaurantContextType {
  // Language & Localization
  language: Language;
  setLanguage: (lang: Language) => void;
  t: Translations;

  // Master Data
  activeModule: ErpModule;
  setActiveModule: (module: ErpModule) => void;
  settings: RestaurantSettings;
  updateSettings: (newSettings: Partial<RestaurantSettings>) => void;
  tables: RestaurantTable[];
  menuItems: MenuItem[];
  ingredients: Ingredient[];
  inventoryTransactions: InventoryTransaction[];
  orders: Order[];
  purchaseOrders: PurchaseOrder[];
  suppliers: Supplier[];
  customers: Customer[];
  employees: Employee[];
  setEmployees: React.Dispatch<React.SetStateAction<Employee[]>>;
  accounts: Account[];
  journalEntries: JournalEntry[];
  cashRegister: CashRegisterSession;
  reconcileCashRegister: (actualCount: number, notes?: string) => void;

  // Active POS State
  orderType: OrderType;
  setOrderType: (type: OrderType) => void;
  selectedTableId: string | null;
  setSelectedTableId: (id: string | null) => void;
  guestCount: number;
  setGuestCount: (count: number) => void;
  selectedCustomerId: string | null;
  setSelectedCustomerId: (id: string | null) => void;
  activeEmployeeId: string;
  setActiveEmployeeId: (id: string) => void;
  cart: CartItemState[];
  discountPercent: number;
  setDiscountPercent: (percent: number) => void;
  discountReason: string;
  setDiscountReason: (reason: string) => void;

  // Cart Actions
  addToCart: (item: MenuItem, quantity?: number, modifiers?: string[], notes?: string) => void;
  removeFromCart: (menuItemId: string) => void;
  updateCartQuantity: (menuItemId: string, delta: number) => void;
  updateItemNotes: (menuItemId: string, notes: string) => void;
  clearCart: () => void;
  cartSubtotal: number;
  cartTax: number;
  cartServiceCharge: number;
  cartDiscountAmount: number;
  cartTotal: number;

  // POS Workflow
  sendOrderToKitchen: () => Order | null;
  processCheckout: (
    paymentMethod: PaymentMethod,
    amountTendered: number,
    splitCount?: number
  ) => { success: boolean; order?: Order; error?: string };
  voidOrder: (orderId: string, reason: string) => void;
  updateKdsStatus: (orderId: string, status: 'queued' | 'cooking' | 'ready' | 'bumped') => void;

  // Purchases Workflow
  createPurchaseOrder: (
    supplierId: string,
    items: { ingredientId: string; quantity: number; unitPrice: number }[],
    notes?: string
  ) => PurchaseOrder;
  receivePurchaseOrder: (poId: string) => boolean;

  // Inventory Actions
  adjustStock: (
    ingredientId: string,
    quantityDelta: number,
    reason: string,
    type: 'waste_spoilage' | 'manual_adjustment'
  ) => void;
  addIngredient: (ingredient: Omit<Ingredient, 'id' | 'lastRestocked'>) => void;

  // Accounting Actions
  recordExpenseVoucher: (
    description: string,
    expenseAccountCode: string,
    paymentAccountCode: string,
    amount: number
  ) => void;

  // Suppliers & Customers
  addSupplier: (supplier: Omit<Supplier, 'id' | 'balancePayable'>) => void;
  paySupplier: (supplierId: string, amount: number) => void;
  paySupplierBalance: (supplierId: string, amount: number) => void;
  addCustomer: (customer: Omit<Customer, 'id' | 'loyaltyPoints' | 'totalSpent' | 'visitCount' | 'joinedDate'>) => void;

  // Employees & HR
  toggleClockInOut: (employeeId: string) => void;

  // Reset demo data
  resetAllData: () => void;
}

const RestaurantContext = createContext<RestaurantContextType | undefined>(undefined);

export const RestaurantProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Language & Direction state (Default Arabic as requested: 'خليه عربي')
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem('rest_erp_lang');
    if (saved === 'en' || saved === 'ar') return saved;
    return 'ar';
  });

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem('rest_erp_lang', lang);
    if (typeof document !== 'undefined') {
      document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
      document.documentElement.lang = lang;
    }
  };

  useEffect(() => {
    if (typeof document !== 'undefined') {
      document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
      document.documentElement.lang = language;
    }
  }, [language]);

  const t = translations[language] || translations.ar;

  // Load from localStorage or defaults
  const [settings, setSettings] = useState<RestaurantSettings>(() => {
    const saved = localStorage.getItem('rest_erp_settings');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        // If language is Arabic and settings still have old English currency, adapt to SAR / ر.س
        return {
          ...initialSettings,
          ...parsed,
          currencySymbol: parsed.currencySymbol === '$' ? 'ر.س' : parsed.currencySymbol || 'ر.س',
          language: parsed.language || 'ar',
        };
      } catch {
        return initialSettings;
      }
    }
    return initialSettings;
  });

  const [tables, setTables] = useState<RestaurantTable[]>(() => {
    const saved = localStorage.getItem('rest_erp_tables');
    return saved ? JSON.parse(saved) : initialTables;
  });

  const [activeModule, setActiveModule] = useState<ErpModule>('pos');

  const [menuItems] = useState<MenuItem[]>(initialMenuItems);

  const [ingredients, setIngredients] = useState<Ingredient[]>(() => {
    const saved = localStorage.getItem('rest_erp_ingredients');
    return saved ? JSON.parse(saved) : initialIngredients;
  });

  const [inventoryTransactions, setInventoryTransactions] = useState<InventoryTransaction[]>(() => {
    const saved = localStorage.getItem('rest_erp_inv_tx');
    return saved ? JSON.parse(saved) : [];
  });

  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem('rest_erp_orders');
    return saved ? JSON.parse(saved) : initialOrders;
  });

  const [purchaseOrders, setPurchaseOrders] = useState<PurchaseOrder[]>(() => {
    const saved = localStorage.getItem('rest_erp_pos');
    return saved ? JSON.parse(saved) : initialPurchaseOrders;
  });

  const [suppliers, setSuppliers] = useState<Supplier[]>(() => {
    const saved = localStorage.getItem('rest_erp_suppliers');
    return saved ? JSON.parse(saved) : initialSuppliers;
  });

  const [customers, setCustomers] = useState<Customer[]>(() => {
    const saved = localStorage.getItem('rest_erp_customers');
    return saved ? JSON.parse(saved) : initialCustomers;
  });

  const [employees, setEmployees] = useState<Employee[]>(() => {
    const saved = localStorage.getItem('rest_erp_employees');
    return saved ? JSON.parse(saved) : initialEmployees;
  });

  const [accounts, setAccounts] = useState<Account[]>(() => {
    const saved = localStorage.getItem('rest_erp_accounts');
    return saved ? JSON.parse(saved) : initialAccounts;
  });

  const [journalEntries, setJournalEntries] = useState<JournalEntry[]>(() => {
    const saved = localStorage.getItem('rest_erp_je');
    return saved ? JSON.parse(saved) : initialJournalEntries;
  });

  const [cashRegister, setCashRegister] = useState<CashRegisterSession>(() => {
    const saved = localStorage.getItem('rest_erp_register');
    return saved ? JSON.parse(saved) : initialCashRegister;
  });

  // Active POS state
  const [orderType, setOrderType] = useState<OrderType>('dine-in');
  const [selectedTableId, setSelectedTableId] = useState<string | null>('tbl-2');
  const [guestCount, setGuestCount] = useState<number>(2);
  const [selectedCustomerId, setSelectedCustomerId] = useState<string | null>(null);
  const [activeEmployeeId, setActiveEmployeeId] = useState<string>('emp-3'); // Clara Oswald
  const [cart, setCart] = useState<CartItemState[]>([]);
  const [discountPercent, setDiscountPercent] = useState<number>(0);
  const [discountReason, setDiscountReason] = useState<string>('');

  // Persist key state
  useEffect(() => {
    localStorage.setItem('rest_erp_settings', JSON.stringify(settings));
  }, [settings]);
  useEffect(() => {
    localStorage.setItem('rest_erp_tables', JSON.stringify(tables));
  }, [tables]);
  useEffect(() => {
    localStorage.setItem('rest_erp_ingredients', JSON.stringify(ingredients));
  }, [ingredients]);
  useEffect(() => {
    localStorage.setItem('rest_erp_orders', JSON.stringify(orders));
  }, [orders]);
  useEffect(() => {
    localStorage.setItem('rest_erp_customers', JSON.stringify(customers));
  }, [customers]);
  useEffect(() => {
    localStorage.setItem('rest_erp_suppliers', JSON.stringify(suppliers));
  }, [suppliers]);
  useEffect(() => {
    localStorage.setItem('rest_erp_accounts', JSON.stringify(accounts));
  }, [accounts]);
  useEffect(() => {
    localStorage.setItem('rest_erp_pos', JSON.stringify(purchaseOrders));
  }, [purchaseOrders]);
  useEffect(() => {
    localStorage.setItem('rest_erp_employees', JSON.stringify(employees));
  }, [employees]);

  // Cart Calculations
  const cartSubtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const cartDiscountAmount = Number(((cartSubtotal * discountPercent) / 100).toFixed(2));
  const discountedSubtotal = Math.max(0, cartSubtotal - cartDiscountAmount);
  const cartTax = Number(((discountedSubtotal * settings.taxRatePercent) / 100).toFixed(2));
  const cartServiceCharge =
    orderType === 'dine-in'
      ? Number(((discountedSubtotal * settings.serviceChargePercent) / 100).toFixed(2))
      : 0;
  const cartTotal = Number((discountedSubtotal + cartTax + cartServiceCharge).toFixed(2));

  // Cart Actions
  const addToCart = (item: MenuItem, quantity = 1, modifiers?: string[], notes?: string) => {
    setCart((prev) => {
      const existing = prev.find((ci) => ci.menuItemId === item.id);
      if (existing) {
        return prev.map((ci) =>
          ci.menuItemId === item.id
            ? { ...ci, quantity: ci.quantity + quantity, kitchenNotes: notes || ci.kitchenNotes }
            : ci
        );
      }
      return [
        ...prev,
        {
          menuItemId: item.id,
          name: item.name,
          price: item.price,
          cost: item.cost,
          quantity,
          selectedModifiers: modifiers,
          kitchenNotes: notes,
        },
      ];
    });
  };

  const removeFromCart = (menuItemId: string) => {
    setCart((prev) => prev.filter((ci) => ci.menuItemId !== menuItemId));
  };

  const updateCartQuantity = (menuItemId: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((ci) => {
          if (ci.menuItemId === menuItemId) {
            const newQty = ci.quantity + delta;
            return newQty > 0 ? { ...ci, quantity: newQty } : null;
          }
          return ci;
        })
        .filter(Boolean) as CartItemState[]
    );
  };

  const updateItemNotes = (menuItemId: string, notes: string) => {
    setCart((prev) =>
      prev.map((ci) => (ci.menuItemId === menuItemId ? { ...ci, kitchenNotes: notes } : ci))
    );
  };

  const clearCart = () => {
    setCart([]);
    setDiscountPercent(0);
    setDiscountReason('');
  };

  const updateSettings = (newSettings: Partial<RestaurantSettings>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }));
  };

  // Send to Kitchen (KDS)
  const sendOrderToKitchen = (): Order | null => {
    if (cart.length === 0) return null;

    const server = employees.find((e) => e.id === activeEmployeeId) || employees[0];
    const customer = customers.find((c) => c.id === selectedCustomerId);
    const table = tables.find((t) => t.id === selectedTableId);

    const now = new Date();
    const dateStr = now.toISOString().slice(0, 10).replace(/-/g, '');
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const orderNumber = `ORD-${dateStr}-${randomSuffix}`;

    const newOrder: Order = {
      id: `ord-${Date.now()}`,
      orderNumber,
      orderType,
      tableId: orderType === 'dine-in' ? selectedTableId || undefined : undefined,
      tableNumber: orderType === 'dine-in' ? table?.number : undefined,
      guestCount,
      customerName: customer ? customer.name : orderType === 'dine-in' ? `Table ${table?.number}` : 'Takeaway Guest',
      customerId: customer?.id,
      serverName: server.name,
      serverId: server.id,
      items: cart.map((ci, idx) => ({
        id: `oi-${Date.now()}-${idx}`,
        menuItemId: ci.menuItemId,
        name: ci.name,
        price: ci.price,
        cost: ci.cost,
        quantity: ci.quantity,
        selectedModifiers: ci.selectedModifiers,
        kitchenNotes: ci.kitchenNotes,
      })),
      subtotal: cartSubtotal,
      taxAmount: cartTax,
      serviceChargeAmount: cartServiceCharge,
      discountAmount: cartDiscountAmount,
      discountReason: discountReason || undefined,
      total: cartTotal,
      status: 'preparing',
      paymentStatus: 'unpaid',
      createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      kdsStatus: 'cooking',
    };

    setOrders((prev) => [newOrder, ...prev]);

    // Mark table as occupied
    if (orderType === 'dine-in' && selectedTableId) {
      setTables((prev) =>
        prev.map((tbl) =>
          tbl.id === selectedTableId
            ? {
                ...tbl,
                status: 'occupied',
                currentOrderId: newOrder.id,
                guestCount,
                occupiedSince: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
              }
            : tbl
        )
      );
    }

    clearCart();
    return newOrder;
  };

  // Settle Order & Deduct Inventory BOM & Record Accounting
  const processCheckout = (
    paymentMethod: PaymentMethod,
    amountTendered: number
  ): { success: boolean; order?: Order; error?: string } => {
    if (cart.length === 0) {
      return { success: false, error: 'Cart is empty' };
    }

    const server = employees.find((e) => e.id === activeEmployeeId) || employees[0];
    const customer = customers.find((c) => c.id === selectedCustomerId);
    const table = tables.find((t) => t.id === selectedTableId);

    const now = new Date();
    const dateStr = now.toISOString().slice(0, 10).replace(/-/g, '');
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const orderNumber = `ORD-${dateStr}-${randomSuffix}`;
    const changeGiven = Math.max(0, Number((amountTendered - cartTotal).toFixed(2)));

    const completedOrder: Order = {
      id: `ord-${Date.now()}`,
      orderNumber,
      orderType,
      tableId: orderType === 'dine-in' ? selectedTableId || undefined : undefined,
      tableNumber: orderType === 'dine-in' ? table?.number : undefined,
      guestCount,
      customerName: customer ? customer.name : orderType === 'dine-in' ? `Table ${table?.number}` : 'Walk-in Guest',
      customerId: customer?.id,
      serverName: server.name,
      serverId: server.id,
      items: cart.map((ci, idx) => ({
        id: `oi-${Date.now()}-${idx}`,
        menuItemId: ci.menuItemId,
        name: ci.name,
        price: ci.price,
        cost: ci.cost,
        quantity: ci.quantity,
        selectedModifiers: ci.selectedModifiers,
        kitchenNotes: ci.kitchenNotes,
      })),
      subtotal: cartSubtotal,
      taxAmount: cartTax,
      serviceChargeAmount: cartServiceCharge,
      discountAmount: cartDiscountAmount,
      discountReason: discountReason || undefined,
      total: cartTotal,
      status: 'completed',
      paymentStatus: 'paid',
      paymentMethod,
      amountTendered,
      changeGiven,
      createdAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      completedAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      kdsStatus: 'bumped',
    };

    // 1. Save Completed Order
    setOrders((prev) => [completedOrder, ...prev]);

    // 2. Free Table
    if (orderType === 'dine-in' && selectedTableId) {
      setTables((prev) =>
        prev.map((tbl) =>
          tbl.id === selectedTableId
            ? {
                ...tbl,
                status: 'available',
                currentOrderId: undefined,
                guestCount: undefined,
                occupiedSince: undefined,
              }
            : tbl
        )
      );
    }

    // 3. Atomically Deduct Raw Ingredients based on Recipe BOM
    const newTxList: InventoryTransaction[] = [];
    const ingredientDeductions: Record<string, number> = {};

    cart.forEach((cartItem) => {
      const menu = menuItems.find((m) => m.id === cartItem.menuItemId);
      if (menu && menu.recipeBom) {
        menu.recipeBom.forEach((bom) => {
          const qtyNeeded = bom.quantity * cartItem.quantity;
          ingredientDeductions[bom.ingredientId] = (ingredientDeductions[bom.ingredientId] || 0) + qtyNeeded;
        });
      }
    });

    setIngredients((prev) =>
      prev.map((ing) => {
        const deductQty = ingredientDeductions[ing.id];
        if (deductQty) {
          const updatedStock = Math.max(0, Number((ing.currentStock - deductQty).toFixed(3)));
          newTxList.push({
            id: `tx-${Date.now()}-${ing.id}`,
            ingredientId: ing.id,
            ingredientName: ing.name,
            type: 'sale_deduction',
            quantityDelta: -deductQty,
            unit: ing.unit,
            unitCost: ing.costPerUnit,
            reason: `Order ${orderNumber} BOM deduction`,
            referenceId: orderNumber,
            createdAt: new Date().toISOString().replace('T', ' ').slice(0, 16),
            staffName: server.name,
          });
          return { ...ing, currentStock: updatedStock };
        }
        return ing;
      })
    );

    if (newTxList.length > 0) {
      setInventoryTransactions((prev) => [...newTxList, ...prev]);
    }

    // 4. Update Customer Loyalty & Spending
    if (customer) {
      const earnedPoints = Math.floor(cartTotal);
      setCustomers((prev) =>
        prev.map((c) =>
          c.id === customer.id
            ? {
                ...c,
                loyaltyPoints: c.loyaltyPoints + earnedPoints,
                totalSpent: Number((c.totalSpent + cartTotal).toFixed(2)),
                visitCount: c.visitCount + 1,
                tier:
                  c.totalSpent + cartTotal > 3000
                    ? 'Platinum'
                    : c.totalSpent + cartTotal > 1500
                    ? 'Gold'
                    : c.totalSpent + cartTotal > 500
                    ? 'Silver'
                    : 'Bronze',
              }
            : c
        )
      );
    }

    // 5. Update Server performance
    setEmployees((prev) =>
      prev.map((emp) =>
        emp.id === server.id
          ? {
              ...emp,
              totalSalesToday: Number((emp.totalSalesToday + cartTotal).toFixed(2)),
              tablesServedToday: emp.tablesServedToday + 1,
            }
          : emp
      )
    );

    // 6. Update Cash Register
    if (paymentMethod === 'cash') {
      setCashRegister((prev) => ({
        ...prev,
        cashSales: Number((prev.cashSales + cartTotal).toFixed(2)),
        expectedCash: Number((prev.expectedCash + cartTotal).toFixed(2)),
      }));
    }

    // 7. Double-Entry Accounting Journal Entry
    const totalCostOfGoods = cart.reduce((sum, ci) => sum + ci.cost * ci.quantity, 0);
    const paymentAccountCode = paymentMethod === 'cash' ? '1010' : '1020'; // Cash or Bank
    const paymentAccountName = paymentMethod === 'cash' ? 'Cash on Hand (Till / Register)' : 'Operating Bank Account (JPMorgan Chase)';

    const salesEntry: JournalEntry = {
      id: `je-${Date.now()}`,
      entryNumber: `JE-${Date.now().toString().slice(-6)}`,
      date: new Date().toISOString().replace('T', ' ').slice(0, 16),
      description: `POS Order #${orderNumber} Settlement (${paymentMethod.toUpperCase()})`,
      referenceType: 'POS_SALE',
      referenceId: orderNumber,
      totalDebit: cartTotal,
      totalCredit: cartTotal,
      createdBy: server.name,
      lines: [
        {
          accountCode: paymentAccountCode,
          accountName: paymentAccountName,
          debit: cartTotal,
          credit: 0,
        },
        {
          accountCode: '4010',
          accountName: 'Food Sales Revenue',
          debit: 0,
          credit: Number((cartSubtotal - cartDiscountAmount).toFixed(2)),
        },
        {
          accountCode: '2020',
          accountName: 'Sales Tax / VAT Payable',
          debit: 0,
          credit: cartTax,
        },
        ...(cartServiceCharge > 0
          ? [
              {
                accountCode: '2030',
                accountName: 'Staff Tips & Gratuity Clearing',
                debit: 0,
                credit: cartServiceCharge,
              },
            ]
          : []),
      ],
    };

    const cogsEntry: JournalEntry = {
      id: `je-cogs-${Date.now()}`,
      entryNumber: `JE-${(Date.now() + 1).toString().slice(-6)}`,
      date: new Date().toISOString().replace('T', ' ').slice(0, 16),
      description: `COGS Recipe BOM Depletion for #${orderNumber}`,
      referenceType: 'POS_SALE',
      referenceId: orderNumber,
      totalDebit: totalCostOfGoods,
      totalCredit: totalCostOfGoods,
      createdBy: 'Automated BOM Engine',
      lines: [
        {
          accountCode: '5010',
          accountName: 'Cost of Goods Sold - Food Raw Ingredients',
          debit: totalCostOfGoods,
          credit: 0,
        },
        {
          accountCode: '1050',
          accountName: 'Food & Beverage Inventory Asset',
          debit: 0,
          credit: totalCostOfGoods,
        },
      ],
    };

    setJournalEntries((prev) => [salesEntry, cogsEntry, ...prev]);

    // Update account balances
    setAccounts((prev) =>
      prev.map((acc) => {
        if (acc.code === paymentAccountCode) {
          return { ...acc, balance: Number((acc.balance + cartTotal).toFixed(2)) };
        }
        if (acc.code === '4010') {
          return { ...acc, balance: Number((acc.balance + (cartSubtotal - cartDiscountAmount)).toFixed(2)) };
        }
        if (acc.code === '2020') {
          return { ...acc, balance: Number((acc.balance + cartTax).toFixed(2)) };
        }
        if (acc.code === '5010') {
          return { ...acc, balance: Number((acc.balance + totalCostOfGoods).toFixed(2)) };
        }
        if (acc.code === '1050') {
          return { ...acc, balance: Math.max(0, Number((acc.balance - totalCostOfGoods).toFixed(2))) };
        }
        return acc;
      })
    );

    clearCart();
    return { success: true, order: completedOrder };
  };

  const voidOrder = (orderId: string, reason: string) => {
    setOrders((prev) =>
      prev.map((ord) => (ord.id === orderId ? { ...ord, status: 'voided', discountReason: `VOID: ${reason}` } : ord))
    );
  };

  const updateKdsStatus = (orderId: string, status: 'queued' | 'cooking' | 'ready' | 'bumped') => {
    setOrders((prev) =>
      prev.map((ord) => {
        if (ord.id === orderId) {
          const orderStatus = status === 'cooking' ? 'preparing' : status === 'ready' ? 'ready' : ord.status;
          return { ...ord, kdsStatus: status, status: orderStatus };
        }
        return ord;
      })
    );
  };

  // Purchase Order Workflow
  const createPurchaseOrder = (
    supplierId: string,
    items: { ingredientId: string; quantity: number; unitPrice: number }[],
    notes?: string
  ): PurchaseOrder => {
    const supplier = suppliers.find((s) => s.id === supplierId);
    const supplierName = supplier ? supplier.name : 'Vendor';
    const totalAmount = items.reduce((sum, item) => sum + item.quantity * item.unitPrice, 0);

    const poNumber = `PO-${new Date().toISOString().slice(2, 10).replace(/-/g, '')}-${Math.floor(10 + Math.random() * 90)}`;
    const newPO: PurchaseOrder = {
      id: `po-${Date.now()}`,
      poNumber,
      supplierId,
      supplierName,
      items: items.map((it) => {
        const ing = ingredients.find((i) => i.id === it.ingredientId);
        return {
          ingredientId: it.ingredientId,
          ingredientName: ing ? ing.name : 'Item',
          quantity: it.quantity,
          unit: ing ? ing.unit : 'pcs',
          unitPrice: it.unitPrice,
          totalPrice: Number((it.quantity * it.unitPrice).toFixed(2)),
        };
      }),
      totalAmount: Number(totalAmount.toFixed(2)),
      status: 'submitted',
      orderDate: new Date().toISOString().slice(0, 10),
      expectedDeliveryDate: new Date(Date.now() + 86400000 * 2).toISOString().slice(0, 10),
      notes,
    };

    setPurchaseOrders((prev) => [newPO, ...prev]);
    return newPO;
  };

  const receivePurchaseOrder = (poId: string): boolean => {
    const po = purchaseOrders.find((p) => p.id === poId);
    if (!po || po.status === 'received') return false;

    // 1. Increase ingredient stocks
    const newTxList: InventoryTransaction[] = [];
    setIngredients((prev) =>
      prev.map((ing) => {
        const poItem = po.items.find((it) => it.ingredientId === ing.id);
        if (poItem) {
          const newStock = Number((ing.currentStock + poItem.quantity).toFixed(3));
          newTxList.push({
            id: `tx-recv-${Date.now()}-${ing.id}`,
            ingredientId: ing.id,
            ingredientName: ing.name,
            type: 'purchase_receipt',
            quantityDelta: poItem.quantity,
            unit: ing.unit,
            unitCost: poItem.unitPrice,
            reason: `PO #${po.poNumber} Receiving`,
            referenceId: po.poNumber,
            createdAt: new Date().toISOString().replace('T', ' ').slice(0, 16),
            staffName: 'Purchasing Manager',
          });
          return {
            ...ing,
            currentStock: newStock,
            costPerUnit: poItem.unitPrice, // update latest unit cost
            lastRestocked: new Date().toISOString().slice(0, 10),
          };
        }
        return ing;
      })
    );

    if (newTxList.length > 0) {
      setInventoryTransactions((prev) => [...newTxList, ...prev]);
    }

    // 2. Mark PO received
    setPurchaseOrders((prev) =>
      prev.map((p) =>
        p.id === poId ? { ...p, status: 'received', receivedDate: new Date().toISOString().slice(0, 10) } : p
      )
    );

    // 3. Update Supplier Balance Payable
    setSuppliers((prev) =>
      prev.map((s) => (s.id === po.supplierId ? { ...s, balancePayable: Number((s.balancePayable + po.totalAmount).toFixed(2)) } : s))
    );

    // 4. Accounting Journal Entry: Debit Inventory Asset, Credit Accounts Payable
    const poJournal: JournalEntry = {
      id: `je-po-${Date.now()}`,
      entryNumber: `JE-${Date.now().toString().slice(-6)}`,
      date: new Date().toISOString().replace('T', ' ').slice(0, 16),
      description: `Goods Receiving for PO #${po.poNumber} - ${po.supplierName}`,
      referenceType: 'PURCHASE_ORDER',
      referenceId: po.poNumber,
      totalDebit: po.totalAmount,
      totalCredit: po.totalAmount,
      createdBy: 'Purchasing Dept',
      lines: [
        {
          accountCode: '1050',
          accountName: 'Food & Beverage Inventory Asset',
          debit: po.totalAmount,
          credit: 0,
        },
        {
          accountCode: '2010',
          accountName: 'Accounts Payable (Vendors & Suppliers)',
          debit: 0,
          credit: po.totalAmount,
        },
      ],
    };

    setJournalEntries((prev) => [poJournal, ...prev]);

    // Update account balances
    setAccounts((prev) =>
      prev.map((acc) => {
        if (acc.code === '1050') return { ...acc, balance: Number((acc.balance + po.totalAmount).toFixed(2)) };
        if (acc.code === '2010') return { ...acc, balance: Number((acc.balance + po.totalAmount).toFixed(2)) };
        return acc;
      })
    );

    return true;
  };

  // Adjust stock
  const adjustStock = (
    ingredientId: string,
    quantityDelta: number,
    reason: string,
    type: 'waste_spoilage' | 'manual_adjustment'
  ) => {
    const ing = ingredients.find((i) => i.id === ingredientId);
    if (!ing) return;

    const newStock = Math.max(0, Number((ing.currentStock + quantityDelta).toFixed(3)));
    setIngredients((prev) =>
      prev.map((i) => (i.id === ingredientId ? { ...i, currentStock: newStock } : i))
    );

    const tx: InventoryTransaction = {
      id: `tx-adj-${Date.now()}`,
      ingredientId,
      ingredientName: ing.name,
      type,
      quantityDelta,
      unit: ing.unit,
      unitCost: ing.costPerUnit,
      reason,
      createdAt: new Date().toISOString().replace('T', ' ').slice(0, 16),
      staffName: 'Chef / Inventory Auditor',
    };

    setInventoryTransactions((prev) => [tx, ...prev]);
  };

  const addIngredient = (ingData: Omit<Ingredient, 'id' | 'lastRestocked'>) => {
    const newIng: Ingredient = {
      ...ingData,
      id: `ing-${Date.now()}`,
      lastRestocked: new Date().toISOString().slice(0, 10),
    };
    setIngredients((prev) => [...prev, newIng]);
  };

  // Record Expense Voucher
  const recordExpenseVoucher = (
    description: string,
    expenseAccountCode: string,
    paymentAccountCode: string,
    amount: number
  ) => {
    const expAcc = accounts.find((a) => a.code === expenseAccountCode);
    const payAcc = accounts.find((a) => a.code === paymentAccountCode);

    const entry: JournalEntry = {
      id: `je-exp-${Date.now()}`,
      entryNumber: `JE-${Date.now().toString().slice(-6)}`,
      date: new Date().toISOString().replace('T', ' ').slice(0, 16),
      description: `Expense Voucher: ${description}`,
      referenceType: 'EXPENSE_VOUCHER',
      totalDebit: amount,
      totalCredit: amount,
      createdBy: 'Finance Manager',
      lines: [
        {
          accountCode: expenseAccountCode,
          accountName: expAcc?.name || 'Expense',
          debit: amount,
          credit: 0,
        },
        {
          accountCode: paymentAccountCode,
          accountName: payAcc?.name || 'Cash / Bank',
          debit: 0,
          credit: amount,
        },
      ],
    };

    setJournalEntries((prev) => [entry, ...prev]);

    setAccounts((prev) =>
      prev.map((acc) => {
        if (acc.code === expenseAccountCode) return { ...acc, balance: Number((acc.balance + amount).toFixed(2)) };
        if (acc.code === paymentAccountCode) return { ...acc, balance: Number((acc.balance - amount).toFixed(2)) };
        return acc;
      })
    );
  };

  // Add Supplier
  const addSupplier = (supplierData: Omit<Supplier, 'id' | 'balancePayable'>) => {
    const newSup: Supplier = {
      ...supplierData,
      id: `sup-${Date.now()}`,
      balancePayable: 0,
    };
    setSuppliers((prev) => [...prev, newSup]);
  };

  // Pay Supplier
  const paySupplier = (supplierId: string, amount: number) => {
    setSuppliers((prev) =>
      prev.map((s) => (s.id === supplierId ? { ...s, balancePayable: Math.max(0, Number((s.balancePayable - amount).toFixed(2))) } : s))
    );

    // Accounting Entry: Debit Accounts Payable, Credit Bank
    const entry: JournalEntry = {
      id: `je-pay-${Date.now()}`,
      entryNumber: `JE-${Date.now().toString().slice(-6)}`,
      date: new Date().toISOString().replace('T', ' ').slice(0, 16),
      description: `Vendor Disbursement: Paid Supplier Invoice ($${amount.toFixed(2)})`,
      referenceType: 'MANUAL',
      totalDebit: amount,
      totalCredit: amount,
      createdBy: 'Accounts Payable',
      lines: [
        {
          accountCode: '2010',
          accountName: 'Accounts Payable (Vendors & Suppliers)',
          debit: amount,
          credit: 0,
        },
        {
          accountCode: '1020',
          accountName: 'Operating Bank Account (JPMorgan Chase)',
          debit: 0,
          credit: amount,
        },
      ],
    };

    setJournalEntries((prev) => [entry, ...prev]);
  };

  // Add Customer
  const addCustomer = (custData: Omit<Customer, 'id' | 'loyaltyPoints' | 'totalSpent' | 'visitCount' | 'joinedDate'>) => {
    const newCust: Customer = {
      ...custData,
      id: `cst-${Date.now()}`,
      loyaltyPoints: 50, // Welcome points
      totalSpent: 0,
      visitCount: 0,
      joinedDate: new Date().toISOString().slice(0, 10),
    };
    setCustomers((prev) => [...prev, newCust]);
  };

  // Toggle Clock-in
  const toggleClockInOut = (employeeId: string) => {
    setEmployees((prev) =>
      prev.map((emp) =>
        emp.id === employeeId
          ? {
              ...emp,
              isClockedIn: !emp.isClockedIn,
              currentShiftStarted: !emp.isClockedIn
                ? new Date().toISOString().replace('T', ' ').slice(0, 16)
                : undefined,
            }
          : emp
      )
    );
  };

  // Pay supplier balance alias
  const paySupplierBalance = (supplierId: string, amount: number) => {
    paySupplier(supplierId, amount);
  };

  // Reconcile cash register drawer
  const reconcileCashRegister = (actualCount: number, notes?: string) => {
    setCashRegister((prev) => {
      const discrepancy = actualCount - prev.expectedCash;
      const updated: CashRegisterSession = {
        ...prev,
        actualCashCounted: actualCount,
        discrepancy,
        paidOut: prev.cashOut,
        notes: notes || prev.notes,
        isClosed: true,
        closedAt: new Date().toISOString(),
      };
      localStorage.setItem('rest_erp_cash_register', JSON.stringify(updated));
      return updated;
    });
  };

  // Reset demo data
  const resetAllData = () => {
    localStorage.clear();
    setSettings(initialSettings);
    setTables(initialTables);
    setIngredients(initialIngredients);
    setInventoryTransactions([]);
    setOrders(initialOrders);
    setPurchaseOrders(initialPurchaseOrders);
    setSuppliers(initialSuppliers);
    setCustomers(initialCustomers);
    setEmployees(initialEmployees);
    setAccounts(initialAccounts);
    setJournalEntries(initialJournalEntries);
    setCashRegister(initialCashRegister);
    clearCart();
  };

  return (
    <RestaurantContext.Provider
      value={{
        language,
        setLanguage,
        t,
        activeModule,
        setActiveModule,
        settings,
        updateSettings,
        tables,
        menuItems,
        ingredients,
        inventoryTransactions,
        orders,
        purchaseOrders,
        suppliers,
        customers,
        employees,
        setEmployees,
        accounts,
        journalEntries,
        cashRegister,
        reconcileCashRegister,

        orderType,
        setOrderType,
        selectedTableId,
        setSelectedTableId,
        guestCount,
        setGuestCount,
        selectedCustomerId,
        setSelectedCustomerId,
        activeEmployeeId,
        setActiveEmployeeId,
        cart,
        discountPercent,
        setDiscountPercent,
        discountReason,
        setDiscountReason,

        addToCart,
        removeFromCart,
        updateCartQuantity,
        updateItemNotes,
        clearCart,
        cartSubtotal,
        cartTax,
        cartServiceCharge,
        cartDiscountAmount,
        cartTotal,

        sendOrderToKitchen,
        processCheckout,
        voidOrder,
        updateKdsStatus,

        createPurchaseOrder,
        receivePurchaseOrder,
        adjustStock,
        addIngredient,
        recordExpenseVoucher,
        addSupplier,
        paySupplier,
        paySupplierBalance,
        addCustomer,
        toggleClockInOut,
        resetAllData,
      }}
    >
      {children}
    </RestaurantContext.Provider>
  );
};

export const useRestaurant = () => {
  const context = useContext(RestaurantContext);
  if (!context) {
    throw new Error('useRestaurant must be used within a RestaurantProvider');
  }
  return context;
};
