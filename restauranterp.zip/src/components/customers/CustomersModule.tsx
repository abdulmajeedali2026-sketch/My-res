import React, { useState } from 'react';
import { useRestaurant } from '../../context/RestaurantContext';
import { Customer } from '../../types/erp';
import {
  Users,
  Search,
  Plus,
  Award,
  Phone,
  Mail,
  DollarSign,
  Heart,
  CheckCircle2,
  X,
  CreditCard,
} from 'lucide-react';

export const CustomersModule: React.FC = () => {
  const { customers, addCustomer, settings, language, t } = useRestaurant();
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  // New customer form
  const [name, setName] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [notes, setNotes] = useState<string>('');

  const getTierLabel = (tier: string) => {
    if (language !== 'ar') return tier;
    switch (tier) {
      case 'Platinum': return 'بلاتيني';
      case 'Gold': return 'ذهبي';
      case 'Silver': return 'فضي';
      case 'Bronze': return 'برونزي';
      default: return tier;
    }
  };

  const filteredCustomers = customers.filter(
    (c) =>
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.phone.includes(searchQuery) ||
      c.email.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleCreateCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !phone) return;

    addCustomer({
      name,
      phone,
      email: email || `${name.toLowerCase().replace(/\s+/g, '')}@example.com`,
      creditBalance: 0,
      tier: 'Bronze',
      notes,
    });

    setShowAddModal(false);
    setFeedback(
      language === 'ar'
        ? `تم إنشاء ملف العميل ${name} بنجاح مع إضافة 50 نقطة ولاء ترحيبية!`
        : `New customer profile created for ${name} with 50 welcome loyalty points!`
    );
    setName('');
    setPhone('');
    setEmail('');
    setNotes('');
    setTimeout(() => setFeedback(null), 4000);
  };

  return (
    <div className="flex-1 flex flex-col p-4 md:p-6 overflow-y-auto bg-slate-100">
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight">
            {t.customers.title}
          </h2>
          <p className="text-xs text-slate-500">
            {t.customers.subtitle}
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs shadow-md shadow-orange-200 transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>{t.customers.addCustomer}</span>
        </button>
      </div>

      {feedback && (
        <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 rounded-2xl text-emerald-800 text-xs font-semibold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{feedback}</span>
        </div>
      )}

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-6">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-xs text-slate-500 font-semibold block mb-1">
            {t.customers.totalCustomers}
          </span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black text-slate-900 font-mono">{customers.length}</span>
            <span className="text-xs text-slate-400 font-medium">{language === 'ar' ? 'عميل مسجل' : 'In CRM'}</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-xs text-slate-500 font-semibold block mb-1">
            {t.customers.vipMembers}
          </span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black text-amber-600 font-mono">
              {customers.filter((c) => c.tier === 'Platinum' || c.tier === 'Gold').length}
            </span>
            <span className="text-xs font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-md">
              {language === 'ar' ? 'فئة ذهبية وبلاتينية' : 'Gold & Platinum'}
            </span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-xs text-slate-500 font-semibold block mb-1">
            {t.customers.totalSpent}
          </span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black text-slate-900 font-mono">
              {settings.currencySymbol} {customers.reduce((s, c) => s + c.totalSpent, 0).toFixed(2)}
            </span>
            <span className="text-xs text-slate-400 font-medium">{language === 'ar' ? 'إجمالي المشتريات' : 'All Time'}</span>
          </div>
        </div>
      </div>

      {/* Customer List */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden flex-1 flex flex-col">
        {/* Search */}
        <div className="p-4 border-b border-slate-200/80">
          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 absolute start-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder={language === 'ar' ? 'بحث بالاسم، رقم الهاتف أو البريد...' : 'Search by name, phone or email...'}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full ps-9 pe-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-hidden focus:border-orange-500"
            />
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto flex-1">
          <table className="w-full text-start border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider text-[10px]">
                <th className="py-3 px-4">{t.customers.name}</th>
                <th className="py-3 px-4">{language === 'ar' ? 'بيانات التواصل' : 'Contact'}</th>
                <th className="py-3 px-4">{t.customers.tier}</th>
                <th className="py-3 px-4">{t.customers.loyaltyPoints}</th>
                <th className="py-3 px-4">{t.customers.visits}</th>
                <th className="py-3 px-4">{t.customers.totalSpent}</th>
                <th className="py-3 px-4">{t.customers.creditBalance}</th>
                <th className="py-3 px-4">{language === 'ar' ? 'التفضيلات والحساسية الغذائية' : 'Preferences / Allergies'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredCustomers.map((c) => (
                <tr key={c.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-3.5 px-4 font-bold text-slate-900">{c.name}</td>
                  <td className="py-3.5 px-4 text-slate-500 space-y-0.5">
                    <div className="flex items-center gap-1">
                      <Phone className="w-3 h-3 text-slate-400" />
                      <span className="font-mono">{c.phone}</span>
                    </div>
                    <div className="flex items-center gap-1 text-[11px]">
                      <Mail className="w-3 h-3 text-slate-400" />
                      <span>{c.email}</span>
                    </div>
                  </td>
                  <td className="py-3.5 px-4">
                    <span
                      className={`text-[10px] font-extrabold px-2.5 py-0.5 rounded-full inline-flex items-center gap-1 ${
                        c.tier === 'Platinum'
                          ? 'bg-slate-900 text-amber-400 border border-slate-700'
                          : c.tier === 'Gold'
                          ? 'bg-amber-100 text-amber-900 border border-amber-300'
                          : c.tier === 'Silver'
                          ? 'bg-slate-100 text-slate-800'
                          : 'bg-orange-100 text-orange-900'
                      }`}
                    >
                      <Award className="w-3 h-3" />
                      {getTierLabel(c.tier)}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 font-mono font-bold text-amber-700">
                    {c.loyaltyPoints} {language === 'ar' ? 'نقطة' : 'pts'}
                  </td>
                  <td className="py-3.5 px-4 font-mono">{c.visitCount} {language === 'ar' ? 'زيارة' : 'visits'}</td>
                  <td className="py-3.5 px-4 font-mono font-extrabold text-slate-900">
                    {settings.currencySymbol} {c.totalSpent.toFixed(2)}
                  </td>
                  <td className="py-3.5 px-4 font-mono font-bold text-emerald-700">
                    {settings.currencySymbol} {c.creditBalance.toFixed(2)}
                  </td>
                  <td className="py-3.5 px-4 text-slate-600 max-w-xs truncate">
                    {c.notes || '—'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Customer Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h3 className="font-extrabold text-base text-slate-900">{t.customers.newCustomerModal}</h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateCustomer} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">{t.customers.name}:</label>
                <input
                  type="text"
                  placeholder={language === 'ar' ? 'مثال: نورة المطيري' : 'e.g. Eleanor Vance'}
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-start"
                  required
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">{t.customers.phone}:</label>
                <input
                  type="tel"
                  placeholder={language === 'ar' ? 'مثال: 0501234567' : 'e.g. +1 (555) 234-5678'}
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-mono text-start"
                  required
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">{t.customers.email} ({language === 'ar' ? 'اختياري' : 'Optional'}):</label>
                <input
                  type="email"
                  placeholder="e.g. customer@example.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-start"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">{language === 'ar' ? 'التفضيلات والملاحظات:' : 'Dietary Notes / VIP Preferences:'}</label>
                <input
                  type="text"
                  placeholder={language === 'ar' ? 'مثال: بدون جلوتين، يفضل طاولة هادئة...' : 'e.g. Gluten sensitive, prefers quiet booth Table 04...'}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-start"
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 py-2.5 border rounded-xl font-bold text-slate-600"
                >
                  {t.common.cancel}
                </button>
                <button
                  type="submit"
                  className="flex-2 py-2.5 bg-orange-500 hover:bg-orange-600 text-white rounded-xl font-bold"
                >
                  {t.customers.saveCustomer}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
