import React, { useState } from 'react';
import { useRestaurant } from '../../context/RestaurantContext';
import { PurchaseOrder } from '../../types/erp';
import {
  Truck,
  Plus,
  CheckCircle2,
  Clock,
  Building2,
  Boxes,
  FileText,
  DollarSign,
  AlertCircle,
  X,
  Sparkles,
} from 'lucide-react';

export const PurchasesModule: React.FC = () => {
  const {
    purchaseOrders,
    suppliers,
    ingredients,
    createPurchaseOrder,
    receivePurchaseOrder,
    settings,
    language,
    t,
  } = useRestaurant();

  const [showCreateModal, setShowCreateModal] = useState<boolean>(false);
  const [selectedSupplierId, setSelectedSupplierId] = useState<string>(suppliers[0]?.id || '');
  const [poItems, setPoItems] = useState<{ ingredientId: string; quantity: number; unitPrice: number }[]>([
    { ingredientId: ingredients[0]?.id || '', quantity: 10, unitPrice: ingredients[0]?.costPerUnit || 10 },
  ]);
  const [poNotes, setPoNotes] = useState<string>('');
  const [feedback, setFeedback] = useState<string | null>(null);

  const handleAddItemRow = () => {
    setPoItems((prev) => [
      ...prev,
      {
        ingredientId: ingredients[0]?.id || '',
        quantity: 5,
        unitPrice: ingredients[0]?.costPerUnit || 10,
      },
    ]);
  };

  const handleRemoveItemRow = (idx: number) => {
    setPoItems((prev) => prev.filter((_, i) => i !== idx));
  };

  const handleCreatePo = (e: React.FormEvent) => {
    e.preventDefault();
    if (poItems.length === 0) return;

    const po = createPurchaseOrder(selectedSupplierId, poItems, poNotes);
    setShowCreateModal(false);
    setFeedback(
      language === 'ar'
        ? `تم إنشاء أمر الشراء #${po.poNumber} بنجاح وإرساله للمورد.`
        : `Purchase Order #${po.poNumber} created and submitted to vendor.`
    );
    setTimeout(() => setFeedback(null), 4000);
  };

  const handleReceivePo = (poId: string, poNum: string) => {
    const success = receivePurchaseOrder(poId);
    if (success) {
      setFeedback(
        language === 'ar'
          ? `تم استلام أمر الشراء #${poNum}! تم تحديث كميات المخزون وترحيل قيد الموردين في دفتر الأستاذ.`
          : `PO #${poNum} marked as received! Raw ingredients replenished and AP ledger updated.`
      );
      setTimeout(() => setFeedback(null), 5000);
    }
  };

  const totalPoSpend = purchaseOrders.reduce((sum, p) => sum + p.totalAmount, 0);
  const pendingCount = purchaseOrders.filter((p) => p.status === 'submitted').length;

  const getStatusLabel = (status: string) => {
    if (language === 'ar') {
      switch (status) {
        case 'received': return t.purchases.received;
        case 'submitted': return 'مرسل للمورد';
        case 'draft': return t.purchases.draft;
        case 'cancelled': return t.purchases.cancelled;
        default: return status;
      }
    }
    return status;
  };

  return (
    <div className="flex-1 flex flex-col p-4 md:p-6 overflow-y-auto bg-slate-100">
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight">
            {t.purchases.title}
          </h2>
          <p className="text-xs text-slate-500">
            {t.purchases.subtitle}
          </p>
        </div>

        <button
          onClick={() => setShowCreateModal(true)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs shadow-md shadow-orange-200 transition-all"
        >
          <Plus className="w-4 h-4" />
          <span>{t.purchases.createPO}</span>
        </button>
      </div>

      {/* Success notification */}
      {feedback && (
        <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 rounded-2xl text-emerald-800 text-xs font-semibold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{feedback}</span>
        </div>
      )}

      {/* Summary KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-6">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-xs text-slate-500 font-semibold block mb-1">
            {language === 'ar' ? 'إجمالي أوامر الشراء' : 'Total Procurement POs'}
          </span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black text-slate-900 font-mono">{purchaseOrders.length}</span>
            <span className="text-xs text-slate-400 font-medium">{language === 'ar' ? 'أمر توريد' : 'Orders'}</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-xs text-slate-500 font-semibold block mb-1">
            {t.purchases.pendingDeliveries}
          </span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black text-amber-600 font-mono">{pendingCount}</span>
            <span className="text-xs text-amber-700 bg-amber-50 px-2 py-0.5 rounded-md font-bold">
              {language === 'ar' ? 'بانتظار الاستلام' : 'Awaiting Goods'}
            </span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-xs text-slate-500 font-semibold block mb-1">
            {t.purchases.totalPurchases}
          </span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black text-slate-900 font-mono">
              {settings.currencySymbol} {totalPoSpend.toFixed(2)}
            </span>
            <span className="text-xs text-slate-400 font-medium">
              {language === 'ar' ? 'توريدات مواد خام' : 'Raw Ingredients'}
            </span>
          </div>
        </div>
      </div>

      {/* Purchase Orders Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden flex-1 flex flex-col">
        <div className="p-4 border-b border-slate-200/80">
          <h3 className="font-extrabold text-sm text-slate-900">
            {language === 'ar' ? 'سجل أوامر الشراء والتوريد' : 'Purchase Orders Register'}
          </h3>
        </div>

        <div className="overflow-x-auto flex-1">
          <table className="w-full text-start border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider text-[10px]">
                <th className="py-3 px-4">{t.purchases.poNumber}</th>
                <th className="py-3 px-4">{t.purchases.supplier}</th>
                <th className="py-3 px-4">{t.purchases.date}</th>
                <th className="py-3 px-4">{language === 'ar' ? 'التسليم المتوقع' : 'Expected Delivery'}</th>
                <th className="py-3 px-4">{language === 'ar' ? 'بنود المواد' : 'Line Items'}</th>
                <th className="py-3 px-4">{t.purchases.totalAmount}</th>
                <th className="py-3 px-4">{t.purchases.status}</th>
                <th className="py-3 px-4 text-end">{language === 'ar' ? 'إجراء الاستلام' : 'Receiving Action'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {purchaseOrders.map((po) => (
                <tr key={po.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-3.5 px-4 font-mono font-bold text-slate-900">{po.poNumber}</td>
                  <td className="py-3.5 px-4 font-medium text-slate-800 flex items-center gap-1.5">
                    <Building2 className="w-3.5 h-3.5 text-slate-400" />
                    <span>{po.supplierName}</span>
                  </td>
                  <td className="py-3.5 px-4 font-mono text-slate-500">{po.orderDate}</td>
                  <td className="py-3.5 px-4 font-mono text-slate-500">{po.expectedDeliveryDate}</td>
                  <td className="py-3.5 px-4">
                    <div className="space-y-0.5">
                      {po.items.map((item, i) => {
                        const ing = ingredients.find((x) => x.id === item.ingredientId);
                        const displayName = (language === 'ar' && ing?.nameAr) ? ing.nameAr : item.ingredientName;
                        const unitName = (language === 'ar' && ing?.unitAr) ? ing.unitAr : item.unit;

                        return (
                          <div key={i} className="text-[11px] text-slate-600">
                            {item.quantity} {unitName} &times; {displayName}
                          </div>
                        );
                      })}
                    </div>
                  </td>
                  <td className="py-3.5 px-4 font-mono font-extrabold text-slate-900">
                    {settings.currencySymbol} {po.totalAmount.toFixed(2)}
                  </td>
                  <td className="py-3.5 px-4">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full capitalize ${
                        po.status === 'received'
                          ? 'bg-emerald-100 text-emerald-800'
                          : po.status === 'submitted'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {getStatusLabel(po.status)}
                    </span>
                  </td>
                  <td className="py-3.5 px-4 text-end">
                    {po.status === 'submitted' ? (
                      <button
                        onClick={() => handleReceivePo(po.id, po.poNumber)}
                        className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1.5 ms-auto shadow-xs transition-colors"
                        title={t.purchases.receiveStock}
                      >
                        <Boxes className="w-3.5 h-3.5" />
                        <span>{t.purchases.receiveStock}</span>
                      </button>
                    ) : (
                      <span className="text-[11px] font-medium text-emerald-700 flex items-center justify-end gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" /> {language === 'ar' ? `بالمخزون (${po.receivedDate})` : `In Stock (${po.receivedDate})`}
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* New Purchase Order Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 shadow-2xl border border-slate-200 flex flex-col max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <div>
                <h3 className="font-extrabold text-base text-slate-900">
                  {t.purchases.newPurchaseOrder}
                </h3>
                <p className="text-xs text-slate-500">
                  {language === 'ar' ? 'طلب مواد خام وتوريد مباشر من الموردين المعتمدين' : 'Procure raw ingredients directly from approved suppliers'}
                </p>
              </div>
              <button
                onClick={() => setShowCreateModal(false)}
                className="w-8 h-8 rounded-full bg-slate-100 text-slate-500 hover:text-slate-900 flex items-center justify-center"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreatePo} className="space-y-4 text-xs">
              {/* Supplier Selection */}
              <div>
                <label className="font-bold text-slate-700 block mb-1">{t.purchases.selectSupplier}:</label>
                <select
                  value={selectedSupplierId}
                  onChange={(e) => setSelectedSupplierId(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-medium text-slate-800 focus:outline-hidden focus:border-orange-500 text-start"
                >
                  {suppliers.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.category} &bull; {language === 'ar' ? 'شروط الدفع:' : 'Terms:'} {s.paymentTerms})
                    </option>
                  ))}
                </select>
              </div>

              {/* Line Items */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="font-bold text-slate-700">{language === 'ar' ? 'المواد الخام والكميات المطلوبة:' : 'Raw Ingredients & Quantities:'}</label>
                  <button
                    type="button"
                    onClick={handleAddItemRow}
                    className="text-xs text-orange-600 font-bold hover:underline flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" /> {t.purchases.addItem}
                  </button>
                </div>

                <div className="space-y-2 max-h-56 overflow-y-auto pe-1">
                  {poItems.map((item, idx) => {
                    const ing = ingredients.find((i) => i.id === item.ingredientId);
                    const unitName = (language === 'ar' && ing?.unitAr) ? ing.unitAr : ing?.unit || 'وحدة';
                    return (
                      <div
                        key={idx}
                        className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-50 border border-slate-200"
                      >
                        <select
                          value={item.ingredientId}
                          onChange={(e) => {
                            const newIngId = e.target.value;
                            const newIng = ingredients.find((i) => i.id === newIngId);
                            setPoItems((prev) =>
                              prev.map((it, i) =>
                                i === idx
                                  ? {
                                      ...it,
                                      ingredientId: newIngId,
                                      unitPrice: newIng?.costPerUnit || it.unitPrice,
                                    }
                                  : it
                              )
                            );
                          }}
                          className="flex-2 p-1.5 bg-white border border-slate-200 rounded-lg text-xs text-start"
                        >
                          {ingredients.map((ingItem) => (
                            <option key={ingItem.id} value={ingItem.id}>
                              {(language === 'ar' && ingItem.nameAr) ? ingItem.nameAr : ingItem.name} ({(language === 'ar' && ingItem.unitAr) ? ingItem.unitAr : ingItem.unit})
                            </option>
                          ))}
                        </select>

                        <div className="flex-1 flex items-center gap-1">
                          <input
                            type="number"
                            step="0.1"
                            min="0.1"
                            value={item.quantity}
                            onChange={(e) => {
                              const val = parseFloat(e.target.value) || 0;
                              setPoItems((prev) =>
                                prev.map((it, i) => (i === idx ? { ...it, quantity: val } : it))
                              );
                            }}
                            className="w-full p-1.5 bg-white border border-slate-200 rounded-lg text-xs text-end font-mono"
                          />
                          <span className="text-[11px] text-slate-500 whitespace-nowrap">{unitName}</span>
                        </div>

                        <div className="flex-1 flex items-center gap-1">
                          <span className="text-slate-400 font-bold">{settings.currencySymbol}</span>
                          <input
                            type="number"
                            step="0.01"
                            min="0"
                            value={item.unitPrice}
                            onChange={(e) => {
                              const val = parseFloat(e.target.value) || 0;
                              setPoItems((prev) =>
                                prev.map((it, i) => (i === idx ? { ...it, unitPrice: val } : it))
                              );
                            }}
                            className="w-full p-1.5 bg-white border border-slate-200 rounded-lg text-xs text-end font-mono"
                          />
                        </div>

                        <span className="w-20 text-end font-mono font-bold text-slate-900 whitespace-nowrap">
                          {settings.currencySymbol} {(item.quantity * item.unitPrice).toFixed(2)}
                        </span>

                        {poItems.length > 1 && (
                          <button
                            type="button"
                            onClick={() => handleRemoveItemRow(idx)}
                            className="w-6 h-6 rounded flex items-center justify-center text-slate-400 hover:text-rose-600"
                          >
                            &times;
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Notes */}
              <div>
                <label className="font-bold text-slate-700 block mb-1">{language === 'ar' ? 'ملاحظات وتعليمات التسليم:' : 'Delivery Notes / Instructions:'}</label>
                <input
                  type="text"
                  placeholder={language === 'ar' ? 'مثال: التوصيل لبوابة المطبخ الخلفية قبل الساعة 9 صباحاً...' : 'e.g. Deliver to back kitchen loading bay before 9:00 AM...'}
                  value={poNotes}
                  onChange={(e) => setPoNotes(e.target.value)}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-start"
                />
              </div>

              {/* Total Summary */}
              <div className="p-3 bg-orange-50 border border-orange-200 rounded-2xl flex items-center justify-between">
                <span className="font-bold text-orange-900">{language === 'ar' ? 'إجمالي تكلفة أمر الشراء المتوقعة:' : 'Estimated Total Order Cost:'}</span>
                <span className="font-mono text-xl font-black text-orange-600">
                  {settings.currencySymbol} {poItems
                    .reduce((sum, it) => sum + it.quantity * it.unitPrice, 0)
                    .toFixed(2)}
                </span>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="flex-1 py-2.5 border rounded-xl font-bold text-slate-600"
                >
                  {t.common.cancel}
                </button>
                <button
                  type="submit"
                  className="flex-2 py-2.5 bg-orange-500 hover:bg-orange-600 text-white rounded-xl font-bold"
                >
                  {t.purchases.savePO}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
