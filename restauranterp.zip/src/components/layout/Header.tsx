import React from 'react';
import { useRestaurant } from '../../context/RestaurantContext';
import { ErpModule } from '../../types/erp';
import {
  UtensilsCrossed,
  Layers,
  ChefHat,
  Database,
  Clock,
  DollarSign,
  AlertTriangle,
  UserCheck,
  UserX,
  Globe,
} from 'lucide-react';

interface HeaderProps {
  activeModule?: ErpModule;
  setActiveModule?: (module: ErpModule) => void;
  onOpenKds?: () => void;
  openKds?: () => void;
  onOpenRegister?: () => void;
  openArchitecture?: () => void;
  onOpenArchitecture?: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeModule: propActiveModule,
  setActiveModule: propSetActiveModule,
  onOpenKds,
  openKds,
  onOpenRegister,
  openArchitecture,
  onOpenArchitecture,
}) => {
  const context = useRestaurant();
  const setActiveModule = propSetActiveModule ?? context.setActiveModule;
  const handleOpenKds = onOpenKds || openKds || (() => {});
  const handleOpenArchitecture = onOpenArchitecture || openArchitecture || (() => setActiveModule('architecture'));

  const {
    settings,
    cashRegister,
    ingredients,
    orders,
    employees,
    activeEmployeeId,
    setActiveEmployeeId,
    toggleClockInOut,
    language,
    setLanguage,
    t,
  } = context;

  const activeEmployee = employees.find((e) => e.id === activeEmployeeId) || employees[0];
  const lowStockCount = ingredients.filter((i) => i.currentStock <= i.reorderLevel).length;
  const activeKdsCount = orders.filter(
    (o) => o.status === 'preparing' || o.status === 'ready' || o.kdsStatus === 'cooking'
  ).length;

  const toggleLanguage = () => {
    setLanguage(language === 'ar' ? 'en' : 'ar');
  };

  return (
    <header className="h-16 bg-white border-b border-slate-200 px-4 md:px-6 flex items-center justify-between sticky top-0 z-30 shadow-xs">
      {/* Brand & Branch */}
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-600 to-orange-500 flex items-center justify-center text-white shadow-sm shadow-orange-200">
          <UtensilsCrossed className="w-5 h-5" />
        </div>
        <div>
          <div className="flex items-center gap-2">
            <h1 className="font-bold text-slate-900 text-base leading-tight tracking-tight">
              {settings.restaurantName}
            </h1>
            <span className="inline-flex items-center gap-1 text-[11px] font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200/60 px-1.5 py-0.5 rounded-md">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
              {language === 'ar' ? 'نظام حي' : 'Live POS'}
            </span>
          </div>
          <p className="text-xs text-slate-500 font-medium">
            ASP.NET Core Web API &bull; SQL Server &bull; {language === 'ar' ? 'نقطة البيع السحابية' : 'Web POS'}
          </p>
        </div>
      </div>

      {/* Center / Fast Actions */}
      <div className="hidden lg:flex items-center gap-2.5">
        {/* Till Balance */}
        <button
          onClick={onOpenRegister}
          className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-50 hover:bg-slate-100 border border-slate-200 text-xs transition-colors cursor-pointer"
          title={t.header.openRegister}
        >
          <DollarSign className="w-4 h-4 text-emerald-600" />
          <span className="text-slate-600 font-medium">{t.header.tillBalance}:</span>
          <span className="font-bold text-slate-900 font-mono">
            {settings.currencySymbol} {cashRegister.expectedCash.toFixed(2)}
          </span>
        </button>

        {/* KDS Button */}
        <button
          onClick={handleOpenKds}
          className="relative flex items-center gap-2 px-3 py-1.5 rounded-lg bg-amber-50 hover:bg-amber-100/80 border border-amber-200 text-amber-900 text-xs font-semibold transition-colors"
          title={t.header.openKds}
        >
          <ChefHat className="w-4 h-4 text-amber-700" />
          <span>{t.header.openKds}</span>
          {activeKdsCount > 0 && (
            <span className="w-5 h-5 rounded-full bg-amber-600 text-white text-[10px] font-bold flex items-center justify-center">
              {activeKdsCount}
            </span>
          )}
        </button>

        {/* Architecture & SQL Hub Button */}
        <button
          onClick={handleOpenArchitecture}
          className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-indigo-50 hover:bg-indigo-100/80 border border-indigo-200 text-indigo-900 text-xs font-semibold transition-colors"
          title={t.header.architectureHub}
        >
          <Database className="w-4 h-4 text-indigo-600" />
          <span>{t.header.architectureHub}</span>
          <span className="bg-indigo-600 text-white text-[10px] font-bold px-1.5 py-0.5 rounded">
            C# / SQL
          </span>
        </button>
      </div>

      {/* Right User, Language Switcher & Status */}
      <div className="flex items-center gap-2.5">
        {/* Language Switcher */}
        <button
          onClick={toggleLanguage}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-all border border-slate-200 shadow-2xs"
          title="تبديل اللغة / Switch Language"
        >
          <Globe className="w-3.5 h-3.5 text-slate-600" />
          <span>{t.toggleLang}</span>
        </button>

        {/* Low stock alert badge */}
        {lowStockCount > 0 && (
          <button
            onClick={() => setActiveModule('inventory')}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-rose-50 text-rose-700 border border-rose-200 text-xs font-medium hover:bg-rose-100 transition-colors"
            title={`${lowStockCount} ${t.header.lowStockWarning}`}
          >
            <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
            <span className="font-bold">{lowStockCount} {t.header.lowStockWarning}</span>
          </button>
        )}

        {/* Active Staff Selector & Clock */}
        <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 p-1 rounded-xl">
          <div className="flex items-center gap-1.5 px-2">
            <div className="w-7 h-7 rounded-lg bg-slate-800 text-white text-xs font-bold flex items-center justify-center">
              {activeEmployee.name.charAt(0)}
            </div>
            <div className="hidden sm:block text-start">
              <select
                value={activeEmployeeId}
                onChange={(e) => setActiveEmployeeId(e.target.value)}
                className="text-xs font-bold text-slate-800 bg-transparent border-0 p-0 focus:ring-0 cursor-pointer"
              >
                {employees.map((emp) => (
                  <option key={emp.id} value={emp.id}>
                    {emp.name} ({emp.role})
                  </option>
                ))}
              </select>
              <div className="flex items-center gap-1 text-[10px] text-slate-500 font-medium">
                {activeEmployee.isClockedIn ? (
                  <span className="text-emerald-600 font-semibold flex items-center gap-0.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span> {t.header.clockedIn}
                  </span>
                ) : (
                  <span className="text-slate-400 font-semibold flex items-center gap-0.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-slate-400"></span> {t.header.clockedOut}
                  </span>
                )}
              </div>
            </div>
          </div>

          <button
            onClick={() => toggleClockInOut(activeEmployee.id)}
            className={`p-1.5 rounded-lg text-xs font-medium transition-colors ${
              activeEmployee.isClockedIn
                ? 'bg-amber-100 text-amber-800 hover:bg-amber-200'
                : 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
            }`}
            title={activeEmployee.isClockedIn ? t.header.clockOut : t.header.clockIn}
          >
            {activeEmployee.isClockedIn ? (
              <UserX className="w-3.5 h-3.5" />
            ) : (
              <UserCheck className="w-3.5 h-3.5" />
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
