import React, { useState } from 'react';
import { useRestaurant } from '../../context/RestaurantContext';
import {
  DollarSign,
  X,
  Banknote,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  Receipt,
  Scale,
} from 'lucide-react';

interface RegisterModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const RegisterModal: React.FC<RegisterModalProps> = ({ isOpen, onClose }) => {
  const { cashRegister, settings, reconcileCashRegister } = useRestaurant();
  const [actualCount, setActualCount] = useState<string>(
    cashRegister.expectedCash.toFixed(2)
  );
  const [notes, setNotes] = useState<string>('');
  const [feedback, setFeedback] = useState<string | null>(null);

  if (!isOpen) return null;

  const countNum = parseFloat(actualCount) || 0;
  const variance = countNum - cashRegister.expectedCash;

  const handleReconcile = (e: React.FormEvent) => {
    e.preventDefault();
    reconcileCashRegister(countNum, notes);
    setFeedback('Cash register drawer reconciled and session logged in audit ledger.');
    setTimeout(() => {
      setFeedback(null);
      onClose();
    }, 2000);
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-800 flex items-center justify-center">
              <DollarSign className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-slate-900">
                Cash Register Drawer Till
              </h3>
              <p className="text-[11px] text-slate-500">
                Opening float & end-of-shift reconciliation
              </p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-600">
            <X className="w-4 h-4" />
          </button>
        </div>

        {feedback && (
          <div className="mb-3 p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>{feedback}</span>
          </div>
        )}

        <div className="space-y-3 text-xs mb-4">
          <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 space-y-2">
            <div className="flex justify-between text-slate-600">
              <span>Opening Float (Cash In):</span>
              <span className="font-mono font-bold text-slate-900">
                ${cashRegister.openingFloat.toFixed(2)}
              </span>
            </div>
            <div className="flex justify-between text-slate-600">
              <span>Today's Cash Sales:</span>
              <span className="font-mono font-bold text-emerald-600">
                +${cashRegister.cashSales.toFixed(2)}
              </span>
            </div>
            <div className="flex justify-between text-slate-600">
              <span>Paid Out / Petty Cash:</span>
              <span className="font-mono font-bold text-slate-700">
                -${(cashRegister.paidOut ?? cashRegister.cashOut ?? 0).toFixed(2)}
              </span>
            </div>
            <div className="flex justify-between pt-2 border-t border-slate-200 font-extrabold text-sm text-slate-950">
              <span>Expected Cash in Drawer:</span>
              <span className="font-mono text-orange-600">
                ${cashRegister.expectedCash.toFixed(2)}
              </span>
            </div>
          </div>

          <form onSubmit={handleReconcile} className="space-y-3">
            <div>
              <label className="font-bold text-slate-700 block mb-1">
                Actual Physical Cash Count ($):
              </label>
              <input
                type="number"
                step="0.01"
                value={actualCount}
                onChange={(e) => setActualCount(e.target.value)}
                className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono text-base font-bold text-right"
                required
              />
            </div>

            {/* Variance indicator */}
            <div
              className={`p-2.5 rounded-xl border flex items-center justify-between text-xs font-bold ${
                Math.abs(variance) < 0.01
                  ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                  : variance > 0
                  ? 'bg-blue-50 border-blue-200 text-blue-800'
                  : 'bg-rose-50 border-rose-200 text-rose-800'
              }`}
            >
              <span>Cash Variance:</span>
              <span className="font-mono text-sm">
                {variance > 0 ? `+$${variance.toFixed(2)} (Overage)` : variance < 0 ? `-$${Math.abs(variance).toFixed(2)} (Shortage)` : '$0.00 (Balanced)'}
              </span>
            </div>

            <div>
              <label className="font-bold text-slate-700 block mb-1">
                Shift Reconciliation Notes:
              </label>
              <input
                type="text"
                placeholder="e.g. End of dinner shift close, counted by Jane..."
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl"
              />
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-2.5 border rounded-xl font-bold text-slate-600 text-xs"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex-2 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-bold text-xs flex items-center justify-center gap-1.5"
              >
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Save Drawer Reconciliation</span>
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};
