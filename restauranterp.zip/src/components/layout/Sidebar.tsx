import React from 'react';
import { useRestaurant } from '../../context/RestaurantContext';
import { ErpModule } from '../../types/erp';
import {
  CreditCard,
  ShoppingBag,
  Truck,
  Boxes,
  Calculator,
  Users,
  Building2,
  UserCog,
  BarChart3,
  Settings,
  Database,
  ChevronRight,
  ChefHat,
} from 'lucide-react';

interface SidebarProps {
  activeModule?: ErpModule;
  setActiveModule?: (module: ErpModule) => void;
  onOpenKds?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeModule: propActiveModule,
  setActiveModule: propSetActiveModule,
  onOpenKds,
}) => {
  const context = useRestaurant();
  const activeModule = propActiveModule ?? context.activeModule;
  const setActiveModule = propSetActiveModule ?? context.setActiveModule;
  const { t, language } = context;

  const menuItems: { id: ErpModule; label: string; icon: React.ComponentType<{ className?: string }>; badge?: string }[] = [
    { id: 'pos', label: t.nav.pos, icon: CreditCard, badge: t.nav.activeBadge },
    { id: 'sales', label: t.nav.sales, icon: ShoppingBag },
    { id: 'purchases', label: t.nav.purchases, icon: Truck },
    { id: 'inventory', label: t.nav.inventory, icon: Boxes },
    { id: 'accounting', label: t.nav.accounting, icon: Calculator },
    { id: 'customers', label: t.nav.customers, icon: Users },
    { id: 'suppliers', label: t.nav.suppliers, icon: Building2 },
    { id: 'employees', label: t.nav.employees, icon: UserCog },
    { id: 'reports', label: t.nav.reports, icon: BarChart3 },
    { id: 'settings', label: t.nav.settings, icon: Settings },
  ];

  return (
    <aside className="w-64 bg-slate-900 text-slate-300 flex flex-col flex-shrink-0 select-none border-r border-slate-800 rtl:border-r-0 rtl:border-l">
      {/* ERP Tree Indicator */}
      <div className="p-4 border-b border-slate-800/80">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-orange-500"></span>
          <span className="text-[11px] font-mono uppercase tracking-wider text-slate-400 font-semibold">
            {language === 'ar' ? 'نظام نقطة البيع والعمليات ERP' : 'Frontend / Web POS'}
          </span>
        </div>
      </div>

      {/* Main Navigation */}
      <nav className="flex-1 overflow-y-auto p-3 space-y-1">
        <div className="px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-500 font-mono">
          {language === 'ar' ? 'الوحدات والأنظمة الرئيسية' : 'ERP Core Modules'}
        </div>
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeModule === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveModule(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all group ${
                isActive
                  ? 'bg-orange-500 text-white shadow-sm shadow-orange-900/30'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon
                  className={`w-4 h-4 transition-colors ${
                    isActive ? 'text-white' : 'text-slate-400 group-hover:text-slate-200'
                  }`}
                />
                <span>{item.label}</span>
              </div>
              {item.badge && (
                <span
                  className={`text-[10px] font-bold px-1.5 py-0.5 rounded-md ${
                    isActive
                      ? 'bg-orange-600 text-white'
                      : 'bg-emerald-950 text-emerald-400 border border-emerald-800/60'
                  }`}
                >
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}

        {/* Backend & DB Section */}
        <div className="pt-4 px-3 py-1.5 text-[10px] font-bold uppercase tracking-wider text-slate-500 font-mono">
          {language === 'ar' ? 'قاعدة البيانات ومعمارية C#' : 'Architecture & Database'}
        </div>
        <button
          onClick={() => setActiveModule('architecture')}
          className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all group ${
            activeModule === 'architecture'
              ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-900/30'
              : 'text-indigo-300 bg-indigo-950/30 hover:bg-indigo-900/50 hover:text-white border border-indigo-900/40'
          }`}
        >
          <div className="flex items-center gap-3">
            <Database className="w-4 h-4 text-indigo-400" />
            <div className="text-start">
              <span className="block font-bold">{t.nav.architecture}</span>
              <span className="text-[10px] text-slate-400 font-normal">C# API & T-SQL Schema</span>
            </div>
          </div>
          <ChevronRight className="w-3.5 h-3.5 opacity-60 rtl:rotate-180" />
        </button>
      </nav>

      {/* System Status Footer */}
      <div className="p-3 m-3 rounded-xl bg-slate-800/80 border border-slate-700/60 text-xs">
        <div className="flex items-center justify-between text-slate-400 text-[11px] mb-1">
          <span>{language === 'ar' ? 'حالة الواجهة الخلفية' : 'Backend Status'}</span>
          <span className="text-emerald-400 font-semibold flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
            {language === 'ar' ? 'متصل بنجاح' : 'Connected'}
          </span>
        </div>
        <div className="text-[11px] font-mono text-slate-300">
          SQL Server 2022 &bull; .NET 9 Web API
        </div>
      </div>
    </aside>
  );
};
