import React, { useState } from 'react';
import { useRestaurant } from '../../context/RestaurantContext';
import { aspNetCodeFiles } from '../../mockData/aspnetCode';
import {
  sqlServerTables,
  generateCreateTableSql,
  SchemaTable,
} from '../../mockData/sqlServerSchema';
import {
  Database,
  Server,
  FolderTree,
  FileCode,
  Check,
  Copy,
  Terminal,
  Play,
  Layers,
  Table as TableIcon,
  Search,
  Key,
  Link,
  ArrowRight,
  ShieldCheck,
  Cpu,
  Boxes,
  CookingPot,
  Receipt,
  Scale,
  Users,
  Building,
} from 'lucide-react';

export const ArchitectureModule: React.FC = () => {
  const { orders, ingredients, accounts, menuItems, language, t } = useRestaurant();
  const isAr = language === 'ar';

  const [activeTab, setActiveTab] = useState<'overview' | 'backend' | 'database'>('overview');
  const [selectedBackendFileName, setSelectedBackendFileName] = useState<string>('Program.cs');
  
  // Database Schema Explorer state
  const [selectedTableName, setSelectedTableName] = useState<string>('Sales');
  const [schemaSearch, setSchemaSearch] = useState<string>('');
  const [selectedModuleFilter, setSelectedModuleFilter] = useState<string>('all');
  const [viewMode, setViewMode] = useState<'columns' | 'ddl'>('columns');
  
  const [copied, setCopied] = useState<boolean>(false);

  // Live Query Runner state
  const [activeQuery, setActiveQuery] = useState<string>(
    'SELECT TOP 10 SaleID, InvoiceNo, OrderType, Status, TotalAmount FROM dbo.Sales ORDER BY SaleDate DESC'
  );
  const [queryResult, setQueryResult] = useState<any>(null);

  const currentBackendFile =
    aspNetCodeFiles.find((f) => f.name === selectedBackendFileName) || aspNetCodeFiles[0];

  const currentTable: SchemaTable =
    sqlServerTables.find((t) => t.name === selectedTableName) || sqlServerTables[0];

  const filteredTables = sqlServerTables.filter((tbl) => {
    const matchesSearch =
      tbl.name.toLowerCase().includes(schemaSearch.toLowerCase()) ||
      tbl.description.toLowerCase().includes(schemaSearch.toLowerCase()) ||
      tbl.descriptionAr.includes(schemaSearch);
    const matchesModule =
      selectedModuleFilter === 'all' || tbl.module === selectedModuleFilter;
    return matchesSearch && matchesModule;
  });

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleRunQuery = () => {
    const q = activeQuery.toLowerCase();
    if (q.includes('sale') || q.includes('order')) {
      setQueryResult(
        orders.map((o, idx) => ({
          SaleID: idx + 1001,
          InvoiceNo: o.orderNumber,
          OrderType: o.orderType,
          TableID: o.tableNumber ? `Table ${o.tableNumber}` : 'Takeaway',
          SubTotal: `$${o.subtotal.toFixed(2)}`,
          TaxAmount: `$${o.taxAmount.toFixed(2)}`,
          TotalAmount: `$${o.total.toFixed(2)}`,
          PaymentMethod: o.paymentMethod || 'Cash',
          Status: o.status,
          SaleDate: o.createdAt,
        }))
      );
    } else if (q.includes('item') || q.includes('dish') || q.includes('recipe')) {
      setQueryResult(
        menuItems.map((m, idx) => ({
          ItemID: idx + 5001,
          ItemCode: m.code,
          ItemName: m.name,
          Category: m.category,
          CostPrice: `$${m.recipeBom.reduce((acc, b) => acc + (b.quantity * 2.5), 0).toFixed(2)}`,
          SalePrice: `$${m.price.toFixed(2)}`,
          TaxRate: '15.00%',
          IsActive: 1,
        }))
      );
    } else if (q.includes('ingredient') || q.includes('warehouse') || q.includes('stock')) {
      setQueryResult(
        ingredients.map((i, idx) => ({
          ItemID: idx + 8001,
          ItemCode: i.code,
          ItemName: i.name,
          Category: i.category,
          Quantity: `${i.currentStock} ${i.unit}`,
          AverageCost: `$${i.costPerUnit.toFixed(2)}`,
          ReorderLevel: `${i.reorderLevel} ${i.unit}`,
          Status: i.currentStock <= i.reorderLevel ? 'LOW_STOCK' : 'OPTIMAL',
        }))
      );
    } else if (q.includes('account') || q.includes('journal') || q.includes('ledger')) {
      setQueryResult(
        accounts.map((a, idx) => ({
          AccountID: idx + 101,
          AccountCode: a.code,
          AccountName: a.name,
          AccountType: a.type,
          Balance: `$${a.balance.toFixed(2)}`,
          IsPosting: 1,
          IsActive: 1,
        }))
      );
    } else {
      setQueryResult([
        { Schema: 'dbo', TableCount: 80, Engine: 'Microsoft SQL Server 2022', Charset: 'UTF-8 / Arabic_CI_AS', Status: 'ONLINE' }
      ]);
    }
  };

  return (
    <div className="flex-1 flex flex-col p-4 md:p-6 overflow-y-auto bg-slate-100">
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <Layers className="w-5 h-5 text-orange-600" />
            <span>{isAr ? 'معمارية النظام الشاملة وقاعدة بيانات SQL Server' : 'Full Architecture & SQL Server Schema Reference'}</span>
          </h2>
          <p className="text-xs text-slate-500">
            {isAr
              ? 'نموذج الطبقات الثلاث (3-Tier): الواجهة الأمامية Web POS، خادم ASP.NET Core Web API وقاعدة بيانات SQL Server (80 جدولاً مع القيود والمفاتيح)'
              : 'Enterprise 3-Tier Architecture: React Web POS, C# ASP.NET Core Web API backend, and SQL Server (80 Tables with FK relations)'}
          </p>
        </div>

        {/* Tab Switcher */}
        <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-slate-200 text-xs">
          <button
            onClick={() => setActiveTab('overview')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold transition-all ${
              activeTab === 'overview'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Cpu className="w-3.5 h-3.5 text-emerald-400" />
            <span>{isAr ? 'مخطط المعمارية (3-Tier)' : '3-Tier Architecture'}</span>
          </button>
          <button
            onClick={() => setActiveTab('backend')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold transition-all ${
              activeTab === 'backend'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Server className="w-3.5 h-3.5 text-orange-400" />
            <span>{isAr ? 'كود ASP.NET Core API' : 'ASP.NET Core Web API'}</span>
          </button>
          <button
            onClick={() => setActiveTab('database')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-bold transition-all ${
              activeTab === 'database'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Database className="w-3.5 h-3.5 text-blue-400" />
            <span>{isAr ? 'مخطط SQL Server (80 جدول)' : 'SQL Server Schema (80 Tables)'}</span>
          </button>
        </div>
      </div>

      {/* TAB 1: 3-TIER ARCHITECTURE OVERVIEW */}
      {activeTab === 'overview' && (
        <div className="space-y-6 mb-6">
          {/* Architecture Visual Diagram */}
          <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-2xs">
            <h3 className="font-extrabold text-sm text-slate-900 mb-4 flex items-center gap-2">
              <Layers className="w-4 h-4 text-orange-600" />
              <span>{isAr ? 'المخطط البصري الهيكلي للنظام (System Topology)' : 'End-to-End System Topology'}</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 relative">
              {/* Frontend Card */}
              <div className="bg-gradient-to-b from-slate-900 to-slate-800 text-white p-5 rounded-2xl shadow-md border border-slate-700 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-[10px] uppercase font-mono tracking-wider text-orange-400 bg-orange-950/80 px-2 py-0.5 rounded">
                      Client Tier
                    </span>
                    <Cpu className="w-5 h-5 text-orange-400" />
                  </div>
                  <h4 className="text-base font-black mb-1">Web POS / ERP Frontend</h4>
                  <p className="text-xs text-slate-300 leading-relaxed mb-4">
                    {isAr
                      ? 'واجهة تفاعلية فورية بنظام React 18 و Tailwind CSS مع دعم RTL واللغة العربية وشاشات اللمس.'
                      : 'High-performance SPA with touch POS, offline support, KDS stations, and management dashboards.'}
                  </p>
                  <ul className="text-[11px] text-slate-300 space-y-1.5">
                    <li className="flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                      <span>POS Terminal & Cash Till Management</span>
                    </li>
                    <li className="flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                      <span>Kitchen Display System (KDS) & Printers</span>
                    </li>
                    <li className="flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                      <span>Inventory BOM & General Ledger Accounting</span>
                    </li>
                  </ul>
                </div>
                <div className="mt-4 pt-3 border-t border-slate-700/60 text-[11px] text-orange-300 font-mono">
                  Stack: React 18, TypeScript, Tailwind CSS, Lucide
                </div>
              </div>

              {/* Middle: Protocol Arrow + Backend Card */}
              <div className="bg-gradient-to-b from-orange-600 to-orange-700 text-white p-5 rounded-2xl shadow-md border border-orange-500 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-[10px] uppercase font-mono tracking-wider text-slate-900 bg-white/90 px-2 py-0.5 rounded font-bold">
                      Application Tier
                    </span>
                    <Server className="w-5 h-5 text-white" />
                  </div>
                  <h4 className="text-base font-black mb-1">ASP.NET Core Web API</h4>
                  <p className="text-xs text-orange-100 leading-relaxed mb-4">
                    {isAr
                      ? 'طبقة الخادم عالية الأداء (Clean Architecture) تعالج الأمان، العمليات المالية، وحساب تكاليف الوصفات تلقائياً.'
                      : 'High-throughput C# RESTful API with automated GL journal posting and atomic inventory depletion transactions.'}
                  </p>
                  <ul className="text-[11px] text-orange-100 space-y-1.5">
                    <li className="flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-white"></span>
                      <span>Controllers, Services & Repository Pattern</span>
                    </li>
                    <li className="flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-white"></span>
                      <span>Entity Framework Core 8 with Connection Resiliency</span>
                    </li>
                    <li className="flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-white"></span>
                      <span>SignalR Real-Time Hubs for KDS and Order Tickets</span>
                    </li>
                  </ul>
                </div>
                <div className="mt-4 pt-3 border-t border-orange-500/60 text-[11px] text-white font-mono">
                  Stack: .NET 8, C#, EF Core, Serilog, Swagger
                </div>
              </div>

              {/* Database Card */}
              <div className="bg-gradient-to-b from-blue-900 to-indigo-950 text-white p-5 rounded-2xl shadow-md border border-blue-800 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-[10px] uppercase font-mono tracking-wider text-blue-300 bg-blue-950 px-2 py-0.5 rounded">
                      Database Tier
                    </span>
                    <Database className="w-5 h-5 text-blue-300" />
                  </div>
                  <h4 className="text-base font-black mb-1">SQL Server (RestaurantERP)</h4>
                  <p className="text-xs text-blue-200 leading-relaxed mb-4">
                    {isAr
                      ? 'قاعدة بيانات علائقية متكاملة من 80 جدولاً تشمل قيود المفاتيح الأجنبية، سجلات المراجعة، ومؤشرات الأداء.'
                      : 'Relational database comprising 80 enterprise tables, foreign key constraints, audit logs, and analytical views.'}
                  </p>
                  <ul className="text-[11px] text-blue-200 space-y-1.5">
                    <li className="flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-blue-400"></span>
                      <span>80 Relational Tables with Exact Data Types</span>
                    </li>
                    <li className="flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-blue-400"></span>
                      <span>ACID-Compliant Stored Procedures & Atomic Transactions</span>
                    </li>
                    <li className="flex items-center gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-blue-400"></span>
                      <span>Pre-Computed Materialized Views for Revenue & Food Costs</span>
                    </li>
                  </ul>
                </div>
                <div className="mt-4 pt-3 border-t border-blue-800/60 text-[11px] text-blue-300 font-mono">
                  Engine: Microsoft SQL Server 2022 (T-SQL)
                </div>
              </div>
            </div>
          </div>

          {/* Enterprise Modules Breakdown Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              {
                title: isAr ? 'نقاط البيع والورديات' : 'POS & Cashier Shifts',
                desc: isAr ? 'Sales, SaleDetails, SalePayments, POSShifts, Cashboxes' : 'Sales, SaleDetails, SalePayments, POSShifts, Cashboxes',
                count: '10 Tables',
                icon: Receipt,
                color: 'text-orange-600 bg-orange-50 border-orange-200',
              },
              {
                title: isAr ? 'المطبخ وشاشات KDS' : 'Kitchen KDS & Printers',
                desc: isAr ? 'Kitchens, KitchenOrders, KitchenStations, Printers, PrinterRoutes' : 'Kitchens, KitchenOrders, KitchenStations, Printers, PrinterRoutes',
                count: '7 Tables',
                icon: CookingPot,
                color: 'text-amber-600 bg-amber-50 border-amber-200',
              },
              {
                title: isAr ? 'المخزون ووصفات BOM' : 'Inventory & Recipe BOM',
                desc: isAr ? 'Items, Recipes, RecipeDetails, Warehouses, StocktakeSessions' : 'Items, Recipes, RecipeDetails, Warehouses, StocktakeSessions',
                count: '20 Tables',
                icon: Boxes,
                color: 'text-emerald-600 bg-emerald-50 border-emerald-200',
              },
              {
                title: isAr ? 'المحاسبة والشجرة المالية' : 'General Ledger Accounting',
                desc: isAr ? 'Accounts, JournalEntries, JournalEntryDetails, Expenses, Taxes' : 'Accounts, JournalEntries, JournalEntryDetails, Expenses, Taxes',
                count: '11 Tables',
                icon: Scale,
                color: 'text-blue-600 bg-blue-50 border-blue-200',
              },
            ].map((moduleCard, i) => {
              const Icon = moduleCard.icon;
              return (
                <div
                  key={i}
                  className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <div className={`p-2 rounded-xl border ${moduleCard.color}`}>
                        <Icon className="w-4 h-4" />
                      </div>
                      <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                        {moduleCard.count}
                      </span>
                    </div>
                    <h4 className="font-black text-sm text-slate-900 mb-1">{moduleCard.title}</h4>
                    <p className="text-xs text-slate-500 font-mono">{moduleCard.desc}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 2: BACKEND C# ASP.NET CORE EXPLORER */}
      {activeTab === 'backend' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 mb-6 flex-1 min-h-[500px]">
          {/* Left: Files List */}
          <div className="lg:col-span-4 bg-white rounded-2xl border border-slate-200 p-4 shadow-2xs flex flex-col">
            <div className="flex items-center gap-2 pb-3 border-b border-slate-100 mb-3">
              <FolderTree className="w-4 h-4 text-orange-600" />
              <h3 className="font-extrabold text-xs text-slate-900 uppercase tracking-wider">
                Backend / ASP.NET Core Web API
              </h3>
            </div>

            <div className="space-y-1 overflow-y-auto flex-1 pr-1">
              {aspNetCodeFiles.map((file) => {
                const isSelected = file.name === selectedBackendFileName;
                return (
                  <button
                    key={file.name}
                    onClick={() => setSelectedBackendFileName(file.name)}
                    className={`w-full text-left p-2.5 rounded-xl text-xs flex items-center justify-between transition-all ${
                      isSelected
                        ? 'bg-orange-50 border border-orange-200 text-orange-950 font-bold'
                        : 'hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <FileCode
                        className={`w-4 h-4 shrink-0 ${
                          isSelected ? 'text-orange-600' : 'text-slate-400'
                        }`}
                      />
                      <span className="truncate font-mono">{file.name}</span>
                    </div>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-500 font-semibold uppercase">
                      {file.category}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right: Code Viewer */}
          <div className="lg:col-span-8 bg-slate-950 rounded-2xl border border-slate-800 shadow-xl overflow-hidden flex flex-col">
            <div className="bg-slate-900 px-4 py-3 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="font-mono text-xs text-orange-400 font-bold">
                  {currentBackendFile.path}
                </span>
                <span className="text-[10px] text-slate-400 bg-slate-800 px-2 py-0.5 rounded font-mono">
                  {currentBackendFile.language}
                </span>
              </div>
              <button
                onClick={() => handleCopy(currentBackendFile.content)}
                className="flex items-center gap-1 px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg text-xs font-semibold transition-colors"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied!' : 'Copy Code'}</span>
              </button>
            </div>

            <div className="px-4 py-2 bg-slate-900/60 border-b border-slate-800/80 text-xs text-slate-400">
              {currentBackendFile.description}
            </div>

            <div className="p-4 overflow-y-auto flex-1 font-mono text-xs text-slate-300 leading-relaxed max-h-[550px]">
              <pre className="whitespace-pre">{currentBackendFile.content}</pre>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: SQL SERVER SCHEMA EXPLORER (80 TABLES) */}
      {activeTab === 'database' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 mb-6 flex-1 min-h-[550px]">
          {/* Left: 80 Tables Catalog & Search */}
          <div className="lg:col-span-4 bg-white rounded-2xl border border-slate-200 p-4 shadow-2xs flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
              <div className="flex items-center gap-2">
                <Database className="w-4 h-4 text-blue-600" />
                <h3 className="font-extrabold text-xs text-slate-900 uppercase tracking-wider">
                  {isAr ? 'جداول قاعدة البيانات (80 جدول)' : 'SQL Server Schema (80 Tables)'}
                </h3>
              </div>
              <span className="text-[10px] font-mono bg-blue-50 text-blue-700 px-2 py-0.5 rounded-full font-bold">
                {filteredTables.length} / {sqlServerTables.length}
              </span>
            </div>

            {/* Search Input */}
            <div className="relative mb-2">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-2.5" />
              <input
                type="text"
                value={schemaSearch}
                onChange={(e) => setSchemaSearch(e.target.value)}
                placeholder={isAr ? 'بحث في الجداول والحقول...' : 'Search tables and fields...'}
                className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:border-blue-500"
              />
            </div>

            {/* Module Filter Pills */}
            <div className="flex items-center gap-1 overflow-x-auto pb-2 mb-2">
              {[
                { id: 'all', label: isAr ? 'الكل' : 'All' },
                { id: 'POS & Sales', label: isAr ? 'المبيعات' : 'Sales' },
                { id: 'Kitchen & KDS', label: isAr ? 'المطبخ' : 'Kitchen' },
                { id: 'Inventory & BOM', label: isAr ? 'المخزون' : 'Inventory' },
                { id: 'Accounting & Cash', label: isAr ? 'المحاسبة' : 'Accounting' },
                { id: 'Purchasing', label: isAr ? 'المشتريات' : 'Purchasing' },
                { id: 'CRM & Delivery', label: isAr ? 'العملاء' : 'CRM' },
                { id: 'System & Security', label: isAr ? 'النظام' : 'System' },
              ].map((filter) => (
                <button
                  key={filter.id}
                  onClick={() => setSelectedModuleFilter(filter.id)}
                  className={`px-2 py-1 text-[10px] font-bold rounded-lg whitespace-nowrap transition-colors ${
                    selectedModuleFilter === filter.id
                      ? 'bg-blue-600 text-white'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                  }`}
                >
                  {filter.label}
                </button>
              ))}
            </div>

            {/* Tables List */}
            <div className="space-y-1 overflow-y-auto flex-1 pr-1 max-h-[480px]">
              {filteredTables.map((tbl) => {
                const isSelected = tbl.name === selectedTableName;
                return (
                  <button
                    key={tbl.name}
                    onClick={() => setSelectedTableName(tbl.name)}
                    className={`w-full text-left p-2.5 rounded-xl text-xs flex items-center justify-between transition-all ${
                      isSelected
                        ? 'bg-blue-50 border border-blue-200 text-blue-950 font-bold'
                        : 'hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <TableIcon
                        className={`w-4 h-4 shrink-0 ${
                          isSelected ? 'text-blue-600' : 'text-slate-400'
                        }`}
                      />
                      <span className="truncate font-mono">{tbl.name}</span>
                    </div>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-500 font-semibold">
                      {tbl.columns.length} cols
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right: Table Inspector & DDL Generator */}
          <div className="lg:col-span-8 bg-white rounded-2xl border border-slate-200 shadow-2xs flex flex-col overflow-hidden">
            {/* Table Header Details */}
            <div className="p-4 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-mono font-bold text-blue-600 bg-blue-100 px-2 py-0.5 rounded">
                    dbo.{currentTable.name}
                  </span>
                  <span className="text-xs text-slate-500 font-medium">
                    ({isAr ? currentTable.moduleAr : currentTable.module})
                  </span>
                </div>
                <p className="text-xs text-slate-600 mt-1">
                  {isAr ? currentTable.descriptionAr : currentTable.description}
                </p>
              </div>

              {/* View Switcher: Columns Grid vs DDL SQL */}
              <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-slate-200 text-xs">
                <button
                  onClick={() => setViewMode('columns')}
                  className={`px-3 py-1 rounded-lg font-bold transition-all ${
                    viewMode === 'columns'
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {isAr ? 'الأعمدة والأنواع' : 'Columns & Keys'}
                </button>
                <button
                  onClick={() => setViewMode('ddl')}
                  className={`px-3 py-1 rounded-lg font-bold transition-all ${
                    viewMode === 'ddl'
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {isAr ? 'كود T-SQL DDL' : 'T-SQL DDL Script'}
                </button>
              </div>
            </div>

            {/* CONTENT 1: Columns & Foreign Keys Table */}
            {viewMode === 'columns' && (
              <div className="overflow-x-auto flex-1 p-4">
                <table className="w-full text-left border-collapse text-xs font-mono">
                  <thead>
                    <tr className="bg-slate-100 border-b border-slate-200 text-slate-700 text-[11px]">
                      <th className="py-2 px-3 font-bold">#</th>
                      <th className="py-2 px-3 font-bold">{isAr ? 'اسم الحقل' : 'Column Name'}</th>
                      <th className="py-2 px-3 font-bold">{isAr ? 'النوع (Data Type)' : 'Data Type'}</th>
                      <th className="py-2 px-3 font-bold">{isAr ? 'يقبل فارغ؟' : 'Nullable'}</th>
                      <th className="py-2 px-3 font-bold">{isAr ? 'المفاتيح والعلاقات' : 'Key Constraints'}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-800">
                    {currentTable.columns.map((col, idx) => {
                      let typeDisplay = col.dataType.toUpperCase();
                      if (col.maxLength && col.maxLength > 0) typeDisplay += `(${col.maxLength})`;
                      else if (col.maxLength === -1) typeDisplay += `(MAX)`;
                      else if (col.precision && col.scale !== undefined)
                        typeDisplay += `(${col.precision}, ${col.scale})`;

                      return (
                        <tr key={col.name} className="hover:bg-slate-50/80">
                          <td className="py-2 px-3 text-slate-400">{idx + 1}</td>
                          <td className="py-2 px-3 font-bold text-slate-900 flex items-center gap-1.5">
                            {col.isPrimaryKey && <Key className="w-3.5 h-3.5 text-amber-500" />}
                            {col.isForeignKey && <Link className="w-3.5 h-3.5 text-blue-500" />}
                            <span>{col.name}</span>
                          </td>
                          <td className="py-2 px-3 text-blue-600 font-semibold">{typeDisplay}</td>
                          <td className="py-2 px-3">
                            {col.isNullable ? (
                              <span className="text-[10px] text-slate-500 bg-slate-100 px-1.5 py-0.5 rounded">
                                NULL
                              </span>
                            ) : (
                              <span className="text-[10px] text-rose-600 bg-rose-50 px-1.5 py-0.5 rounded font-bold">
                                NOT NULL
                              </span>
                            )}
                          </td>
                          <td className="py-2 px-3">
                            {col.isPrimaryKey && (
                              <span className="text-[10px] text-amber-700 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded font-bold mr-1">
                                PRIMARY KEY
                              </span>
                            )}
                            {col.isForeignKey && col.refTable && (
                              <button
                                onClick={() => setSelectedTableName(col.refTable!)}
                                className="text-[10px] text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 px-2 py-0.5 rounded font-semibold inline-flex items-center gap-1"
                              >
                                <span>FK → {col.refTable}({col.refColumn})</span>
                              </button>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}

            {/* CONTENT 2: T-SQL DDL Script Viewer */}
            {viewMode === 'ddl' && (
              <div className="bg-slate-950 p-4 flex-1 flex flex-col font-mono text-xs">
                <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800">
                  <span className="text-slate-400 text-[11px]">
                    Generated Microsoft SQL Server DDL Script
                  </span>
                  <button
                    onClick={() => handleCopy(generateCreateTableSql(currentTable))}
                    className="flex items-center gap-1 px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg text-xs font-semibold transition-colors"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? 'Copied!' : 'Copy DDL'}</span>
                  </button>
                </div>
                <pre className="text-emerald-400 overflow-y-auto max-h-[450px] leading-relaxed whitespace-pre">
                  {generateCreateTableSql(currentTable)}
                </pre>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Interactive SQL / T-SQL Query Runner */}
      <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-2xs">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <Terminal className="w-4 h-4 text-orange-600" />
            <h3 className="font-extrabold text-sm text-slate-900">
              {isAr ? 'منصة استعلامات T-SQL الحية (Direct Engine)' : 'Interactive T-SQL Query Console (Live Data Engine)'}
            </h3>
          </div>
          <span className="text-[11px] text-slate-400 font-mono">
            {isAr ? 'تنفيذ استعلامات SQL حية مباشرة على بيانات النظام في الذاكرة' : 'Direct query execution on in-memory relational dataset'}
          </span>
        </div>

        {/* Quick query buttons */}
        <div className="flex flex-wrap gap-2 mb-3">
          {[
            'SELECT TOP 10 SaleID, InvoiceNo, OrderType, Status, TotalAmount FROM dbo.Sales ORDER BY SaleDate DESC',
            'SELECT ItemID, ItemCode, ItemName, CostPrice, SalePrice FROM dbo.Items WHERE IsActive = 1',
            'SELECT ItemID, ItemName, Quantity, AverageCost, Status FROM dbo.WarehouseItems WHERE Status = \'LOW_STOCK\'',
            'SELECT AccountID, AccountCode, AccountName, AccountType, Balance FROM dbo.Accounts',
          ].map((queryText) => (
            <button
              key={queryText}
              onClick={() => setActiveQuery(queryText)}
              className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-mono text-[11px] transition-colors"
            >
              {queryText}
            </button>
          ))}
        </div>

        {/* Query Input + Execute */}
        <div className="flex gap-2 mb-4">
          <input
            type="text"
            value={activeQuery}
            onChange={(e) => setActiveQuery(e.target.value)}
            className="flex-1 p-2.5 bg-slate-900 text-emerald-400 font-mono text-xs rounded-xl focus:outline-hidden border border-slate-800"
          />
          <button
            onClick={handleRunQuery}
            className="px-5 py-2.5 bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs rounded-xl flex items-center gap-1.5 shadow-md shadow-orange-200 transition-colors"
          >
            <Play className="w-3.5 h-3.5 fill-current" />
            <span>{isAr ? 'تنفيذ الاستعلام' : 'Execute SQL'}</span>
          </button>
        </div>

        {/* Query Results Table */}
        {queryResult && (
          <div className="overflow-x-auto border border-slate-200 rounded-xl max-h-60 overflow-y-auto">
            <table className="w-full text-left border-collapse text-xs font-mono">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 text-[11px]">
                  {Object.keys(queryResult[0] || {}).map((col) => (
                    <th key={col} className="py-2 px-3">
                      {col}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-800">
                {queryResult.map((row: any, i: number) => (
                  <tr key={i} className="hover:bg-slate-50/70">
                    {Object.values(row).map((val: any, j: number) => (
                      <td key={j} className="py-2 px-3 whitespace-nowrap">
                        {String(val)}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
