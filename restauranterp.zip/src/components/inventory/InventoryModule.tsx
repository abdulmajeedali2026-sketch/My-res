import React, { useState } from 'react';
import { useRestaurant } from '../../context/RestaurantContext';
import { Ingredient } from '../../types/erp';
import {
  Boxes,
  Layers,
  AlertTriangle,
  Plus,
  ArrowUpDown,
  FileSpreadsheet,
  CheckCircle2,
  Trash2,
  Scale,
  Sparkles,
  X,
  TrendingDown,
  ChefHat,
  Search,
} from 'lucide-react';

export const InventoryModule: React.FC = () => {
  const {
    ingredients,
    menuItems,
    inventoryTransactions,
    suppliers,
    settings,
    adjustStock,
    addIngredient,
    language,
    t,
  } = useRestaurant();

  const [activeTab, setActiveTab] = useState<'raw' | 'bom' | 'waste' | 'audit'>('raw');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [categoryFilter, setCategoryFilter] = useState<string>('All');

  // Modal states
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [showAdjustModal, setShowAdjustModal] = useState<boolean>(false);
  const [adjustIngId, setAdjustIngId] = useState<string>(ingredients[0]?.id || '');
  const [adjustDelta, setAdjustDelta] = useState<number>(-1);
  const [adjustReason, setAdjustReason] = useState<string>('');
  const [adjustType, setAdjustType] = useState<'waste_spoilage' | 'manual_adjustment'>('waste_spoilage');
  const [feedback, setFeedback] = useState<string | null>(null);

  // New ingredient form
  const [newCode, setNewCode] = useState<string>('ING-NEW-01');
  const [newName, setNewName] = useState<string>('');
  const [newNameAr, setNewNameAr] = useState<string>('');
  const [newCat, setNewCat] = useState<Ingredient['category']>('Produce');
  const [newStock, setNewStock] = useState<number>(10);
  const [newUnit, setNewUnit] = useState<Ingredient['unit']>('kg');
  const [newReorder, setNewReorder] = useState<number>(5);
  const [newCost, setNewCost] = useState<number>(5.5);
  const [newSupId, setNewSupId] = useState<string>(suppliers[0]?.id || '');

  const categories = [
    'All',
    'Meat & Poultry',
    'Dairy & Cheese',
    'Produce',
    'Dry Goods & Pantry',
    'Beverages & Spirits',
    'Bakery & Dough',
  ];

  const getCategoryLabel = (cat: string) => {
    if (language === 'ar') {
      switch (cat) {
        case 'All': return 'الكل';
        case 'Meat & Poultry': return 'اللحوم والدواجن';
        case 'Dairy & Cheese': return 'الألبان والأجبان';
        case 'Produce': return 'الخضار والفواكه';
        case 'Dry Goods & Pantry': return 'البقوليات والمؤن';
        case 'Beverages & Spirits': return 'المشروبات والعصائر';
        case 'Bakery & Dough': return 'المخبوزات والعجين';
        default: return cat;
      }
    }
    return cat;
  };

  const getUnitLabel = (unit: string) => {
    if (language === 'ar') {
      switch (unit) {
        case 'kg': return 'كجم';
        case 'g': return 'جم';
        case 'L': return 'لتر';
        case 'ml': return 'مل';
        case 'pcs': return 'حبة';
        case 'pack': return 'عبوة';
        default: return unit;
      }
    }
    return unit;
  };

  const getMovementTypeLabel = (type: string) => {
    if (language === 'ar') {
      switch (type) {
        case 'purchase_receipt': return 'استلام مشتريات';
        case 'sale_deduction': return 'خصم تلقائي (BOM)';
        case 'waste_spoilage': return 'هدر وتالف مطبخ';
        case 'manual_adjustment': return 'تسوية جردية';
        default: return type;
      }
    }
    return type.replace('_', ' ');
  };

  const filteredIngredients = ingredients.filter((ing) => {
    const matchesCat = categoryFilter === 'All' || ing.category === categoryFilter;
    const matchesSearch =
      ing.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (ing.nameAr && ing.nameAr.includes(searchQuery)) ||
      ing.code.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  const totalInventoryValue = ingredients.reduce((sum, i) => sum + i.currentStock * i.costPerUnit, 0);
  const lowStockCount = ingredients.filter((i) => i.currentStock <= i.reorderLevel).length;

  const handleAdjustSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!adjustReason) return;

    adjustStock(adjustIngId, adjustDelta, adjustReason, adjustType);
    setShowAdjustModal(false);
    setFeedback(
      language === 'ar'
        ? 'تم تسجيل التسوية الجردية بنجاح وتحديث حركة المخزون.'
        : 'Inventory stock count adjusted and logged in audit trail.'
    );
    setAdjustReason('');
    setTimeout(() => setFeedback(null), 4000);
  };

  const handleAddIngredient = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName) return;

    const sup = suppliers.find((s) => s.id === newSupId);
    addIngredient({
      code: newCode,
      name: newName,
      nameAr: newNameAr || undefined,
      category: newCat,
      categoryAr: getCategoryLabel(newCat),
      currentStock: newStock,
      unit: newUnit,
      unitAr: getUnitLabel(newUnit),
      reorderLevel: newReorder,
      costPerUnit: newCost,
      supplierId: newSupId,
      supplierName: sup ? sup.name : 'Supplier',
    });

    setShowAddModal(false);
    setFeedback(
      language === 'ar'
        ? `تمت إضافة المادة الخام "${newNameAr || newName}" إلى سجل المخزون بنجاح.`
        : `New raw ingredient "${newName}" added to inventory ledger.`
    );
    setNewName('');
    setNewNameAr('');
    setTimeout(() => setFeedback(null), 4000);
  };

  return (
    <div className="flex-1 flex flex-col p-4 md:p-6 overflow-y-auto bg-slate-100">
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight">
            {t.inventory.title}
          </h2>
          <p className="text-xs text-slate-500">
            {t.inventory.subtitle}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowAdjustModal(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white border border-slate-200 text-slate-700 hover:bg-slate-50 font-bold text-xs shadow-2xs transition-colors"
          >
            <Scale className="w-3.5 h-3.5 text-slate-500" />
            <span>{t.inventory.adjustStock}</span>
          </button>
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs shadow-md shadow-orange-200 transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>{t.inventory.addIngredient}</span>
          </button>
        </div>
      </div>

      {feedback && (
        <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 rounded-2xl text-emerald-800 text-xs font-semibold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{feedback}</span>
        </div>
      )}

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-6">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-xs text-slate-500 font-semibold block mb-1">
            {language === 'ar' ? 'إجمالي القيمة التقديرية للمخزون' : 'Total Stock Asset Value'}
          </span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black text-slate-900 font-mono">
              {settings.currencySymbol} {totalInventoryValue.toFixed(2)}
            </span>
            <span className="text-xs text-slate-400 font-medium">
              {language === 'ar' ? 'بالمستودع الفعلي' : 'On Hand'}
            </span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-xs text-slate-500 font-semibold block mb-1">
            {t.inventory.lowStockAlert}
          </span>
          <div className="flex items-baseline justify-between">
            <span className={`text-2xl font-black font-mono ${lowStockCount > 0 ? 'text-rose-600' : 'text-slate-900'}`}>
              {lowStockCount} {language === 'ar' ? 'مواد' : 'Items'}
            </span>
            {lowStockCount > 0 ? (
              <span className="text-xs font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded-md flex items-center gap-1">
                <AlertTriangle className="w-3 h-3" /> {language === 'ar' ? 'بحاجة لإعادة الطلب' : 'Reorder Needed'}
              </span>
            ) : (
              <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md">
                {language === 'ar' ? 'المخزون آمن وكافٍ' : 'Healthy Stocks'}
              </span>
            )}
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-xs text-slate-500 font-semibold block mb-1">
            {language === 'ar' ? 'معادلات التكاليف (BOM) المربوطة' : 'Configured Recipe BOMs'}
          </span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black text-slate-900 font-mono">
              {menuItems.length} {language === 'ar' ? 'وجبة وصنف' : 'Dishes'}
            </span>
            <span className="text-xs text-slate-400 font-medium">
              {language === 'ar' ? 'خصم آلي عند البيع' : 'Auto-Depleting'}
            </span>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 mb-4 pb-2 overflow-x-auto">
        {[
          { id: 'raw' as const, label: t.inventory.rawMaterials, icon: Boxes },
          { id: 'bom' as const, label: t.inventory.bomRecipes, icon: ChefHat },
          { id: 'audit' as const, label: t.inventory.transactions, icon: FileSpreadsheet },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-200/70'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab 1: Raw Stock Table */}
      {activeTab === 'raw' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden flex flex-col flex-1">
          {/* Filters */}
          <div className="p-4 border-b border-slate-200/80 flex flex-wrap items-center justify-between gap-3">
            <div className="relative w-full sm:w-72">
              <Search className="w-4 h-4 absolute start-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder={language === 'ar' ? 'بحث باسم المادة، الرمز...' : 'Search raw material name, code...'}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full ps-9 pe-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-hidden focus:border-orange-500 text-start"
              />
            </div>

            <div className="flex items-center gap-1 overflow-x-auto pb-1">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setCategoryFilter(cat)}
                  className={`px-2.5 py-1 rounded-lg text-xs font-bold whitespace-nowrap transition-all ${
                    categoryFilter === cat
                      ? 'bg-orange-500 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {getCategoryLabel(cat)}
                </button>
              ))}
            </div>
          </div>

          {/* Table */}
          <div className="overflow-x-auto flex-1">
            <table className="w-full text-start border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider text-[10px]">
                  <th className="py-3 px-4">{t.inventory.ingredientCode}</th>
                  <th className="py-3 px-4">{t.inventory.ingredientName}</th>
                  <th className="py-3 px-4">{t.inventory.category}</th>
                  <th className="py-3 px-4">{t.inventory.currentStock}</th>
                  <th className="py-3 px-4">{t.inventory.reorderLevel}</th>
                  <th className="py-3 px-4">{t.inventory.unitCost}</th>
                  <th className="py-3 px-4">{language === 'ar' ? 'قيمة الرصيد' : 'Valuation'}</th>
                  <th className="py-3 px-4">{language === 'ar' ? 'المورد الأساسي' : 'Primary Vendor'}</th>
                  <th className="py-3 px-4">{t.inventory.status}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {filteredIngredients.map((ing) => {
                  const isLow = ing.currentStock <= ing.reorderLevel;
                  const isOut = ing.currentStock <= 0;
                  const itemValuation = ing.currentStock * ing.costPerUnit;
                  const displayName = (language === 'ar' && ing.nameAr) ? ing.nameAr : ing.name;
                  const displayCat = (language === 'ar' && ing.categoryAr) ? ing.categoryAr : getCategoryLabel(ing.category);
                  const displayUnit = (language === 'ar' && ing.unitAr) ? ing.unitAr : getUnitLabel(ing.unit);

                  return (
                    <tr key={ing.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3.5 px-4 font-mono font-bold text-slate-900">{ing.code}</td>
                      <td className="py-3.5 px-4 font-bold text-slate-900">{displayName}</td>
                      <td className="py-3.5 px-4 text-slate-500">{displayCat}</td>
                      <td className="py-3.5 px-4 font-mono font-bold text-sm">
                        {ing.currentStock.toFixed(2)} {displayUnit}
                      </td>
                      <td className="py-3.5 px-4 font-mono text-slate-500">
                        {ing.reorderLevel} {displayUnit}
                      </td>
                      <td className="py-3.5 px-4 font-mono text-slate-800">
                        {settings.currencySymbol} {ing.costPerUnit.toFixed(2)} / {displayUnit}
                      </td>
                      <td className="py-3.5 px-4 font-mono font-extrabold text-slate-900">
                        {settings.currencySymbol} {itemValuation.toFixed(2)}
                      </td>
                      <td className="py-3.5 px-4 text-slate-600">{ing.supplierName}</td>
                      <td className="py-3.5 px-4">
                        {isOut ? (
                          <span className="text-[10px] font-extrabold text-rose-700 bg-rose-100 px-2 py-0.5 rounded-full whitespace-nowrap">
                            {language === 'ar' ? 'نفد (0)' : 'Depleted (0)'}
                          </span>
                        ) : isLow ? (
                          <span className="text-[10px] font-extrabold text-amber-700 bg-amber-100 px-2 py-0.5 rounded-full flex items-center gap-1 w-fit whitespace-nowrap">
                            <AlertTriangle className="w-3 h-3" /> {language === 'ar' ? 'منخفض' : 'Low Stock'}
                          </span>
                        ) : (
                          <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full whitespace-nowrap">
                            {language === 'ar' ? 'طبيعي' : 'Normal'}
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 2: Recipe BOM & Food Cost */}
      {activeTab === 'bom' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {menuItems.map((dish) => {
            const calculatedCost = dish.recipeBom.reduce((sum, bom) => {
              const ing = ingredients.find((i) => i.id === bom.ingredientId);
              return sum + (ing ? ing.costPerUnit * bom.quantity : 0);
            }, 0);
            const foodCostPct = dish.price > 0 ? (calculatedCost / dish.price) * 100 : 0;
            const grossMargin = dish.price - calculatedCost;
            const dishName = (language === 'ar' && dish.nameAr) ? dish.nameAr : dish.name;
            const dishCategory = (language === 'ar' && dish.categoryAr) ? dish.categoryAr : dish.category;

            return (
              <div
                key={dish.id}
                className="bg-white rounded-2xl border border-slate-200/90 p-4 shadow-2xs flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div>
                      <span className="font-mono text-[10px] text-orange-600 font-bold block">
                        {dish.code} &bull; {dishCategory}
                      </span>
                      <h4 className="font-extrabold text-sm text-slate-900">{dishName}</h4>
                    </div>
                    <div className="text-end">
                      <span className="text-base font-black text-slate-900 font-mono block">
                        {settings.currencySymbol} {dish.price.toFixed(2)}
                      </span>
                      <span
                        className={`text-[10px] font-extrabold px-1.5 py-0.5 rounded font-mono ${
                          foodCostPct <= 28
                            ? 'bg-emerald-100 text-emerald-800'
                            : foodCostPct <= 35
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-rose-100 text-rose-800'
                        }`}
                      >
                        {language === 'ar' ? 'التكلفة:' : 'Cost:'} {foodCostPct.toFixed(1)}%
                      </span>
                    </div>
                  </div>

                  {/* BOM Recipe breakdown */}
                  <div className="mt-3 pt-3 border-t border-slate-100 space-y-1.5 text-xs">
                    <span className="text-[10px] uppercase tracking-wider font-bold text-slate-400 block">
                      {language === 'ar' ? 'مكونات الوصفة ومعادلة التكلفة (BOM)' : 'Recipe Ingredients (BOM)'}
                    </span>
                    {dish.recipeBom.map((bom, idx) => {
                      const ing = ingredients.find((i) => i.id === bom.ingredientId);
                      const lineCost = ing ? ing.costPerUnit * bom.quantity : 0;
                      const ingName = (language === 'ar' && ing?.nameAr) ? ing.nameAr : (ing?.name || 'مكون');
                      const ingUnit = (language === 'ar' && ing?.unitAr) ? ing.unitAr : (ing?.unit || 'وحدة');

                      return (
                        <div
                          key={idx}
                          className="flex items-center justify-between text-slate-700 bg-slate-50 px-2 py-1 rounded-lg"
                        >
                          <span className="font-medium text-[11px] truncate me-2">
                            {bom.quantity} {ingUnit} &bull; {ingName}
                          </span>
                          <span className="font-mono text-[11px] font-bold text-slate-900 whitespace-nowrap">
                            {settings.currencySymbol} {lineCost.toFixed(2)}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Footer summary */}
                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs bg-orange-50/50 p-2.5 rounded-xl border border-orange-100">
                  <div>
                    <span className="text-[10px] text-slate-500 block">{language === 'ar' ? 'تكلفة الطبق' : 'Recipe Cost'}</span>
                    <span className="font-mono font-bold text-slate-800">
                      {settings.currencySymbol} {calculatedCost.toFixed(2)}
                    </span>
                  </div>
                  <div className="text-end">
                    <span className="text-[10px] text-slate-500 block">{language === 'ar' ? 'هامش الربح الإجمالي' : 'Gross Profit'}</span>
                    <span className="font-mono font-extrabold text-emerald-700">
                      +{settings.currencySymbol} {grossMargin.toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Tab 3: Transactions & Audit Log */}
      {activeTab === 'audit' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden flex-1">
          <div className="p-4 border-b border-slate-200/80 flex items-center justify-between">
            <h3 className="font-extrabold text-sm text-slate-900">
              {language === 'ar' ? 'سجل حركات وتدقيق المخزون' : 'Inventory Movement & Audit Ledger'}
            </h3>
            <span className="text-xs text-slate-400 font-mono">
              {inventoryTransactions.length} {language === 'ar' ? 'حركة مسجلة' : 'Recorded Movements'}
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-start border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider text-[10px]">
                  <th className="py-3 px-4">{language === 'ar' ? 'التاريخ والوقت' : 'Date & Time'}</th>
                  <th className="py-3 px-4">{t.inventory.ingredientName}</th>
                  <th className="py-3 px-4">{language === 'ar' ? 'نوع الحركة' : 'Movement Type'}</th>
                  <th className="py-3 px-4">{language === 'ar' ? 'فارق الكمية' : 'Quantity Delta'}</th>
                  <th className="py-3 px-4">{t.inventory.unitCost}</th>
                  <th className="py-3 px-4">{language === 'ar' ? 'السبب / المرجع' : 'Reference / Reason'}</th>
                  <th className="py-3 px-4">{language === 'ar' ? 'المسؤول' : 'Audited By'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {inventoryTransactions.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-8 text-center text-slate-400">
                      {language === 'ar' ? 'لا توجد حركات تسوية أو خصم اليوم.' : 'No stock adjustments or automated POS deductions logged yet today.'}
                    </td>
                  </tr>
                ) : (
                  inventoryTransactions.map((tx) => {
                    const ing = ingredients.find((i) => i.id === tx.ingredientId);
                    const displayName = (language === 'ar' && ing?.nameAr) ? ing.nameAr : tx.ingredientName;
                    const displayUnit = (language === 'ar' && ing?.unitAr) ? ing.unitAr : getUnitLabel(tx.unit);

                    return (
                      <tr key={tx.id} className="hover:bg-slate-50/70 transition-colors">
                        <td className="py-3 px-4 font-mono text-slate-500">{tx.createdAt}</td>
                        <td className="py-3 px-4 font-bold text-slate-900">{displayName}</td>
                        <td className="py-3 px-4">
                          <span
                            className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                              tx.type === 'purchase_receipt'
                                ? 'bg-emerald-100 text-emerald-800'
                                : tx.type === 'sale_deduction'
                                ? 'bg-blue-100 text-blue-800'
                                : 'bg-rose-100 text-rose-800'
                            }`}
                          >
                            {getMovementTypeLabel(tx.type)}
                          </span>
                        </td>
                        <td
                          className={`py-3 px-4 font-mono font-extrabold ${
                            tx.quantityDelta > 0 ? 'text-emerald-600' : 'text-rose-600'
                          }`}
                        >
                          {tx.quantityDelta > 0 ? `+${tx.quantityDelta}` : tx.quantityDelta} {displayUnit}
                        </td>
                        <td className="py-3 px-4 font-mono">{settings.currencySymbol} {tx.unitCost.toFixed(2)}</td>
                        <td className="py-3 px-4 text-slate-600">{tx.reason}</td>
                        <td className="py-3 px-4 text-slate-500">{tx.staffName}</td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Adjust Stock / Log Waste Modal */}
      {showAdjustModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h3 className="font-extrabold text-base text-slate-900">
                {language === 'ar' ? 'تسجيل هدر أو تسوية مخزون' : 'Log Stock Variance or Spoilage'}
              </h3>
              <button onClick={() => setShowAdjustModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAdjustSubmit} className="space-y-3.5 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">{language === 'ar' ? 'اختر المادة الخام:' : 'Select Ingredient:'}</label>
                <select
                  value={adjustIngId}
                  onChange={(e) => setAdjustIngId(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-start"
                >
                  {ingredients.map((i) => (
                    <option key={i.id} value={i.id}>
                      {(language === 'ar' && i.nameAr) ? i.nameAr : i.name} ({language === 'ar' ? 'الرصيد:' : 'Stock:'} {i.currentStock} {(language === 'ar' && i.unitAr) ? i.unitAr : getUnitLabel(i.unit)})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">{language === 'ar' ? 'نوع التسوية:' : 'Adjustment Type:'}</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setAdjustType('waste_spoilage')}
                    className={`p-2 rounded-xl border text-center font-bold transition-all ${
                      adjustType === 'waste_spoilage'
                        ? 'border-rose-500 bg-rose-50 text-rose-800'
                        : 'border-slate-200 text-slate-600'
                    }`}
                  >
                    {language === 'ar' ? 'تالف وهدر مطبخ' : 'Kitchen Spoilage / Waste'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setAdjustType('manual_adjustment')}
                    className={`p-2 rounded-xl border text-center font-bold transition-all ${
                      adjustType === 'manual_adjustment'
                        ? 'border-indigo-500 bg-indigo-50 text-indigo-800'
                        : 'border-slate-200 text-slate-600'
                    }`}
                  >
                    {language === 'ar' ? 'فارق جرد فعلي' : 'Physical Count Audit'}
                  </button>
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  {language === 'ar' ? 'فارق الكمية (سالب للإنقاص، موجب للزيادة):' : 'Quantity Adjustment (Negative to decrease, positive to add):'}
                </label>
                <input
                  type="number"
                  step="0.1"
                  value={adjustDelta}
                  onChange={(e) => setAdjustDelta(parseFloat(e.target.value) || 0)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-mono text-start"
                  required
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">{language === 'ar' ? 'السبب أو المبرر:' : 'Reason / Explanation:'}</label>
                <input
                  type="text"
                  placeholder={language === 'ar' ? 'مثال: تاريخ الصلاحية منتهٍ، تسوية الجرد الأسبوعي...' : 'e.g. Expired dairy batch, burned during prep, physical count audit...'}
                  value={adjustReason}
                  onChange={(e) => setAdjustReason(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-start"
                  required
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAdjustModal(false)}
                  className="flex-1 py-2.5 border rounded-xl font-bold text-slate-600"
                >
                  {t.common.cancel}
                </button>
                <button
                  type="submit"
                  className="flex-2 py-2.5 bg-slate-900 text-white hover:bg-slate-800 rounded-xl font-bold"
                >
                  {language === 'ar' ? 'حفظ التسوية' : 'Record Adjustment'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add New Raw Ingredient Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h3 className="font-extrabold text-base text-slate-900">
                {t.inventory.addIngredient}
              </h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddIngredient} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">{t.inventory.ingredientCode}:</label>
                <input
                  type="text"
                  value={newCode}
                  onChange={(e) => setNewCode(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-mono text-start"
                  required
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">{language === 'ar' ? 'اسم المادة (عربي):' : 'Ingredient Name (Arabic):'}</label>
                <input
                  type="text"
                  placeholder="مثال: زيت زيتون بكر ممتاز"
                  value={newNameAr}
                  onChange={(e) => setNewNameAr(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-start"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">{language === 'ar' ? 'اسم المادة (إنجليزي):' : 'Ingredient Name (English):'}</label>
                <input
                  type="text"
                  placeholder="e.g. Extra Virgin Olive Oil PDO"
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-start"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">{t.inventory.category}:</label>
                  <select
                    value={newCat}
                    onChange={(e) => setNewCat(e.target.value as any)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-start"
                  >
                    {categories.filter((c) => c !== 'All').map((c) => (
                      <option key={c} value={c}>
                        {getCategoryLabel(c)}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">{t.inventory.unit}:</label>
                  <select
                    value={newUnit}
                    onChange={(e) => setNewUnit(e.target.value as any)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-start"
                  >
                    <option value="kg">{language === 'ar' ? 'كجم (kg)' : 'kg'}</option>
                    <option value="g">{language === 'ar' ? 'جم (g)' : 'g'}</option>
                    <option value="L">{language === 'ar' ? 'لتر (L)' : 'L'}</option>
                    <option value="ml">{language === 'ar' ? 'مل (ml)' : 'ml'}</option>
                    <option value="pcs">{language === 'ar' ? 'حبة (pcs)' : 'pcs'}</option>
                    <option value="pack">{language === 'ar' ? 'عبوة (pack)' : 'pack'}</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">{language === 'ar' ? 'الرصيد الحالي:' : 'Stock On Hand:'}</label>
                  <input
                    type="number"
                    step="0.1"
                    value={newStock}
                    onChange={(e) => setNewStock(parseFloat(e.target.value) || 0)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-mono text-end"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">{t.inventory.reorderLevel}:</label>
                  <input
                    type="number"
                    step="0.1"
                    value={newReorder}
                    onChange={(e) => setNewReorder(parseFloat(e.target.value) || 0)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-mono text-end"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">{language === 'ar' ? `التكلفة (${settings.currencySymbol}):` : `Cost / Unit (${settings.currencySymbol}):`}</label>
                  <input
                    type="number"
                    step="0.01"
                    value={newCost}
                    onChange={(e) => setNewCost(parseFloat(e.target.value) || 0)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-mono text-end"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">{language === 'ar' ? 'المورد الأساسي:' : 'Primary Supplier:'}</label>
                <select
                  value={newSupId}
                  onChange={(e) => setNewSupId(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-start"
                >
                  {suppliers.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 py-2.5 border rounded-xl font-bold text-slate-600"
                >
                  {t.common.cancel}
                </button>
                <button
                  type="submit"
                  className="flex-2 py-2.5 bg-orange-500 hover:bg-orange-600 text-white rounded-xl font-bold"
                >
                  {language === 'ar' ? 'حفظ المادة الخام' : 'Save Ingredient'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
