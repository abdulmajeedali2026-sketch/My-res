import React, { useState } from 'react';
import { useRestaurant } from '../../context/RestaurantContext';
import { Employee } from '../../types/erp';
import {
  UserCheck,
  Clock,
  DollarSign,
  TrendingUp,
  Plus,
  CheckCircle2,
  X,
  Phone,
  ShieldCheck,
  Utensils,
  Award,
} from 'lucide-react';

export const EmployeesModule: React.FC = () => {
  const { employees, setEmployees, settings, language, t } = useRestaurant();
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [feedback, setFeedback] = useState<string | null>(null);

  // Form states
  const [name, setName] = useState<string>('');
  const [role, setRole] = useState<Employee['role']>('Waiter');
  const [pin, setPin] = useState<string>('1234');
  const [hourlyWage, setHourlyWage] = useState<number>(35);

  const getRoleLabel = (r: string) => {
    if (language !== 'ar') return r;
    switch (r) {
      case 'Manager': return 'مدير صالة';
      case 'Chef': return 'شيف رئيسي';
      case 'Waiter': return 'مقدم طلبات (نادل)';
      case 'Cashier': return 'كاشير / أمين صندوق';
      case 'Bartender': return 'باريستا / صانع مشروبات';
      default: return r;
    }
  };

  const clockedInCount = employees.filter((e) => e.isClockedIn || e.status === 'clocked_in').length;
  const totalSalesToday = employees.reduce((s, e) => s + e.totalSalesToday, 0);

  const toggleClock = (id: string) => {
    setEmployees((prev: Employee[]) =>
      prev.map((emp: Employee) => {
        if (emp.id !== id) return emp;
        const isClockedIn = emp.isClockedIn || emp.status === 'clocked_in';
        const newStatus: 'clocked_in' | 'clocked_out' = isClockedIn ? 'clocked_out' : 'clocked_in';
        const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        return {
          ...emp,
          isClockedIn: !isClockedIn,
          status: newStatus,
          clockInTime: newStatus === 'clocked_in' ? timeStr : emp.clockInTime,
        };
      })
    );
    setFeedback(
      language === 'ar'
        ? 'تم تحديث حالة الحضور والانصراف للموظف بنجاح.'
        : 'Staff time clock status updated.'
    );
    setTimeout(() => setFeedback(null), 3000);
  };

  const handleAddEmployee = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name) return;

    const newEmp: Employee = {
      id: `emp-${Date.now()}`,
      name,
      role,
      pin,
      phone: '0555000000',
      email: `${name.toLowerCase().replace(/\s+/g, '')}@restaurant.com`,
      hourlyRate: hourlyWage,
      hourlyWage,
      isClockedIn: false,
      status: 'clocked_out',
      totalSalesToday: 0,
      tablesServedToday: 0,
    };

    setEmployees((prev: Employee[]) => [...prev, newEmp]);
    setShowAddModal(false);
    setFeedback(
      language === 'ar'
        ? `تم تسجيل الموظف الجديد (${name}) بنجاح.`
        : `New staff member ${name} registered.`
    );
    setName('');
    setTimeout(() => setFeedback(null), 4000);
  };

  return (
    <div className="flex-1 flex flex-col p-4 md:p-6 overflow-y-auto bg-slate-100">
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight">
            {t.employees.title}
          </h2>
          <p className="text-xs text-slate-500">
            {t.employees.subtitle}
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs shadow-md shadow-orange-200 transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>{t.employees.addEmployee}</span>
        </button>
      </div>

      {feedback && (
        <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 rounded-2xl text-emerald-800 text-xs font-semibold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{feedback}</span>
        </div>
      )}

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-6">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-xs text-slate-500 font-semibold block mb-1">
            {t.employees.activeStaff}
          </span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black text-emerald-600 font-mono">
              {clockedInCount} {language === 'ar' ? 'موظف' : 'Active'}
            </span>
            <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md">
              {t.employees.clockedIn}
            </span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-xs text-slate-500 font-semibold block mb-1">
            {language === 'ar' ? 'مبيعات الكادر اليوم' : 'Server Generated Sales'}
          </span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black text-slate-900 font-mono">
              {settings.currencySymbol} {totalSalesToday.toFixed(2)}
            </span>
            <span className="text-xs text-slate-400 font-medium">
              {language === 'ar' ? 'وردية اليوم' : "Today's Shift"}
            </span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-xs text-slate-500 font-semibold block mb-1">
            {t.employees.totalStaff}
          </span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black text-slate-900 font-mono">{employees.length}</span>
            <span className="text-xs text-slate-400 font-medium">{language === 'ar' ? 'مسجلين بالنظام' : 'Total Staff'}</span>
          </div>
        </div>
      </div>

      {/* Employees Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {employees.map((emp) => {
          const isClockedIn = emp.isClockedIn || emp.status === 'clocked_in';

          return (
            <div
              key={emp.id}
              className="bg-white rounded-2xl border border-slate-200 p-5 shadow-2xs flex flex-col justify-between"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-[10px] font-extrabold uppercase tracking-wider text-orange-600 bg-orange-50 px-2 py-0.5 rounded">
                      {getRoleLabel(emp.role)}
                    </span>
                    <h3 className="font-black text-base text-slate-900 mt-1">{emp.name}</h3>
                  </div>

                  <span
                    className={`text-[10px] font-bold px-2.5 py-1 rounded-full flex items-center gap-1 ${
                      isClockedIn
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    <Clock className="w-3 h-3" />
                    {isClockedIn
                      ? (language === 'ar' ? `حاضر منذ ${emp.clockInTime || emp.currentShiftStarted || '08:00'}` : `In at ${emp.clockInTime || emp.currentShiftStarted || '08:00'}`)
                      : t.employees.clockedOut}
                  </span>
                </div>

                {/* Performance stats */}
                <div className="grid grid-cols-2 gap-2 bg-slate-50 p-2.5 rounded-xl text-xs border border-slate-200/70">
                  <div>
                    <span className="text-[10px] text-slate-500 block">{t.employees.salesHandled}</span>
                    <span className="font-mono font-bold text-slate-900">
                      {settings.currencySymbol} {emp.totalSalesToday.toFixed(2)}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block">{t.employees.tablesServed}</span>
                    <span className="font-mono font-bold text-slate-900">
                      {emp.tablesServedToday} {language === 'ar' ? 'طاولة' : 'tables'}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block">{t.employees.hourlyRate}</span>
                    <span className="font-mono font-semibold text-slate-700">
                      {settings.currencySymbol} {(emp.hourlyRate || emp.hourlyWage || 35).toFixed(2)}/{language === 'ar' ? 'ساعة' : 'hr'}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] text-slate-500 block">{t.employees.pin}</span>
                    <span className="font-mono font-bold text-slate-700">****</span>
                  </div>
                </div>
              </div>

              {/* Action */}
              <div className="mt-4 pt-3 border-t border-slate-100">
                <button
                  onClick={() => toggleClock(emp.id)}
                  className={`w-full py-2 px-3 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-colors ${
                    isClockedIn
                      ? 'bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200'
                      : 'bg-slate-900 hover:bg-slate-800 text-white shadow-xs'
                  }`}
                >
                  <Clock className="w-3.5 h-3.5" />
                  <span>{isClockedIn ? t.employees.clockOut : t.employees.clockIn}</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add Employee Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h3 className="font-extrabold text-base text-slate-900">{t.employees.addEmployee}</h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddEmployee} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">{language === 'ar' ? 'اسم الموظف الكامل:' : 'Full Name:'}</label>
                <input
                  type="text"
                  placeholder={language === 'ar' ? 'مثال: فيصل العتيبي' : 'e.g. Liam Davies'}
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-start"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">{t.employees.role}:</label>
                  <select
                    value={role}
                    onChange={(e) => setRole(e.target.value as any)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-start"
                  >
                    <option value="Manager">{language === 'ar' ? 'مدير صالة' : 'Manager'}</option>
                    <option value="Chef">{language === 'ar' ? 'شيف رئيسي' : 'Chef'}</option>
                    <option value="Waiter">{language === 'ar' ? 'مقدم طلبات (نادل)' : 'Waiter / Server'}</option>
                    <option value="Cashier">{language === 'ar' ? 'كاشير / أمين صندوق' : 'Cashier'}</option>
                    <option value="Bartender">{language === 'ar' ? 'باريستا / صانع مشروبات' : 'Bartender'}</option>
                  </select>
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">
                    {language === 'ar' ? `الأجر بالساعة (${settings.currencySymbol}):` : `Hourly Wage (${settings.currencySymbol}):`}
                  </label>
                  <input
                    type="number"
                    step="0.5"
                    value={hourlyWage}
                    onChange={(e) => setHourlyWage(parseFloat(e.target.value) || 0)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-mono text-end"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  {language === 'ar' ? 'رمز الدخول السري لنظام الكاشير (4 أرقام):' : 'POS Security 4-digit PIN:'}
                </label>
                <input
                  type="password"
                  maxLength={4}
                  value={pin}
                  onChange={(e) => setPin(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-mono text-center tracking-widest text-sm"
                  required
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 py-2.5 border rounded-xl font-bold text-slate-600"
                >
                  {t.common.cancel}
                </button>
                <button
                  type="submit"
                  className="flex-2 py-2.5 bg-orange-500 hover:bg-orange-600 text-white rounded-xl font-bold"
                >
                  {t.common.save}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
