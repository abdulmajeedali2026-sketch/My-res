import React, { useState } from 'react';
import { useRestaurant } from '../../context/RestaurantContext';
import { Order } from '../../types/erp';
import { ReceiptModal } from '../pos/ReceiptModal';
import {
  Search,
  DollarSign,
  TrendingUp,
  Receipt,
  RotateCcw,
  CheckCircle2,
  AlertTriangle,
  FileText,
  Clock,
  Filter,
  Eye,
  CreditCard,
  Banknote,
  Smartphone,
  Sparkles,
} from 'lucide-react';

export const SalesModule: React.FC = () => {
  const { orders, cashRegister, settings, voidOrder, menuItems, language, t } = useRestaurant();
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [receiptOrder, setReceiptOrder] = useState<Order | null>(null);
  const [voidReason, setVoidReason] = useState<string>('');
  const [showVoidModal, setShowVoidModal] = useState<boolean>(false);

  // Filter orders
  const filteredOrders = orders.filter((o) => {
    const matchesSearch =
      o.orderNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (o.customerName && o.customerName.toLowerCase().includes(searchQuery.toLowerCase())) ||
      o.serverName.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' || o.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  // Analytics Metrics
  const completedOrders = orders.filter((o) => o.status === 'completed' || o.paymentStatus === 'paid');
  const totalRevenue = completedOrders.reduce((sum, o) => sum + o.total, 0);
  const totalOrdersCount = completedOrders.length;
  const averageCheck = totalOrdersCount > 0 ? totalRevenue / totalOrdersCount : 0;
  const totalTaxCollected = completedOrders.reduce((sum, o) => sum + o.taxAmount, 0);

  const handleVoidConfirm = () => {
    if (selectedOrder && voidReason) {
      voidOrder(selectedOrder.id, voidReason);
      setShowVoidModal(false);
      setSelectedOrder(null);
      setVoidReason('');
    }
  };

  const getStatusLabel = (status: string) => {
    if (language === 'ar') {
      switch (status) {
        case 'completed': return t.sales.statusCompleted;
        case 'preparing': return t.sales.statusPreparing;
        case 'ready': return t.sales.statusReady;
        case 'served': return t.sales.statusServed;
        case 'pending': return t.sales.statusPending;
        case 'voided': return t.sales.statusVoided;
        default: return status;
      }
    }
    return status;
  };

  const getPaymentMethodLabel = (method?: string) => {
    if (!method) return language === 'ar' ? 'غير مسدد' : 'Unpaid';
    if (language === 'ar') {
      switch (method) {
        case 'cash': return 'نقداً';
        case 'card': return 'بطاقة بنكية';
        case 'mobile_pay': return 'دفع إلكتروني';
        case 'customer_credit': return 'حساب آجل';
        default: return method;
      }
    }
    return method;
  };

  const getOrderTypeLabel = (type: string, tableNumber?: string) => {
    if (language === 'ar') {
      if (type === 'dine-in') return `محلي ${tableNumber ? `(طاولة ${tableNumber})` : ''}`;
      if (type === 'takeaway') return 'سفري';
      if (type === 'delivery') return 'توصيل';
      return type;
    }
    return `${type} ${tableNumber ? `(Table ${tableNumber})` : ''}`;
  };

  const filterTabs = [
    { id: 'all', label: t.sales.filterAll },
    { id: 'completed', label: t.sales.filterCompleted },
    { id: 'preparing', label: t.sales.statusPreparing },
    { id: 'ready', label: t.sales.statusReady },
    { id: 'voided', label: t.sales.filterVoided },
  ];

  return (
    <div className="flex-1 flex flex-col p-4 md:p-6 overflow-y-auto bg-slate-100">
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight">
            {t.sales.title}
          </h2>
          <p className="text-xs text-slate-500">
            {t.sales.subtitle}
          </p>
        </div>

        {/* Cash Register Till Snapshot */}
        <div className="flex items-center gap-3 bg-white p-2.5 rounded-2xl border border-slate-200 shadow-2xs">
          <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
            <DollarSign className="w-5 h-5" />
          </div>
          <div>
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
              {language === 'ar' ? 'رصيد الدرج النقدي' : 'Active Drawer Float'}
            </span>
            <span className="text-sm font-extrabold text-slate-900 font-mono">
              {settings.currencySymbol} {cashRegister.expectedCash.toFixed(2)}
            </span>
          </div>
          <div className="text-end ps-3 border-s border-slate-100 text-[11px]">
            <span className="text-slate-500 block">
              {language === 'ar' ? 'الافتتاحي:' : 'Opening:'} {settings.currencySymbol} {cashRegister.openingFloat.toFixed(2)}
            </span>
            <span className="text-emerald-600 font-bold">
              {language === 'ar' ? 'مبيعات الكاش:' : 'Cash Sales:'} +{settings.currencySymbol} {cashRegister.cashSales.toFixed(2)}
            </span>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-xs text-slate-500 font-semibold block mb-1">{t.sales.totalSales}</span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black text-slate-900 font-mono">
              {settings.currencySymbol} {totalRevenue.toFixed(2)}
            </span>
            <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md flex items-center gap-1">
              <TrendingUp className="w-3 h-3 rtl:rotate-180" /> +12%
            </span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-xs text-slate-500 font-semibold block mb-1">{t.sales.ordersCount}</span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black text-slate-900 font-mono">{totalOrdersCount}</span>
            <span className="text-xs text-slate-400 font-medium">{language === 'ar' ? 'طلب ناجح' : 'Orders'}</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-xs text-slate-500 font-semibold block mb-1">{t.sales.avgTicket}</span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black text-slate-900 font-mono">
              {settings.currencySymbol} {averageCheck.toFixed(2)}
            </span>
            <span className="text-xs text-slate-400 font-medium">{language === 'ar' ? 'لكل فاتورة' : 'Per Ticket'}</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-xs text-slate-500 font-semibold block mb-1">
            {language === 'ar' ? 'ضريبة القيمة المضافة' : 'Sales Tax / VAT'}
          </span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black text-slate-900 font-mono">
              {settings.currencySymbol} {totalTaxCollected.toFixed(2)}
            </span>
            <span className="text-xs text-slate-400 font-medium">
              {language === 'ar' ? 'ضريبة مستحقة' : 'Accrued Tax'}
            </span>
          </div>
        </div>
      </div>

      {/* Orders Table with Filters */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden flex flex-col flex-1">
        {/* Table Filters */}
        <div className="p-4 border-b border-slate-200/80 flex flex-wrap items-center justify-between gap-3">
          {/* Search */}
          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 absolute start-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder={language === 'ar' ? 'بحث برقم الفاتورة، العميل، النادل...' : 'Search by Order #, Guest, Server...'}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full ps-9 pe-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-hidden focus:border-orange-500 text-start"
            />
          </div>

          {/* Status Tabs */}
          <div className="flex items-center gap-1 overflow-x-auto pb-1">
            {filterTabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setStatusFilter(tab.id)}
                className={`px-3 py-1 rounded-lg text-xs font-bold capitalize transition-all ${
                  statusFilter === tab.id
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto flex-1">
          <table className="w-full text-start border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider text-[10px]">
                <th className="py-3 px-4">{t.sales.orderNumber}</th>
                <th className="py-3 px-4">{t.sales.type}</th>
                <th className="py-3 px-4">{language === 'ar' ? 'العميل' : 'Customer'}</th>
                <th className="py-3 px-4">{language === 'ar' ? 'الموظف / النادل' : 'Server'}</th>
                <th className="py-3 px-4">{t.sales.time}</th>
                <th className="py-3 px-4">{t.sales.itemsCount}</th>
                <th className="py-3 px-4">{t.sales.total}</th>
                <th className="py-3 px-4">{t.sales.payment}</th>
                <th className="py-3 px-4">{t.sales.status}</th>
                <th className="py-3 px-4 text-end">{t.sales.actions}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {filteredOrders.length === 0 ? (
                <tr>
                  <td colSpan={10} className="py-8 text-center text-slate-400 font-medium">
                    {language === 'ar' ? 'لا توجد طلبات تطابق شروط البحث.' : 'No orders found matching criteria.'}
                  </td>
                </tr>
              ) : (
                filteredOrders.map((ord) => (
                  <tr key={ord.id} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-slate-900">
                      {ord.orderNumber}
                    </td>
                    <td className="py-3 px-4">
                      <span className="capitalize font-semibold text-slate-900 block">
                        {getOrderTypeLabel(ord.orderType, ord.tableNumber)}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-medium text-slate-800">
                      {ord.customerName || (language === 'ar' ? 'عميل كاونتر' : 'Walk-in')}
                    </td>
                    <td className="py-3 px-4 text-slate-600">{ord.serverName}</td>
                    <td className="py-3 px-4 text-slate-500 font-mono">{ord.createdAt}</td>
                    <td className="py-3 px-4 font-medium text-slate-700">
                      {ord.items.reduce((s, i) => s + i.quantity, 0)} {language === 'ar' ? 'صنف' : 'items'}
                    </td>
                    <td className="py-3 px-4 font-mono font-extrabold text-slate-900">
                      {settings.currencySymbol} {ord.total.toFixed(2)}
                    </td>
                    <td className="py-3 px-4">
                      <span className="inline-flex items-center gap-1 uppercase font-bold text-[10px] text-slate-700 bg-slate-100 px-2 py-0.5 rounded">
                        {ord.paymentMethod === 'card' ? (
                          <CreditCard className="w-3 h-3 text-indigo-600" />
                        ) : ord.paymentMethod === 'cash' ? (
                          <Banknote className="w-3 h-3 text-emerald-600" />
                        ) : (
                          <Smartphone className="w-3 h-3 text-amber-600" />
                        )}
                        {getPaymentMethodLabel(ord.paymentMethod)}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full capitalize ${
                          ord.status === 'completed'
                            ? 'bg-emerald-100 text-emerald-800'
                            : ord.status === 'preparing'
                            ? 'bg-amber-100 text-amber-800'
                            : ord.status === 'ready'
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-rose-100 text-rose-800'
                        }`}
                      >
                        {getStatusLabel(ord.status)}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-end space-x-1 rtl:space-x-reverse">
                      <button
                        onClick={() => setSelectedOrder(ord)}
                        className="p-1.5 rounded-lg text-slate-500 hover:text-slate-900 hover:bg-slate-200 transition-colors"
                        title={t.sales.viewDetails}
                      >
                        <Eye className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => setReceiptOrder(ord)}
                        className="p-1.5 rounded-lg text-slate-500 hover:text-orange-600 hover:bg-orange-50 transition-colors"
                        title={t.sales.printReceipt}
                      >
                        <Receipt className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Order Details Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-5 shadow-2xl border border-slate-200 flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-3">
              <div>
                <span className="font-mono text-xs text-orange-600 font-bold block">
                  {selectedOrder.orderNumber}
                </span>
                <h3 className="font-extrabold text-base text-slate-900">
                  {selectedOrder.customerName || (language === 'ar' ? 'عميل كاونتر' : 'Walk-in')} &bull; {getOrderTypeLabel(selectedOrder.orderType, selectedOrder.tableNumber)}
                </h3>
              </div>
              <button
                onClick={() => setSelectedOrder(null)}
                className="w-8 h-8 rounded-full bg-slate-100 text-slate-500 hover:text-slate-900 flex items-center justify-center"
              >
                &times;
              </button>
            </div>

            {/* Items list */}
            <div className="space-y-2 mb-4 max-h-60 overflow-y-auto pe-1">
              {selectedOrder.items.map((it) => {
                const mi = menuItems.find((m) => m.id === it.menuItemId);
                const itemName = (language === 'ar' && mi?.nameAr) ? mi.nameAr : it.name;

                return (
                  <div
                    key={it.id}
                    className="flex items-center justify-between p-2 rounded-xl bg-slate-50 text-xs"
                  >
                    <div>
                      <span className="font-bold text-slate-900 block">
                        {it.quantity}x {itemName}
                      </span>
                      {it.kitchenNotes && (
                        <span className="text-[10px] text-amber-700 italic block">
                          {language === 'ar' ? 'ملاحظة:' : 'Note:'} {it.kitchenNotes}
                        </span>
                      )}
                    </div>
                    <span className="font-mono font-bold text-slate-900">
                      {settings.currencySymbol} {(it.price * it.quantity).toFixed(2)}
                    </span>
                  </div>
                );
              })}
            </div>

            {/* Totals */}
            <div className="bg-slate-50 p-3 rounded-2xl space-y-1 text-xs mb-4">
              <div className="flex justify-between text-slate-600">
                <span>{t.pos.subtotal}:</span>
                <span className="font-mono font-semibold">{settings.currencySymbol} {selectedOrder.subtotal.toFixed(2)}</span>
              </div>
              {selectedOrder.discountAmount > 0 && (
                <div className="flex justify-between text-rose-600">
                  <span>{t.pos.discount}:</span>
                  <span className="font-mono font-semibold">-{settings.currencySymbol} {selectedOrder.discountAmount.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between text-slate-600">
                <span>{t.pos.tax} ({settings.taxRatePercent}%):</span>
                <span className="font-mono font-semibold">{settings.currencySymbol} {selectedOrder.taxAmount.toFixed(2)}</span>
              </div>
              <div className="flex justify-between font-black text-sm text-slate-900 pt-1 border-t border-slate-200">
                <span>{t.pos.total}:</span>
                <span className="font-mono text-orange-600">{settings.currencySymbol} {selectedOrder.total.toFixed(2)}</span>
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-2">
              <button
                onClick={() => {
                  setReceiptOrder(selectedOrder);
                  setSelectedOrder(null);
                }}
                className="flex-1 py-2.5 rounded-xl bg-slate-900 text-white text-xs font-bold flex items-center justify-center gap-1.5 hover:bg-slate-800"
              >
                <Receipt className="w-4 h-4" />
                <span>{t.sales.printReceipt}</span>
              </button>

              {selectedOrder.status !== 'voided' && (
                <button
                  onClick={() => setShowVoidModal(true)}
                  className="py-2.5 px-4 rounded-xl border border-rose-200 text-rose-600 hover:bg-rose-50 text-xs font-bold"
                >
                  {language === 'ar' ? 'إلغاء الطلب' : 'Void Order'}
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Void Modal */}
      {showVoidModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-4 border border-rose-200 shadow-2xl">
            <h4 className="font-bold text-slate-900 text-sm mb-2 text-rose-600 flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4" />
              {language === 'ar' ? `إلغاء الفاتورة #${selectedOrder?.orderNumber}` : `Void Order #${selectedOrder?.orderNumber}`}
            </h4>
            <p className="text-xs text-slate-500 mb-3">
              {language === 'ar'
                ? 'يتطلب سبباً للإلغاء من قبل المشرف. يقوم هذا الإجراء بعكس القيد المالي في الدفتر المحاسبي.'
                : 'Requires reason for manager authorization. Reverses sales ledger entry.'}
            </p>
            <input
              type="text"
              placeholder={language === 'ar' ? 'مثال: خطأ في إدخال الطلب، إلغاء من قبل العميل...' : 'e.g. Customer walked out, wrong order placed...'}
              value={voidReason}
              onChange={(e) => setVoidReason(e.target.value)}
              className="w-full p-2 border border-slate-300 rounded-xl text-xs mb-3 text-start"
            />
            <div className="flex gap-2">
              <button
                onClick={() => setShowVoidModal(false)}
                className="flex-1 py-2 border rounded-xl text-xs font-bold text-slate-600"
              >
                {t.common.cancel}
              </button>
              <button
                disabled={!voidReason}
                onClick={handleVoidConfirm}
                className="flex-1 py-2 bg-rose-600 text-white rounded-xl text-xs font-bold hover:bg-rose-700 disabled:opacity-40"
              >
                {language === 'ar' ? 'تأكيد الإلغاء' : 'Confirm Void'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Receipt Preview */}
      <ReceiptModal order={receiptOrder} onClose={() => setReceiptOrder(null)} />
    </div>
  );
};
