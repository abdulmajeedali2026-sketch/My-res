import React, { useState } from 'react';
import { useRestaurant } from '../../context/RestaurantContext';
import {
  Calculator,
  DollarSign,
  Plus,
  ArrowDownRight,
  ArrowUpRight,
  FileText,
  TrendingUp,
  Scale,
  CheckCircle2,
  X,
  Sparkles,
} from 'lucide-react';

export const AccountingModule: React.FC = () => {
  const { accounts, journalEntries, settings, recordExpenseVoucher, language, t } = useRestaurant();
  const [activeTab, setActiveTab] = useState<'pl' | 'journal' | 'coa' | 'balance'>('pl');

  // Expense modal
  const [showExpenseModal, setShowExpenseModal] = useState<boolean>(false);
  const [expDescription, setExpDescription] = useState<string>('');
  const [expAccountCode, setExpAccountCode] = useState<string>('6030'); // Utilities
  const [payAccountCode, setPayAccountCode] = useState<string>('1010'); // Cash on hand
  const [expAmount, setExpAmount] = useState<number>(120);
  const [feedback, setFeedback] = useState<string | null>(null);

  // Helper translations for Chart of Accounts
  const getAccountName = (code: string, originalName: string) => {
    if (language !== 'ar') return originalName;
    const arabicNames: Record<string, string> = {
      '1010': 'النقدية في الصندوق (نقطة البيع)',
      '1020': 'الحساب البنكي الجاري للمطعم',
      '1050': 'مخزون المواد الخام الغذائية',
      '2010': 'حسابات الموردين الدائنة (ذمم دائنة)',
      '2020': 'ضريبة القيمة المضافة المستحقة (VAT)',
      '3010': 'رأس مال الشركاء والمؤسسين',
      '3020': 'الأرباح المبقاة والمرحلة',
      '4010': 'إيرادات مبيعات الطعام والوجبات',
      '4020': 'إيرادات مبيعات المشروبات والقهوة',
      '5010': 'تكلفة البضاعة المباعة - مأكولات (COGS)',
      '5020': 'تكلفة البضاعة المباعة - مشروبات (COGS)',
      '6010': 'رواتب وأجور طاقم العمل',
      '6020': 'إيجار مقر ومرافق المطعم',
      '6030': 'المرافق التشغيلية (كهرباء، ماء، غاز)',
      '6040': 'مصاريف التسويق والحملات الترويجية',
      '6050': 'مصاريف الصيانة ومعدات المطبخ',
      '6060': 'خسائر هدر وتالف المطبخ',
    };
    return arabicNames[code] || originalName;
  };

  const getAccountTypeLabel = (type: string) => {
    if (language !== 'ar') return type;
    switch (type) {
      case 'Asset': return 'أصول';
      case 'Liability': return 'خصوم والتزامات';
      case 'Equity': return 'حقوق الملكية';
      case 'Revenue': return 'إيرادات';
      case 'Expense': return 'مصروفات';
      default: return type;
    }
  };

  const getSubCategoryLabel = (sub: string) => {
    if (language !== 'ar') return sub;
    switch (sub) {
      case 'Current Assets': return 'أصول متداولة';
      case 'Current Liabilities': return 'خصوم متداولة';
      case 'Equity': return 'حقوق المساهمين';
      case 'Operating Revenue': return 'إيرادات تشغيلية';
      case 'COGS': return 'تكلفة البضاعة (COGS)';
      case 'Operating Expenses': return 'مصاريف تشغيلية (OPEX)';
      default: return sub;
    }
  };

  // Financial Calculations
  const revenueAccounts = accounts.filter((a) => a.type === 'Revenue');
  const cogsAccounts = accounts.filter((a) => a.type === 'Expense' && a.subCategory === 'COGS');
  const opexAccounts = accounts.filter((a) => a.type === 'Expense' && a.subCategory === 'Operating Expenses');
  const assetAccounts = accounts.filter((a) => a.type === 'Asset');
  const liabilityAccounts = accounts.filter((a) => a.type === 'Liability');
  const equityAccounts = accounts.filter((a) => a.type === 'Equity');

  const totalRevenue = revenueAccounts.reduce((sum, a) => sum + a.balance, 0);
  const totalCogs = cogsAccounts.reduce((sum, a) => sum + a.balance, 0);
  const grossProfit = totalRevenue - totalCogs;
  const grossMarginPct = totalRevenue > 0 ? (grossProfit / totalRevenue) * 100 : 0;
  const totalOpex = opexAccounts.reduce((sum, a) => sum + a.balance, 0);
  const netOperatingIncome = grossProfit - totalOpex;
  const netMarginPct = totalRevenue > 0 ? (netOperatingIncome / totalRevenue) * 100 : 0;

  const totalAssets = assetAccounts.reduce((sum, a) => sum + a.balance, 0);
  const totalLiabilities = liabilityAccounts.reduce((sum, a) => sum + a.balance, 0);
  const totalEquity = equityAccounts.reduce((sum, a) => sum + a.balance, 0) + netOperatingIncome;

  const handleCreateExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (!expDescription || expAmount <= 0) return;

    recordExpenseVoucher(expDescription, expAccountCode, payAccountCode, expAmount);
    setShowExpenseModal(false);
    setFeedback(
      language === 'ar'
        ? `تم تسجيل سند الصرف بنجاح بقيمة ${settings.currencySymbol} ${expAmount.toFixed(2)} - ${expDescription}`
        : `Expense voucher recorded: ${settings.currencySymbol} ${expAmount.toFixed(2)} - ${expDescription}`
    );
    setExpDescription('');
    setTimeout(() => setFeedback(null), 4000);
  };

  return (
    <div className="flex-1 flex flex-col p-4 md:p-6 overflow-y-auto bg-slate-100">
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight">
            {t.accounting.title}
          </h2>
          <p className="text-xs text-slate-500">
            {t.accounting.subtitle}
          </p>
        </div>

        <button
          onClick={() => setShowExpenseModal(true)}
          className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs shadow-md transition-colors"
        >
          <Plus className="w-4 h-4 text-orange-400" />
          <span>{t.accounting.recordExpense}</span>
        </button>
      </div>

      {feedback && (
        <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 rounded-2xl text-emerald-800 text-xs font-semibold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{feedback}</span>
        </div>
      )}

      {/* Financial KPIs */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-6">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-xs text-slate-500 font-semibold block mb-1">
            {language === 'ar' ? 'الإيرادات التشغيلية' : 'Operating Revenue'}
          </span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black text-slate-900 font-mono">
              {settings.currencySymbol} {totalRevenue.toFixed(2)}
            </span>
            <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md">
              100%
            </span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-xs text-slate-500 font-semibold block mb-1">
            {language === 'ar' ? 'تكلفة المبيعات (COGS)' : 'Cost of Goods (COGS)'}
          </span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black text-rose-600 font-mono">
              {settings.currencySymbol} {totalCogs.toFixed(2)}
            </span>
            <span className="text-xs font-medium text-rose-700 bg-rose-50 px-2 py-0.5 rounded-md">
              {((totalCogs / (totalRevenue || 1)) * 100).toFixed(1)}% {language === 'ar' ? 'من المبيعات' : 'of sales'}
            </span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-xs text-slate-500 font-semibold block mb-1">
            {language === 'ar' ? 'إجمالي الربح (الهامش)' : 'Gross Margin'}
          </span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black text-slate-900 font-mono">
              {settings.currencySymbol} {grossProfit.toFixed(2)}
            </span>
            <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md">
              {grossMarginPct.toFixed(1)}%
            </span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-xs text-slate-500 font-semibold block mb-1">
            {language === 'ar' ? 'صافي الدخل التشغيلي' : 'Net Operating Income'}
          </span>
          <div className="flex items-baseline justify-between">
            <span
              className={`text-2xl font-black font-mono ${
                netOperatingIncome >= 0 ? 'text-emerald-700' : 'text-rose-600'
              }`}
            >
              {settings.currencySymbol} {netOperatingIncome.toFixed(2)}
            </span>
            <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md">
              {netMarginPct.toFixed(1)}% {language === 'ar' ? 'صافي' : 'Net'}
            </span>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 mb-4 pb-2 overflow-x-auto">
        {[
          { id: 'pl' as const, label: t.accounting.pnl, icon: TrendingUp },
          { id: 'journal' as const, label: t.accounting.journalEntries, icon: FileText },
          { id: 'coa' as const, label: t.accounting.chartOfAccounts, icon: Calculator },
          { id: 'balance' as const, label: t.accounting.balanceSheet, icon: Scale },
        ].map((tabItem) => {
          const Icon = tabItem.icon;
          const isActive = activeTab === tabItem.id;
          return (
            <button
              key={tabItem.id}
              onClick={() => setActiveTab(tabItem.id)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'text-slate-600 hover:bg-slate-200/70'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tabItem.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab 1: P&L Statement */}
      {activeTab === 'pl' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-2xs max-w-4xl mx-auto w-full">
          <div className="text-center pb-4 border-b border-slate-200 mb-6">
            <h3 className="font-black text-lg text-slate-900 tracking-tight">
              {settings.restaurantName}
            </h3>
            <p className="text-xs font-bold text-slate-500">
              {language === 'ar' ? 'قائمة الدخل والأرباح والخسائر (P&L)' : 'Statement of Income & Expenses (P&L)'}
            </p>
            <p className="text-[11px] text-slate-400 font-mono">
              {language === 'ar' ? 'الفترة المالية الحالية (سبتمبر 2026)' : 'Fiscal Period: Month to Date (September 2026)'}
            </p>
          </div>

          <div className="space-y-6 text-xs text-slate-700">
            {/* Revenue */}
            <div>
              <div className="flex justify-between items-center bg-slate-50 p-2.5 rounded-xl font-bold text-slate-900 mb-2 border border-slate-200">
                <span className="uppercase tracking-wider text-[11px]">
                  {language === 'ar' ? 'الإيرادات التشغيلية' : 'Operating Revenue'}
                </span>
                <span className="font-mono text-sm">{settings.currencySymbol} {totalRevenue.toFixed(2)}</span>
              </div>
              <div className="ps-4 pe-2 space-y-1.5">
                {revenueAccounts.map((acc) => (
                  <div key={acc.code} className="flex justify-between py-1 border-b border-slate-100">
                    <span>
                      <span className="font-mono text-slate-400 me-2">{acc.code}</span>
                      {getAccountName(acc.code, acc.name)}
                    </span>
                    <span className="font-mono font-medium">{settings.currencySymbol} {acc.balance.toFixed(2)}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* COGS */}
            <div>
              <div className="flex justify-between items-center bg-rose-50/70 p-2.5 rounded-xl font-bold text-rose-950 mb-2 border border-rose-100">
                <span className="uppercase tracking-wider text-[11px]">
                  {language === 'ar' ? 'تكلفة البضاعة المباعة (COGS)' : 'Cost of Goods Sold (COGS)'}
                </span>
                <span className="font-mono text-sm text-rose-700">-{settings.currencySymbol} {totalCogs.toFixed(2)}</span>
              </div>
              <div className="ps-4 pe-2 space-y-1.5">
                {cogsAccounts.map((acc) => (
                  <div key={acc.code} className="flex justify-between py-1 border-b border-slate-100">
                    <span>
                      <span className="font-mono text-slate-400 me-2">{acc.code}</span>
                      {getAccountName(acc.code, acc.name)}
                    </span>
                    <span className="font-mono font-medium text-slate-800">{settings.currencySymbol} {acc.balance.toFixed(2)}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Gross Profit Summary Bar */}
            <div className="bg-slate-900 text-white p-3 rounded-xl flex items-center justify-between font-extrabold text-sm">
              <span>{language === 'ar' ? 'إجمالي الربح (مجمل الربح)' : 'GROSS PROFIT'}</span>
              <div className="flex items-center gap-3">
                <span className="text-xs text-emerald-400 font-normal">
                  {language === 'ar' ? 'الهامش:' : 'Margin:'} {grossMarginPct.toFixed(1)}%
                </span>
                <span className="font-mono text-emerald-400">{settings.currencySymbol} {grossProfit.toFixed(2)}</span>
              </div>
            </div>

            {/* Operating Expenses */}
            <div>
              <div className="flex justify-between items-center bg-slate-50 p-2.5 rounded-xl font-bold text-slate-900 mb-2 border border-slate-200">
                <span className="uppercase tracking-wider text-[11px]">
                  {language === 'ar' ? 'المصاريف التشغيلية (OPEX)' : 'Operating Expenses (OPEX)'}
                </span>
                <span className="font-mono text-sm text-slate-900">-{settings.currencySymbol} {totalOpex.toFixed(2)}</span>
              </div>
              <div className="ps-4 pe-2 space-y-1.5">
                {opexAccounts.map((acc) => (
                  <div key={acc.code} className="flex justify-between py-1 border-b border-slate-100">
                    <span>
                      <span className="font-mono text-slate-400 me-2">{acc.code}</span>
                      {getAccountName(acc.code, acc.name)}
                    </span>
                    <span className="font-mono font-medium">{settings.currencySymbol} {acc.balance.toFixed(2)}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Net Operating Income Result */}
            <div className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white p-4 rounded-2xl flex items-center justify-between font-black text-base shadow-xs">
              <div>
                <span>{language === 'ar' ? 'صافي الدخل التشغيلي' : 'NET OPERATING INCOME'}</span>
                <span className="block text-xs font-normal text-emerald-100">
                  {language === 'ar' ? 'الأرباح الصافية بعد تكلفة البضاعة والمصاريف العامة' : 'Bottom-line profit after COGS and overhead'}
                </span>
              </div>
              <div className="text-end">
                <span className="font-mono text-xl">{settings.currencySymbol} {netOperatingIncome.toFixed(2)}</span>
                <span className="block text-xs text-emerald-100 font-normal">
                  {language === 'ar' ? 'هامش الربح الصافي:' : 'Net Margin:'} {netMarginPct.toFixed(1)}%
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: General Journal */}
      {activeTab === 'journal' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden flex-1">
          <div className="p-4 border-b border-slate-200/80 flex items-center justify-between">
            <h3 className="font-extrabold text-sm text-slate-900">{t.accounting.journalEntries}</h3>
            <span className="text-xs text-slate-400 font-mono">
              {journalEntries.length} {language === 'ar' ? 'قيد محاسبي مسجل' : 'Double-Entry Transactions'}
            </span>
          </div>

          <div className="p-4 space-y-4 max-h-[70vh] overflow-y-auto">
            {journalEntries.map((je) => (
              <div
                key={je.id}
                className="bg-slate-50 border border-slate-200/80 rounded-2xl p-3.5 space-y-2 text-xs"
              >
                <div className="flex flex-wrap items-center justify-between gap-2 pb-2 border-b border-slate-200">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-orange-600 bg-orange-50 px-2 py-0.5 rounded border border-orange-200">
                      {je.entryNumber}
                    </span>
                    <span className="font-bold text-slate-900">{je.description}</span>
                  </div>
                  <div className="flex items-center gap-2 text-[11px] text-slate-500 font-mono">
                    <span>{je.date}</span>
                    <span>&bull;</span>
                    <span>{language === 'ar' ? 'المسؤول:' : 'By:'} {je.createdBy}</span>
                  </div>
                </div>

                {/* Lines */}
                <table className="w-full text-start border-collapse text-[11px]">
                  <thead>
                    <tr className="text-slate-400 font-semibold border-b border-slate-200">
                      <th className="py-1">{language === 'ar' ? 'رمز واسم الحساب' : 'Account Code & Description'}</th>
                      <th className="py-1 text-end w-28">{language === 'ar' ? 'مدين (Debit)' : 'Debit'}</th>
                      <th className="py-1 text-end w-28">{language === 'ar' ? 'دائن (Credit)' : 'Credit'}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {je.lines.map((ln, i) => (
                      <tr key={i} className="text-slate-700">
                        <td className="py-1">
                          <span className="font-mono font-bold text-slate-800 me-2">{ln.accountCode}</span>
                          <span>{getAccountName(ln.accountCode, ln.accountName)}</span>
                        </td>
                        <td className="py-1 text-end font-mono font-bold text-slate-900">
                          {ln.debit > 0 ? `${settings.currencySymbol} ${ln.debit.toFixed(2)}` : '-'}
                        </td>
                        <td className="py-1 text-end font-mono font-bold text-slate-900">
                          {ln.credit > 0 ? `${settings.currencySymbol} ${ln.credit.toFixed(2)}` : '-'}
                        </td>
                      </tr>
                    ))}
                    <tr className="font-bold border-t border-slate-300 text-slate-900">
                      <td className="py-1 text-[10px] text-slate-500">{language === 'ar' ? 'الإجمالي (قيد متوازن):' : 'Totals (Balanced):'}</td>
                      <td className="py-1 text-end font-mono text-emerald-700">
                        {settings.currencySymbol} {je.totalDebit.toFixed(2)}
                      </td>
                      <td className="py-1 text-end font-mono text-emerald-700">
                        {settings.currencySymbol} {je.totalCredit.toFixed(2)}
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: Chart of Accounts */}
      {activeTab === 'coa' && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-2xs overflow-hidden flex-1">
          <div className="p-4 border-b border-slate-200/80">
            <h3 className="font-extrabold text-sm text-slate-900">{t.accounting.chartOfAccounts}</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-start border-collapse text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-500 font-bold uppercase tracking-wider text-[10px]">
                  <th className="py-3 px-4">{language === 'ar' ? 'رمز الحساب' : 'Account Code'}</th>
                  <th className="py-3 px-4">{language === 'ar' ? 'اسم الحساب' : 'Account Name'}</th>
                  <th className="py-3 px-4">{language === 'ar' ? 'النوع' : 'Type'}</th>
                  <th className="py-3 px-4">{language === 'ar' ? 'التصنيف الفرعي' : 'Sub-Category'}</th>
                  <th className="py-3 px-4 text-end">{language === 'ar' ? 'الرصيد الحالي' : 'Current Balance'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-slate-700">
                {accounts.map((acc) => (
                  <tr key={acc.code} className="hover:bg-slate-50/70 transition-colors">
                    <td className="py-3 px-4 font-mono font-bold text-slate-900">{acc.code}</td>
                    <td className="py-3 px-4 font-semibold text-slate-800">{getAccountName(acc.code, acc.name)}</td>
                    <td className="py-3 px-4">
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                          acc.type === 'Asset'
                            ? 'bg-blue-100 text-blue-800'
                            : acc.type === 'Liability'
                            ? 'bg-rose-100 text-rose-800'
                            : acc.type === 'Revenue'
                            ? 'bg-emerald-100 text-emerald-800'
                            : acc.type === 'Expense'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-purple-100 text-purple-800'
                        }`}
                      >
                        {getAccountTypeLabel(acc.type)}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-500">{getSubCategoryLabel(acc.subCategory)}</td>
                    <td className="py-3 px-4 text-end font-mono font-extrabold text-slate-900">
                      {settings.currencySymbol} {acc.balance.toFixed(2)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 4: Balance Sheet */}
      {activeTab === 'balance' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-2xs max-w-4xl mx-auto w-full">
          <div className="text-center pb-4 border-b border-slate-200 mb-6">
            <h3 className="font-black text-lg text-slate-900 tracking-tight">
              {settings.restaurantName}
            </h3>
            <p className="text-xs font-bold text-slate-500">{language === 'ar' ? 'الميزانية العمومية' : 'Balance Sheet Snapshot'}</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
            {/* Assets */}
            <div className="space-y-4">
              <div className="bg-blue-50 border border-blue-200 p-3 rounded-xl flex items-center justify-between font-bold text-blue-950">
                <span>{language === 'ar' ? 'إجمالي الأصول' : 'TOTAL ASSETS'}</span>
                <span className="font-mono text-base">{settings.currencySymbol} {totalAssets.toFixed(2)}</span>
              </div>
              <div className="space-y-1.5 ps-2">
                {assetAccounts.map((a) => (
                  <div key={a.code} className="flex justify-between py-1 border-b border-slate-100">
                    <span>
                      <span className="font-mono text-slate-400 me-2">{a.code}</span>
                      {getAccountName(a.code, a.name)}
                    </span>
                    <span className="font-mono font-semibold">{settings.currencySymbol} {a.balance.toFixed(2)}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Liabilities & Equity */}
            <div className="space-y-4">
              <div className="bg-rose-50 border border-rose-200 p-3 rounded-xl flex items-center justify-between font-bold text-rose-950">
                <span>{language === 'ar' ? 'إجمالي الخصوم وحقوق الملكية' : 'TOTAL LIABILITIES & EQUITY'}</span>
                <span className="font-mono text-base">{settings.currencySymbol} {(totalLiabilities + totalEquity).toFixed(2)}</span>
              </div>

              <div>
                <span className="font-bold text-slate-500 text-[10px] uppercase block mb-1">
                  {language === 'ar' ? 'الخصوم والالتزامات' : 'Liabilities'}
                </span>
                <div className="space-y-1.5 ps-2">
                  {liabilityAccounts.map((a) => (
                    <div key={a.code} className="flex justify-between py-1 border-b border-slate-100">
                      <span>
                        <span className="font-mono text-slate-400 me-2">{a.code}</span>
                        {getAccountName(a.code, a.name)}
                      </span>
                      <span className="font-mono font-semibold">{settings.currencySymbol} {a.balance.toFixed(2)}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-2">
                <span className="font-bold text-slate-500 text-[10px] uppercase block mb-1">
                  {language === 'ar' ? 'حقوق الملكية وصافي الأرباح' : 'Owners Equity & Net Income'}
                </span>
                <div className="space-y-1.5 ps-2">
                  {equityAccounts.map((a) => (
                    <div key={a.code} className="flex justify-between py-1 border-b border-slate-100">
                      <span>
                        <span className="font-mono text-slate-400 me-2">{a.code}</span>
                        {getAccountName(a.code, a.name)}
                      </span>
                      <span className="font-mono font-semibold">{settings.currencySymbol} {a.balance.toFixed(2)}</span>
                    </div>
                  ))}
                  <div className="flex justify-between py-1 border-b border-slate-100 text-emerald-700 font-bold">
                    <span>{language === 'ar' ? 'صافي أرباح الفترة الحالية' : 'Current Period Net Earnings'}</span>
                    <span className="font-mono">{settings.currencySymbol} {netOperatingIncome.toFixed(2)}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Record Expense Voucher Modal */}
      {showExpenseModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h3 className="font-extrabold text-base text-slate-900">{t.accounting.recordExpense}</h3>
              <button onClick={() => setShowExpenseModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateExpense} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">{language === 'ar' ? 'بيان / وصف المصروف:' : 'Expense Description:'}</label>
                <input
                  type="text"
                  placeholder={language === 'ar' ? 'مثال: فاتورة كهرباء المطعم، صيانة ثلاجة التبريد...' : 'e.g. Commercial Gas bill, Walk-in freezer repair...'}
                  value={expDescription}
                  onChange={(e) => setExpDescription(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-start"
                  required
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">{language === 'ar' ? 'حساب المصروف المدين:' : 'Debit Expense Account:'}</label>
                <select
                  value={expAccountCode}
                  onChange={(e) => setExpAccountCode(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-start"
                >
                  {opexAccounts.map((a) => (
                    <option key={a.code} value={a.code}>
                      {a.code} - {getAccountName(a.code, a.name)}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">{language === 'ar' ? 'مصدر الدفع الدائن:' : 'Credit Payment Source:'}</label>
                <select
                  value={payAccountCode}
                  onChange={(e) => setPayAccountCode(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-start"
                >
                  <option value="1010">{language === 'ar' ? '1010 - النقدية في الصندوق (الخزينة)' : '1010 - Cash on Hand (Till / Register)'}</option>
                  <option value="1020">{language === 'ar' ? '1020 - الحساب البنكي الجاري' : '1020 - Operating Bank Account'}</option>
                </select>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">{language === 'ar' ? `المبلغ (${settings.currencySymbol}):` : `Amount (${settings.currencySymbol}):`}</label>
                <input
                  type="number"
                  step="0.01"
                  min="0.01"
                  value={expAmount}
                  onChange={(e) => setExpAmount(parseFloat(e.target.value) || 0)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-mono text-end"
                  required
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowExpenseModal(false)}
                  className="flex-1 py-2.5 border rounded-xl font-bold text-slate-600"
                >
                  {t.common.cancel}
                </button>
                <button
                  type="submit"
                  className="flex-2 py-2.5 bg-slate-900 text-white hover:bg-slate-800 rounded-xl font-bold"
                >
                  {language === 'ar' ? 'حفظ سند الصرف' : 'Record Voucher'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
