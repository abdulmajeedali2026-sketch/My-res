import React, { useState } from 'react';
import { useRestaurant } from '../../context/RestaurantContext';
import { MenuItem } from '../../types/erp';
import { Search, Plus, Clock, Sparkles, AlertCircle } from 'lucide-react';

export const MenuGrid: React.FC = () => {
  const { menuItems, addToCart, settings, ingredients, language, t } = useRestaurant();
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');

  const categoryList: { key: string; label: string }[] = [
    { key: 'All', label: t.pos.allDishes },
    { key: 'Starters', label: t.pos.starters },
    { key: 'Steaks & Grills', label: t.pos.steaks },
    { key: 'Pizza & Pasta', label: t.pos.pizzaPasta },
    { key: 'Seafood', label: t.pos.seafood },
    { key: 'Desserts', label: t.pos.desserts },
    { key: 'Beverages', label: t.pos.beverages },
  ];

  const filteredItems = menuItems.filter((item) => {
    const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
    const itemName = (language === 'ar' && item.nameAr) ? item.nameAr : item.name;
    const itemDesc = (language === 'ar' && item.descriptionAr) ? item.descriptionAr : item.description;
    const q = searchQuery.toLowerCase();
    const matchesSearch =
      itemName.toLowerCase().includes(q) ||
      item.name.toLowerCase().includes(q) ||
      item.code.toLowerCase().includes(q) ||
      itemDesc.toLowerCase().includes(q);
    return matchesCategory && matchesSearch;
  });

  // Check if any recipe BOM ingredient is out of stock
  const isIngredientAvailable = (item: MenuItem): boolean => {
    if (!item.recipeBom || item.recipeBom.length === 0) return true;
    for (const bom of item.recipeBom) {
      const ing = ingredients.find((i) => i.id === bom.ingredientId);
      if (ing && ing.currentStock < bom.quantity) {
        return false;
      }
    }
    return true;
  };

  return (
    <div className="flex-1 flex flex-col min-w-0">
      {/* Category Pills & Search */}
      <div className="space-y-2 mb-3">
        <div className="flex items-center gap-2">
          {/* Search Bar */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute start-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder={t.pos.searchPlaceholder}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full ps-9 pe-4 py-2 bg-white border border-slate-200 rounded-xl text-xs font-medium text-slate-800 placeholder-slate-400 focus:outline-hidden focus:border-orange-500 focus:ring-1 focus:ring-orange-500 shadow-2xs"
            />
          </div>
        </div>

        {/* Categories Bar */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {categoryList.map((cat) => (
            <button
              key={cat.key}
              onClick={() => setSelectedCategory(cat.key)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all ${
                selectedCategory === cat.key
                  ? 'bg-orange-500 text-white shadow-xs'
                  : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200/80'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Menu Cards Grid */}
      <div className="flex-1 overflow-y-auto pr-1 rtl:pr-0 rtl:pl-1">
        <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-3 xl:grid-cols-3 gap-3">
          {filteredItems.map((item) => {
            const inStock = isIngredientAvailable(item);
            const margin = Math.round(((item.price - item.cost) / item.price) * 100);
            const displayName = (language === 'ar' && item.nameAr) ? item.nameAr : item.name;
            const displayDesc = (language === 'ar' && item.descriptionAr) ? item.descriptionAr : item.description;

            return (
              <div
                key={item.id}
                onClick={() => inStock && addToCart(item)}
                className={`group bg-white rounded-2xl border border-slate-200/90 overflow-hidden flex flex-col justify-between transition-all relative ${
                  inStock
                    ? 'hover:border-orange-400 hover:shadow-md cursor-pointer'
                    : 'opacity-60 cursor-not-allowed bg-slate-50'
                }`}
              >
                {/* Image & Badges */}
                <div className="relative h-32 w-full overflow-hidden bg-slate-100">
                  <img
                    src={item.imageUrl}
                    alt={displayName}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"></div>

                  {/* Dietary & Time Badges */}
                  <div className="absolute top-2 start-2 flex flex-wrap gap-1">
                    {item.dietary?.map((tag) => (
                      <span
                        key={tag}
                        className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-black/60 backdrop-blur-xs text-white border border-white/20"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>

                  <div className="absolute bottom-2 start-2 end-2 flex items-center justify-between text-white">
                    <span className="text-[10px] font-medium flex items-center gap-1 bg-black/40 px-1.5 py-0.5 rounded backdrop-blur-xs">
                      <Clock className="w-2.5 h-2.5" /> {item.preparationTimeMinutes} {language === 'ar' ? 'د' : 'm'}
                    </span>
                    <span className="text-[10px] font-mono font-semibold text-orange-200">
                      {language === 'ar' ? 'الربح' : 'Margin'}: {margin}%
                    </span>
                  </div>

                  {!inStock && (
                    <div className="absolute inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center text-rose-300 font-bold text-xs gap-1">
                      <AlertCircle className="w-4 h-4" />
                      <span>{language === 'ar' ? 'المكونات غير متوفرة' : 'Out of Ingredients'}</span>
                    </div>
                  )}
                </div>

                {/* Card Content */}
                <div className="p-3 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex items-start justify-between gap-1 mb-1">
                      <h3 className="font-bold text-slate-900 text-xs leading-snug line-clamp-1 group-hover:text-orange-600 transition-colors">
                        {displayName}
                      </h3>
                    </div>
                    <p className="text-[11px] text-slate-500 line-clamp-2 leading-relaxed mb-2">
                      {displayDesc}
                    </p>
                  </div>

                  {/* Price & Action */}
                  <div className="flex items-center justify-between pt-2 border-t border-slate-100">
                    <div>
                      <span className="font-extrabold text-sm text-slate-900">
                        {settings.currencySymbol} {item.price.toFixed(2)}
                      </span>
                      <span className="text-[10px] text-slate-400 block font-mono">
                        {language === 'ar' ? 'التكلفة:' : 'Cost:'} {settings.currencySymbol} {item.cost.toFixed(2)}
                      </span>
                    </div>

                    <button
                      disabled={!inStock}
                      onClick={(e) => {
                        e.stopPropagation();
                        inStock && addToCart(item);
                      }}
                      className={`w-7 h-7 rounded-xl flex items-center justify-center transition-all ${
                        inStock
                          ? 'bg-orange-500 text-white hover:bg-orange-600 shadow-xs shadow-orange-300'
                          : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                      }`}
                      title={language === 'ar' ? 'إضافة إلى الطلب' : 'Add to order'}
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
