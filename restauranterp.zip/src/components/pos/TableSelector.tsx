import React, { useState } from 'react';
import { useRestaurant } from '../../context/RestaurantContext';
import { RestaurantTable, TableZone } from '../../types/erp';
import { Users, Clock, CheckCircle2, AlertCircle, Sparkles } from 'lucide-react';

export const TableSelector: React.FC = () => {
  const { tables, selectedTableId, setSelectedTableId, orderType, setOrderType, language, t } = useRestaurant();
  const [activeZone, setActiveZone] = useState<TableZone | 'All'>('All');

  const zoneLabels: Record<string, string> = {
    All: language === 'ar' ? 'جميع الصالات' : 'All',
    'Main Dining': language === 'ar' ? 'الصالة الرئيسية' : 'Main Dining',
    'Patio Terrace': language === 'ar' ? 'التراس الخارجي' : 'Patio Terrace',
    'Bar Lounge': language === 'ar' ? 'اللاونج والمشروبات' : 'Bar Lounge',
    'Private Dining': language === 'ar' ? 'صالات كبار الشخصيات' : 'Private Dining',
  };

  const zones: (TableZone | 'All')[] = ['All', 'Main Dining', 'Patio Terrace', 'Bar Lounge', 'Private Dining'];

  const filteredTables = activeZone === 'All' ? tables : tables.filter((t) => t.zone === activeZone);

  const getStatusColor = (status: RestaurantTable['status'], isSelected: boolean) => {
    if (isSelected) {
      return 'border-orange-500 bg-orange-50/80 ring-2 ring-orange-400 text-orange-950';
    }
    switch (status) {
      case 'available':
        return 'border-emerald-200 bg-emerald-50/40 text-emerald-950 hover:border-emerald-300 hover:bg-emerald-50';
      case 'occupied':
        return 'border-rose-200 bg-rose-50/40 text-rose-950 hover:border-rose-300 hover:bg-rose-50';
      case 'reserved':
        return 'border-amber-200 bg-amber-50/40 text-amber-950 hover:border-amber-300 hover:bg-amber-50';
      case 'cleaning':
        return 'border-slate-200 bg-slate-100 text-slate-700';
    }
  };

  const getStatusBadge = (status: RestaurantTable['status']) => {
    switch (status) {
      case 'available':
        return <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100/70 px-1.5 py-0.5 rounded">{t.pos.available}</span>;
      case 'occupied':
        return <span className="text-[10px] font-bold text-rose-700 bg-rose-100/70 px-1.5 py-0.5 rounded">{t.pos.occupied}</span>;
      case 'reserved':
        return <span className="text-[10px] font-bold text-amber-700 bg-amber-100/70 px-1.5 py-0.5 rounded">{t.pos.reserved}</span>;
      case 'cleaning':
        return <span className="text-[10px] font-bold text-slate-600 bg-slate-200 px-1.5 py-0.5 rounded">{language === 'ar' ? 'تنظيف' : 'Clean'}</span>;
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200/80 p-3 shadow-2xs mb-4">
      <div className="flex flex-wrap items-center justify-between gap-2 mb-3 pb-2 border-b border-slate-100">
        {/* Zone Filters */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
          <span className="text-xs font-bold text-slate-500 me-1">{language === 'ar' ? 'الصالات:' : 'Floor:'}</span>
          {zones.map((zone) => (
            <button
              key={zone}
              onClick={() => setActiveZone(zone)}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                activeZone === zone
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200/70'
              }`}
            >
              {zoneLabels[zone] || zone}
            </button>
          ))}
        </div>

        {/* Legend */}
        <div className="flex items-center gap-3 text-[11px] text-slate-500 font-medium">
          <div className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            <span>{t.pos.available} ({tables.filter((t) => t.status === 'available').length})</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-rose-500"></span>
            <span>{t.pos.occupied} ({tables.filter((t) => t.status === 'occupied').length})</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-amber-500"></span>
            <span>{t.pos.reserved} ({tables.filter((t) => t.status === 'reserved').length})</span>
          </div>
        </div>
      </div>

      {/* Tables Grid */}
      <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-6 gap-2">
        {filteredTables.map((table) => {
          const isSelected = selectedTableId === table.id && orderType === 'dine-in';
          return (
            <button
              key={table.id}
              onClick={() => {
                setOrderType('dine-in');
                setSelectedTableId(table.id);
              }}
              className={`p-2 rounded-xl border text-start transition-all relative flex flex-col justify-between h-20 ${getStatusColor(
                table.status,
                isSelected
              )}`}
            >
              <div className="flex items-center justify-between">
                <span className="font-extrabold text-sm tracking-tight">{table.number}</span>
                {getStatusBadge(table.status)}
              </div>

              <div className="flex items-center justify-between text-[11px] text-slate-500 font-medium mt-auto">
                <span className="flex items-center gap-1">
                  <Users className="w-3 h-3" />
                  {table.guestCount ? `${table.guestCount}/${table.capacity}` : `${table.capacity} ${language === 'ar' ? 'مقاعد' : 'seats'}`}
                </span>
                {table.occupiedSince && (
                  <span className="flex items-center gap-0.5 text-[10px] text-slate-400">
                    <Clock className="w-2.5 h-2.5" />
                    {table.occupiedSince}
                  </span>
                )}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
