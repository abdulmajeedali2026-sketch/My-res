import React from 'react';
import { useRestaurant } from '../../context/RestaurantContext';
import { Order } from '../../types/erp';
import { Printer, X, Check, UtensilsCrossed } from 'lucide-react';

interface ReceiptModalProps {
  order: Order | null;
  onClose: () => void;
}

export const ReceiptModal: React.FC<ReceiptModalProps> = ({ order, onClose }) => {
  const { settings, menuItems, language, t } = useRestaurant();

  if (!order) return null;

  const handlePrint = () => {
    window.print();
  };

  const getOrderTypeLabel = (type: string, tableNum?: string) => {
    if (language === 'ar') {
      if (type === 'dine-in') return `محلي داخل المطعم ${tableNum ? `(طاولة ${tableNum})` : ''}`;
      if (type === 'takeaway') return 'سفري واستلام كاونتر';
      if (type === 'delivery') return 'توصيل خارجي';
      return type;
    }
    return `${type} ${tableNum ? `(Table ${tableNum})` : ''}`;
  };

  const getPaymentMethodLabel = (method?: string) => {
    if (!method) return language === 'ar' ? 'نقداً' : 'CASH';
    if (language === 'ar') {
      switch (method) {
        case 'cash': return 'نقداً';
        case 'card': return 'بطاقة بنكية / مدى';
        case 'mobile_pay': return 'دفع إلكتروني / NFC';
        case 'customer_credit': return 'حساب آجل';
        default: return method;
      }
    }
    return method.toUpperCase();
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl max-w-sm w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Top Bar */}
        <div className="p-3 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-400" />
            <span className="font-bold text-xs">{language === 'ar' ? 'تم الدفع بنجاح' : 'Payment Successful'}</span>
          </div>
          <button
            onClick={onClose}
            className="w-7 h-7 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Scrollable Printable Receipt Content */}
        <div className="p-4 overflow-y-auto flex-1 bg-slate-50 flex justify-center">
          <div
            id="printable-receipt"
            className="w-full max-w-[290px] bg-white p-4 shadow-sm border border-slate-200 rounded-xl font-mono text-[11px] text-slate-800 leading-tight space-y-3"
          >
            {/* Header */}
            <div className="text-center pb-2 border-b border-dashed border-slate-300 space-y-1">
              <div className="font-extrabold text-sm uppercase tracking-wider text-slate-900">
                {settings.restaurantName}
              </div>
              <div className="text-[10px] text-slate-500">{settings.tagline}</div>
              <div className="text-[10px] text-slate-500">{settings.address}</div>
              <div className="text-[10px] text-slate-500">{language === 'ar' ? 'هاتف:' : 'Tel:'} {settings.phone}</div>
              <div className="text-[10px] text-slate-600 font-semibold">
                {language === 'ar' ? 'الرقم الضريبي:' : 'Tax Reg:'} {settings.taxRegistrationNumber}
              </div>
            </div>

            {/* Meta */}
            <div className="text-[10px] space-y-0.5 pb-2 border-b border-dashed border-slate-300">
              <div className="flex justify-between">
                <span>{language === 'ar' ? 'رقم الفاتورة:' : 'Order #:'}</span>
                <span className="font-bold">{order.orderNumber}</span>
              </div>
              <div className="flex justify-between">
                <span>{language === 'ar' ? 'التاريخ والوقت:' : 'Date & Time:'}</span>
                <span>{order.completedAt || order.createdAt}</span>
              </div>
              <div className="flex justify-between">
                <span>{language === 'ar' ? 'الكاشير / النادل:' : 'Server:'}</span>
                <span>{order.serverName}</span>
              </div>
              <div className="flex justify-between">
                <span>{language === 'ar' ? 'نوع الطلب:' : 'Dining Mode:'}</span>
                <span className="font-bold">
                  {getOrderTypeLabel(order.orderType, order.tableNumber)}
                </span>
              </div>
              {order.customerName && (
                <div className="flex justify-between">
                  <span>{language === 'ar' ? 'العميل:' : 'Guest:'}</span>
                  <span>{order.customerName}</span>
                </div>
              )}
            </div>

            {/* Itemized list */}
            <div className="space-y-1.5 pb-2 border-b border-dashed border-slate-300">
              <div className="flex justify-between font-bold text-[10px] text-slate-500 border-b border-slate-200 pb-1">
                <span>{language === 'ar' ? 'الكمية &bull; الصنف' : 'QTY &bull; ITEM'}</span>
                <span>{language === 'ar' ? 'المجموع' : 'TOTAL'}</span>
              </div>
              {order.items.map((item) => {
                const mi = menuItems.find((m) => m.id === item.menuItemId);
                const displayName = (language === 'ar' && mi?.nameAr) ? mi.nameAr : item.name;

                return (
                  <div key={item.id} className="flex justify-between items-start text-[11px]">
                    <div className="flex-1 pe-2">
                      <div className="font-semibold">
                        {item.quantity}x {displayName}
                      </div>
                      {item.kitchenNotes && (
                        <div className="text-[9px] text-slate-500 italic">* {item.kitchenNotes}</div>
                      )}
                    </div>
                    <span className="font-bold whitespace-nowrap">
                      {settings.currencySymbol} {(item.price * item.quantity).toFixed(2)}
                    </span>
                  </div>
                );
              })}
            </div>

            {/* Totals */}
            <div className="space-y-1 pb-2 border-b border-dashed border-slate-300 text-[11px]">
              <div className="flex justify-between">
                <span>{t.pos.subtotal}:</span>
                <span>
                  {settings.currencySymbol} {order.subtotal.toFixed(2)}
                </span>
              </div>
              {order.discountAmount > 0 && (
                <div className="flex justify-between text-rose-600">
                  <span>{t.pos.discount}:</span>
                  <span>
                    -{settings.currencySymbol} {order.discountAmount.toFixed(2)}
                  </span>
                </div>
              )}
              <div className="flex justify-between">
                <span>{t.pos.tax} ({settings.taxRatePercent}%):</span>
                <span>
                  {settings.currencySymbol} {order.taxAmount.toFixed(2)}
                </span>
              </div>
              {order.serviceChargeAmount > 0 && (
                <div className="flex justify-between">
                  <span>{t.pos.serviceCharge} ({settings.serviceChargePercent}%):</span>
                  <span>
                    {settings.currencySymbol} {order.serviceChargeAmount.toFixed(2)}
                  </span>
                </div>
              )}
              <div className="flex justify-between font-extrabold text-sm text-slate-950 pt-1 border-t border-slate-200">
                <span>{language === 'ar' ? 'الإجمالي المسدد:' : 'TOTAL PAID:'}</span>
                <span>
                  {settings.currencySymbol} {order.total.toFixed(2)}
                </span>
              </div>
            </div>

            {/* Payment Info */}
            <div className="text-[10px] space-y-0.5 pb-2 border-b border-dashed border-slate-300">
              <div className="flex justify-between">
                <span>{language === 'ar' ? 'طريقة الدفع:' : 'Paid via:'}</span>
                <span className="font-bold">{getPaymentMethodLabel(order.paymentMethod)}</span>
              </div>
              {order.amountTendered !== undefined && (
                <div className="flex justify-between">
                  <span>{language === 'ar' ? 'المبلغ المستلم:' : 'Amount Tendered:'}</span>
                  <span>
                    {settings.currencySymbol} {order.amountTendered.toFixed(2)}
                  </span>
                </div>
              )}
              {order.changeGiven !== undefined && order.changeGiven > 0 && (
                <div className="flex justify-between font-bold">
                  <span>{t.pos.changeDue}:</span>
                  <span>
                    {settings.currencySymbol} {order.changeGiven.toFixed(2)}
                  </span>
                </div>
              )}
            </div>

            {/* Barcode & Footer */}
            <div className="text-center pt-1 space-y-2">
              <div className="tracking-widest font-bold text-[10px] bg-slate-100 py-1 rounded">
                |||| | |||||| | |||||||| |||| | ||
              </div>
              <p className="text-[9px] text-slate-500 leading-tight">
                {settings.receiptFooterMessage}
              </p>
            </div>
          </div>
        </div>

        {/* Modal Actions */}
        <div className="p-3 bg-white border-t border-slate-200 flex gap-2">
          <button
            onClick={handlePrint}
            className="flex-1 py-2.5 px-3 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-xs transition-colors"
          >
            <Printer className="w-4 h-4" />
            <span>{language === 'ar' ? 'طباعة الفاتورة (طابعة حرارية)' : 'Print Receipt (Thermal)'}</span>
          </button>
          <button
            onClick={onClose}
            className="py-2.5 px-4 rounded-xl border border-slate-200 text-slate-700 hover:bg-slate-100 font-bold text-xs"
          >
            {t.common.close}
          </button>
        </div>
      </div>
    </div>
  );
};
