import React, { useState } from 'react';
import { TableSelector } from './TableSelector';
import { MenuGrid } from './MenuGrid';
import { CartPanel } from './CartPanel';
import { PaymentModal } from './PaymentModal';
import { ReceiptModal } from './ReceiptModal';
import { Order } from '../../types/erp';
import { useRestaurant } from '../../context/RestaurantContext';

export const PosModule: React.FC = () => {
  const { orderType } = useRestaurant();
  const [isPaymentOpen, setIsPaymentOpen] = useState<boolean>(false);
  const [completedOrderForReceipt, setCompletedOrderForReceipt] = useState<Order | null>(null);

  const handlePaymentComplete = (order: Order) => {
    setIsPaymentOpen(false);
    setCompletedOrderForReceipt(order);
  };

  return (
    <div className="flex-1 flex h-[calc(100vh-4rem)] overflow-hidden bg-slate-100">
      {/* Main POS Center: Tables + Menu */}
      <div className="flex-1 flex flex-col p-3 md:p-4 overflow-y-auto">
        {/* Table selector when in dine-in mode */}
        {orderType === 'dine-in' && <TableSelector />}

        {/* Menu Items Grid */}
        <MenuGrid />
      </div>

      {/* Right Cart Sidebar */}
      <CartPanel
        onOpenPayment={() => setIsPaymentOpen(true)}
        onOpenReceipt={() => {}}
      />

      {/* Payment Settlement Modal */}
      <PaymentModal
        isOpen={isPaymentOpen}
        onClose={() => setIsPaymentOpen(false)}
        onPaymentComplete={handlePaymentComplete}
      />

      {/* Thermal Receipt Preview Modal */}
      <ReceiptModal
        order={completedOrderForReceipt}
        onClose={() => setCompletedOrderForReceipt(null)}
      />
    </div>
  );
};
