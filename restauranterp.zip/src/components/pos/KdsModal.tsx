import React, { useState } from 'react';
import { useRestaurant } from '../../context/RestaurantContext';
import { ChefHat, X, Clock, CheckCircle2, Flame, BellRing, Utensils } from 'lucide-react';

interface KdsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const KdsModal: React.FC<KdsModalProps> = ({ isOpen, onClose }) => {
  const { orders, updateKdsStatus, settings } = useRestaurant();
  const [filter, setFilter] = useState<'all' | 'cooking' | 'ready'>('all');

  if (!isOpen) return null;

  // Active KDS orders
  const activeOrders = orders.filter((o) => {
    if (o.status === 'completed' && o.kdsStatus === 'bumped') return false;
    if (o.status === 'voided') return false;
    if (filter === 'all') return true;
    return o.kdsStatus === filter;
  });

  return (
    <div className="fixed inset-0 bg-black/75 backdrop-blur-xs flex items-center justify-center z-50 p-3 md:p-6">
      <div className="bg-slate-900 text-white rounded-3xl max-w-6xl w-full h-[90vh] shadow-2xl border border-slate-800 flex flex-col overflow-hidden">
        {/* KDS Header */}
        <div className="p-4 bg-slate-950 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-amber-500/20 text-amber-400 border border-amber-500/30 flex items-center justify-center">
              <ChefHat className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-extrabold text-base tracking-tight flex items-center gap-2">
                <span>Kitchen Display System (KDS)</span>
                <span className="text-xs bg-amber-500/20 text-amber-300 px-2 py-0.5 rounded-full font-mono border border-amber-500/30">
                  {activeOrders.length} Active Tickets
                </span>
              </h2>
              <p className="text-[11px] text-slate-400">
                Live line-cook order routing &bull; Automated recipe preparation
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Status filters */}
            <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs">
              {(['all', 'cooking', 'ready'] as const).map((f) => (
                <button
                  key={f}
                  onClick={() => setFilter(f)}
                  className={`px-3 py-1 rounded-lg font-bold capitalize transition-all ${
                    filter === f
                      ? 'bg-amber-500 text-slate-950 shadow-xs'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>

            <button
              onClick={onClose}
              className="w-9 h-9 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Tickets Grid */}
        <div className="flex-1 overflow-y-auto p-4 bg-slate-900/60">
          {activeOrders.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center text-slate-500">
              <Utensils className="w-12 h-12 text-slate-600 mb-2" />
              <p className="font-bold text-sm text-slate-300">All caught up! No active tickets</p>
              <p className="text-xs text-slate-500 mt-1">
                New orders placed on the POS terminal will instantly appear here.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {activeOrders.map((order) => {
                const isCooking = order.kdsStatus === 'cooking' || order.status === 'preparing';
                const isReady = order.kdsStatus === 'ready' || order.status === 'ready';

                return (
                  <div
                    key={order.id}
                    className={`rounded-2xl border flex flex-col justify-between overflow-hidden shadow-md transition-all ${
                      isReady
                        ? 'border-emerald-500/80 bg-emerald-950/20'
                        : isCooking
                        ? 'border-amber-500/80 bg-amber-950/20'
                        : 'border-slate-800 bg-slate-950/50'
                    }`}
                  >
                    {/* Ticket Header */}
                    <div
                      className={`p-3 border-b flex items-center justify-between ${
                        isReady
                          ? 'bg-emerald-900/30 border-emerald-800/60'
                          : isCooking
                          ? 'bg-amber-900/30 border-amber-800/60'
                          : 'bg-slate-900 border-slate-800'
                      }`}
                    >
                      <div>
                        <span className="font-mono text-[10px] text-slate-400 block">
                          {order.orderNumber}
                        </span>
                        <h4 className="font-black text-sm text-white">
                          {order.orderType === 'dine-in'
                            ? `Table ${order.tableNumber || 'T-01'}`
                            : `${order.orderType.toUpperCase()}`}
                        </h4>
                      </div>

                      <div className="text-right">
                        <span
                          className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-md ${
                            isReady
                              ? 'bg-emerald-500 text-slate-950'
                              : 'bg-amber-500 text-slate-950'
                          }`}
                        >
                          {isReady ? 'READY TO SERVE' : 'IN PREP'}
                        </span>
                        <span className="text-[10px] text-slate-400 block font-mono mt-0.5 flex items-center justify-end gap-0.5">
                          <Clock className="w-2.5 h-2.5" />
                          {order.createdAt}
                        </span>
                      </div>
                    </div>

                    {/* Order Items Checklist */}
                    <div className="p-3 flex-1 space-y-2 overflow-y-auto max-h-56">
                      {order.items.map((item) => (
                        <div
                          key={item.id}
                          className="bg-slate-900/80 p-2 rounded-xl border border-slate-800 text-xs flex flex-col gap-0.5"
                        >
                          <div className="flex items-start justify-between">
                            <span className="font-bold text-slate-200">
                              <span className="text-amber-400 font-mono font-black text-sm mr-1">
                                {item.quantity}x
                              </span>
                              {item.name}
                            </span>
                          </div>
                          {item.kitchenNotes && (
                            <div className="text-[10px] text-amber-300 font-medium bg-amber-950/60 px-1.5 py-0.5 rounded border border-amber-900/50">
                              Note: {item.kitchenNotes}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>

                    {/* Ticket Footer Action */}
                    <div className="p-2.5 bg-slate-950/80 border-t border-slate-800">
                      {isCooking && (
                        <button
                          onClick={() => updateKdsStatus(order.id, 'ready')}
                          className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm transition-colors"
                        >
                          <CheckCircle2 className="w-4 h-4" />
                          <span>Mark Dish Ready</span>
                        </button>
                      )}

                      {isReady && (
                        <button
                          onClick={() => updateKdsStatus(order.id, 'bumped')}
                          className="w-full py-2 bg-slate-700 hover:bg-slate-600 text-slate-200 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
                        >
                          <span>Bump / Served (Clear Ticket)</span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
