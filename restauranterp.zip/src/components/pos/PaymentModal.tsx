import React, { useState } from 'react';
import { useRestaurant } from '../../context/RestaurantContext';
import { PaymentMethod, Order } from '../../types/erp';
import {
  X,
  Banknote,
  CreditCard,
  Smartphone,
  Wallet,
  CheckCircle2,
  Sparkles,
  ArrowRight,
} from 'lucide-react';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPaymentComplete: (order: Order) => void;
}

export const PaymentModal: React.FC<PaymentModalProps> = ({
  isOpen,
  onClose,
  onPaymentComplete,
}) => {
  const {
    settings,
    cartTotal,
    orderType,
    tables,
    selectedTableId,
    customers,
    selectedCustomerId,
    processCheckout,
    language,
    t,
  } = useRestaurant();

  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cash');
  const [tenderAmount, setTenderAmount] = useState<string>(cartTotal.toFixed(2));
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const numericTender = parseFloat(tenderAmount) || 0;
  const changeDue = Math.max(0, numericTender - cartTotal);
  const selectedTable = tables.find((t) => t.id === selectedTableId);
  const selectedCustomer = customers.find((c) => c.id === selectedCustomerId);

  // Quick cash buttons
  const cashOptions = [
    { label: language === 'ar' ? 'المبلغ بالضبط' : 'Exact', val: cartTotal },
    { label: `${settings.currencySymbol} ${Math.ceil(cartTotal / 10) * 10}`, val: Math.ceil(cartTotal / 10) * 10 },
    { label: `${settings.currencySymbol} ${Math.ceil(cartTotal / 20) * 20 || 20}`, val: Math.ceil(cartTotal / 20) * 20 || 20 },
    { label: `${settings.currencySymbol} 50`, val: 50 },
    { label: `${settings.currencySymbol} 100`, val: 100 },
    { label: `${settings.currencySymbol} 500`, val: 500 },
  ].filter((opt, idx, arr) => arr.findIndex((x) => x.val === opt.val) === idx && opt.val >= cartTotal);

  const handleSettle = () => {
    if (paymentMethod === 'cash' && numericTender < cartTotal) {
      setErrorMessage(
        language === 'ar'
          ? `المبلغ المستلم أقل من الإجمالي بمقدار ${settings.currencySymbol} ${(cartTotal - numericTender).toFixed(2)}`
          : `Tendered amount is short by $${(cartTotal - numericTender).toFixed(2)}`
      );
      return;
    }

    setIsProcessing(true);
    setErrorMessage(null);

    setTimeout(() => {
      const result = processCheckout(paymentMethod, numericTender);
      setIsProcessing(false);
      if (result.success && result.order) {
        onPaymentComplete(result.order);
      } else {
        setErrorMessage(result.error || (language === 'ar' ? 'فشلت معالجة الدفع' : 'Payment processing failed'));
      }
    }, 400);
  };

  const paymentMethodsList = [
    { id: 'cash' as PaymentMethod, label: t.pos.cash, icon: Banknote },
    { id: 'card' as PaymentMethod, label: t.pos.card, icon: CreditCard },
    { id: 'mobile_pay' as PaymentMethod, label: language === 'ar' ? 'دفع إلكتروني' : 'NFC Mobile', icon: Smartphone },
    { id: 'customer_credit' as PaymentMethod, label: language === 'ar' ? 'حساب آجل' : 'Account', icon: Wallet },
  ];

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl max-w-lg w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
          <div>
            <span className="text-[10px] font-bold uppercase tracking-wider text-orange-400">
              {language === 'ar' ? 'الدفع والتحصيل المالي' : 'Payment & Bill Settlement'}
            </span>
            <h3 className="font-extrabold text-lg">
              {orderType === 'dine-in'
                ? (language === 'ar' ? `طاولة رقم ${selectedTable?.number || 'T-01'}` : `Table ${selectedTable?.number || 'T-01'}`)
                : (language === 'ar' ? 'طلب كاونتر / سفري' : 'Counter Order')}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4">
          {/* Amount Due Big Banner */}
          <div className="bg-orange-50 border border-orange-200/80 rounded-2xl p-4 flex items-center justify-between">
            <div>
              <span className="text-xs text-orange-950/70 font-semibold block">{t.pos.total}</span>
              <span className="text-3xl font-black text-orange-600 font-mono tracking-tight">
                {settings.currencySymbol} {cartTotal.toFixed(2)}
              </span>
            </div>
            {selectedCustomer && (
              <div className="text-end">
                <span className="text-[11px] font-bold text-amber-900 block">
                  {selectedCustomer.name}
                </span>
                <span className="text-[10px] text-amber-700 bg-amber-100/80 px-2 py-0.5 rounded-full font-semibold">
                  {language === 'ar' ? `يكتسب +${Math.floor(cartTotal)} نقطة` : `Earns +${Math.floor(cartTotal)} Points`}
                </span>
              </div>
            )}
          </div>

          {/* Payment Method Selector */}
          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1.5">
              {language === 'ar' ? 'طريقة السداد والقبض:' : 'Select Tender Method'}
            </label>
            <div className="grid grid-cols-4 gap-2">
              {paymentMethodsList.map((m) => {
                const Icon = m.icon;
                const isSelected = paymentMethod === m.id;
                return (
                  <button
                    key={m.id}
                    onClick={() => {
                      setPaymentMethod(m.id);
                      if (m.id !== 'cash') {
                        setTenderAmount(cartTotal.toFixed(2));
                      }
                    }}
                    className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1 text-xs font-bold transition-all ${
                      isSelected
                        ? 'border-orange-500 bg-orange-50 text-orange-950 ring-2 ring-orange-300'
                        : 'border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    <Icon className={`w-5 h-5 ${isSelected ? 'text-orange-600' : 'text-slate-500'}`} />
                    <span>{m.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Cash Tender Details */}
          {paymentMethod === 'cash' ? (
            <div className="space-y-3 bg-slate-50 p-3.5 rounded-2xl border border-slate-200">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-slate-700">{language === 'ar' ? 'المبلغ المستلم نقداً:' : 'Cash Received:'}</label>
                <div className="relative w-40">
                  <span className="absolute start-2.5 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-xs">
                    {settings.currencySymbol}
                  </span>
                  <input
                    type="number"
                    step="0.01"
                    value={tenderAmount}
                    onChange={(e) => setTenderAmount(e.target.value)}
                    className="w-full ps-9 pe-3 py-1.5 bg-white border border-slate-300 rounded-xl font-mono font-bold text-sm text-end text-slate-900 focus:border-orange-500 focus:outline-hidden"
                  />
                </div>
              </div>

              {/* Fast Cash Pills */}
              <div className="flex flex-wrap gap-1.5">
                {cashOptions.map((opt) => (
                  <button
                    key={opt.val}
                    onClick={() => setTenderAmount(opt.val.toFixed(2))}
                    className="px-2.5 py-1 rounded-lg bg-white border border-slate-200 text-xs font-bold text-slate-700 hover:bg-slate-100 font-mono"
                  >
                    {opt.label}
                  </button>
                ))}
              </div>

              {/* Change Due calculation */}
              <div className="flex items-center justify-between pt-2 border-t border-slate-200 text-xs">
                <span className="font-bold text-slate-600">{t.pos.changeDue}:</span>
                <span
                  className={`font-mono text-base font-extrabold ${
                    changeDue > 0 ? 'text-emerald-600' : 'text-slate-800'
                  }`}
                >
                  {settings.currencySymbol} {changeDue.toFixed(2)}
                </span>
              </div>
            </div>
          ) : (
            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 text-center space-y-1">
              <div className="w-10 h-10 rounded-full bg-emerald-100 text-emerald-700 mx-auto flex items-center justify-center mb-2">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <p className="font-bold text-xs text-slate-900">
                {language === 'ar'
                  ? `جهاز الدفع جاهز للاتصال (${paymentMethod === 'card' ? 'بطاقة بنكية مدى / رقاقة' : 'NFC لاسلكي'})`
                  : `Ready for ${paymentMethod === 'card' ? 'EMV Chip / Swipe' : 'NFC Contactless'}`}
              </p>
              <p className="text-[11px] text-slate-500">
                {language === 'ar'
                  ? `تم الاتصال بنقطة البيع &bull; المبلغ المطلوب للخصم: ${settings.currencySymbol} ${cartTotal.toFixed(2)}`
                  : `Terminal connected &bull; Authorized for exact total ${settings.currencySymbol}${cartTotal.toFixed(2)}`}
              </p>
            </div>
          )}

          {errorMessage && (
            <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs font-semibold">
              {errorMessage}
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex items-center gap-2 pt-2">
            <button
              onClick={onClose}
              className="flex-1 py-3 px-4 rounded-xl text-xs font-bold border border-slate-200 text-slate-600 hover:bg-slate-100"
            >
              {t.common.cancel}
            </button>
            <button
              disabled={isProcessing}
              onClick={handleSettle}
              className="flex-2 py-3 px-4 rounded-xl text-xs font-bold bg-orange-500 hover:bg-orange-600 text-white flex items-center justify-center gap-2 shadow-lg shadow-orange-200 transition-all"
            >
              {isProcessing ? (
                <span>{language === 'ar' ? 'ترحيل القيد وخصم المكونات...' : 'Writing Ledger & Deducting BOM...'}</span>
              ) : (
                <>
                  <span>{language === 'ar' ? 'تأكيد السداد والطباعة' : 'Complete Settlement'}</span>
                  <ArrowRight className="w-4 h-4 rtl:rotate-180" />
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
