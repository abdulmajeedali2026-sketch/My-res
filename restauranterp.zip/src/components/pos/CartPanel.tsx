import React, { useState } from 'react';
import { useRestaurant } from '../../context/RestaurantContext';
import {
  Trash2,
  Plus,
  Minus,
  MessageSquare,
  Users,
  Percent,
  Receipt,
  ChefHat,
  CreditCard,
  User,
  Split,
  ChevronDown,
  X,
  Sparkles,
} from 'lucide-react';
import { OrderType } from '../../types/erp';

interface CartPanelProps {
  onOpenPayment: () => void;
  onOpenReceipt: () => void;
}

export const CartPanel: React.FC<CartPanelProps> = ({ onOpenPayment }) => {
  const {
    settings,
    orderType,
    setOrderType,
    selectedTableId,
    tables,
    guestCount,
    setGuestCount,
    customers,
    selectedCustomerId,
    setSelectedCustomerId,
    cart,
    menuItems,
    removeFromCart,
    updateCartQuantity,
    updateItemNotes,
    clearCart,
    discountPercent,
    setDiscountPercent,
    discountReason,
    setDiscountReason,
    cartSubtotal,
    cartTax,
    cartServiceCharge,
    cartDiscountAmount,
    cartTotal,
    sendOrderToKitchen,
    language,
    t,
  } = useRestaurant();

  const [editingNoteItem, setEditingNoteItem] = useState<string | null>(null);
  const [noteInput, setNoteInput] = useState<string>('');
  const [showDiscountModal, setShowDiscountModal] = useState<boolean>(false);
  const [showSplitModal, setShowSplitModal] = useState<boolean>(false);
  const [splitGuests, setSplitGuests] = useState<number>(2);
  const [kitchenFeedback, setKitchenFeedback] = useState<string | null>(null);

  const selectedTable = tables.find((t) => t.id === selectedTableId);
  const selectedCustomer = customers.find((c) => c.id === selectedCustomerId);

  const handleSendToKitchen = () => {
    const order = sendOrderToKitchen();
    if (order) {
      setKitchenFeedback(
        language === 'ar'
          ? `تم إرسال الطلب لمطبخ العرض KDS: طلب رقم #${order.orderNumber}`
          : `Fired to Kitchen: Order #${order.orderNumber}`
      );
      setTimeout(() => setKitchenFeedback(null), 4000);
    }
  };

  const handleApplyTierDiscount = (percent: number, reason: string) => {
    setDiscountPercent(percent);
    setDiscountReason(reason);
    setShowDiscountModal(false);
  };

  const orderTypeLabels: Record<OrderType, string> = {
    'dine-in': t.pos.dineIn,
    takeaway: t.pos.takeaway,
    delivery: t.pos.delivery,
  };

  return (
    <aside className="w-80 lg:w-96 bg-white border-l border-slate-200 rtl:border-l-0 rtl:border-r flex flex-col h-full shadow-lg select-none">
      {/* Top Header: Order Mode & Table */}
      <div className="p-3 border-b border-slate-200 bg-slate-50/70">
        {/* Order Type Tabs */}
        <div className="grid grid-cols-3 gap-1 bg-slate-200/80 p-1 rounded-xl mb-2.5">
          {(['dine-in', 'takeaway', 'delivery'] as OrderType[]).map((type) => (
            <button
              key={type}
              onClick={() => setOrderType(type)}
              className={`py-1.5 text-xs font-bold rounded-lg transition-all ${
                orderType === type
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {orderTypeLabels[type]}
            </button>
          ))}
        </div>

        {/* Dine-In Table & Guest Count */}
        {orderType === 'dine-in' ? (
          <div className="flex items-center justify-between bg-white px-3 py-2 rounded-xl border border-slate-200 text-xs">
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-orange-500"></span>
              <span className="font-bold text-slate-900">
                {language === 'ar' ? 'طاولة:' : 'Table:'} {selectedTable ? selectedTable.number : (language === 'ar' ? 'غير محددة' : 'None Selected')}
              </span>
              <span className="text-[10px] text-slate-500">({selectedTable?.zone || (language === 'ar' ? 'الصالات' : 'Floor')})</span>
            </div>
            {/* Guest Count Stepper */}
            <div className="flex items-center gap-1.5 bg-slate-100 px-2 py-0.5 rounded-lg">
              <Users className="w-3.5 h-3.5 text-slate-500" />
              <button
                onClick={() => setGuestCount(Math.max(1, guestCount - 1))}
                className="w-4 h-4 rounded text-slate-600 hover:bg-slate-200 flex items-center justify-center font-bold"
              >
                -
              </button>
              <span className="font-bold text-slate-800 text-xs">{guestCount}</span>
              <button
                onClick={() => setGuestCount(guestCount + 1)}
                className="w-4 h-4 rounded text-slate-600 hover:bg-slate-200 flex items-center justify-center font-bold"
              >
                +
              </button>
            </div>
          </div>
        ) : (
          <div className="bg-white px-3 py-2 rounded-xl border border-slate-200 text-xs flex items-center justify-between text-slate-700">
            <span className="font-semibold uppercase tracking-wider text-[10px] text-slate-500">
              {orderTypeLabels[orderType]}
            </span>
            <span className="text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded font-bold text-[11px]">
              {language === 'ar' ? 'بدون رسوم خدمة' : 'No Service Charge'}
            </span>
          </div>
        )}

        {/* Customer Loyalty Selector */}
        <div className="mt-2 flex items-center gap-2 bg-white px-3 py-1.5 rounded-xl border border-slate-200">
          <User className="w-3.5 h-3.5 text-slate-400" />
          <select
            value={selectedCustomerId || ''}
            onChange={(e) => {
              const custId = e.target.value || null;
              setSelectedCustomerId(custId);
              if (custId) {
                const c = customers.find((cust) => cust.id === custId);
                if (c?.tier === 'Platinum') handleApplyTierDiscount(15, language === 'ar' ? 'خصم بلاتيني 15%' : 'Platinum VIP 15%');
                else if (c?.tier === 'Gold') handleApplyTierDiscount(10, language === 'ar' ? 'خصم ذهبي 10%' : 'Gold Loyalty 10%');
                else if (c?.tier === 'Silver') handleApplyTierDiscount(5, language === 'ar' ? 'خصم فضي 5%' : 'Silver Loyalty 5%');
              } else {
                setDiscountPercent(0);
                setDiscountReason('');
              }
            }}
            className="w-full bg-transparent text-xs font-semibold text-slate-800 border-0 p-0 focus:ring-0 cursor-pointer"
          >
            <option value="">{language === 'ar' ? 'عميل عام (بدون ملف ولاء)' : 'Guest (No Loyalty Profile)'}</option>
            {customers.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name} ({c.tier} &bull; {c.loyaltyPoints} {language === 'ar' ? 'نقطة' : 'pts'})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Feedback Alert if fired to kitchen */}
      {kitchenFeedback && (
        <div className="mx-3 mt-2 p-2 bg-emerald-50 border border-emerald-200 rounded-xl text-xs text-emerald-800 font-semibold flex items-center gap-1.5 animate-fade-in">
          <ChefHat className="w-4 h-4 text-emerald-600" />
          <span>{kitchenFeedback}</span>
        </div>
      )}

      {/* Cart Items List */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2">
        {cart.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-6 text-slate-400">
            <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center mb-3">
              <Receipt className="w-6 h-6 text-slate-400" />
            </div>
            <p className="font-semibold text-xs text-slate-700">{t.pos.emptyCartTitle}</p>
            <p className="text-[11px] text-slate-400 mt-1 max-w-xs">
              {t.pos.emptyCartSubtitle}
            </p>
          </div>
        ) : (
          cart.map((item) => {
            const mi = menuItems.find((m) => m.id === item.menuItemId);
            const displayName = (language === 'ar' && mi?.nameAr) ? mi.nameAr : item.name;

            return (
              <div
                key={item.menuItemId}
                className="bg-slate-50 rounded-xl p-2.5 border border-slate-200/80 flex flex-col gap-1.5 text-xs hover:border-slate-300 transition-colors"
              >
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1">
                    <span className="font-bold text-slate-900 block leading-snug">
                      {displayName}
                    </span>
                    <span className="text-[11px] text-slate-500 font-mono">
                      {settings.currencySymbol} {item.price.toFixed(2)}
                    </span>
                  </div>
                  <span className="font-extrabold text-slate-900 font-mono">
                    {settings.currencySymbol} {(item.price * item.quantity).toFixed(2)}
                  </span>
                </div>

                {/* Kitchen note display */}
                {item.kitchenNotes && (
                  <div className="text-[11px] bg-amber-50 text-amber-900 px-2 py-0.5 rounded border border-amber-200/60 font-medium">
                    {language === 'ar' ? 'ملاحظة:' : 'Note:'} {item.kitchenNotes}
                  </div>
                )}

                {/* Controls: Quantity + Notes + Delete */}
                <div className="flex items-center justify-between pt-1 border-t border-slate-200/60">
                  <button
                    onClick={() => {
                      setEditingNoteItem(item.menuItemId);
                      setNoteInput(item.kitchenNotes || '');
                    }}
                    className="text-[11px] text-slate-500 hover:text-slate-800 flex items-center gap-1"
                  >
                    <MessageSquare className="w-3 h-3 text-slate-400" />
                    <span>{item.kitchenNotes ? (language === 'ar' ? 'تعديل الملاحظة' : 'Edit Note') : (language === 'ar' ? '+ ملاحظة للمطبخ' : '+ Kitchen Note')}</span>
                  </button>

                  <div className="flex items-center gap-2">
                    <div className="flex items-center gap-1 bg-white border border-slate-200 rounded-lg p-0.5">
                      <button
                        onClick={() => updateCartQuantity(item.menuItemId, -1)}
                        className="w-5 h-5 rounded flex items-center justify-center text-slate-600 hover:bg-slate-100 font-bold"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="w-6 text-center font-bold text-xs text-slate-900">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => updateCartQuantity(item.menuItemId, 1)}
                        className="w-5 h-5 rounded flex items-center justify-center text-slate-600 hover:bg-slate-100 font-bold"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>

                    <button
                      onClick={() => removeFromCart(item.menuItemId)}
                      className="w-6 h-6 rounded flex items-center justify-center text-slate-400 hover:text-rose-600 hover:bg-rose-50"
                      title={language === 'ar' ? 'حذف الصنف' : 'Delete item'}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Note Editing Modal/Popup */}
      {editingNoteItem && (
        <div className="p-3 bg-amber-50 border-t border-b border-amber-200 text-xs">
          <div className="flex items-center justify-between mb-1.5 font-bold text-amber-900">
            <span>{language === 'ar' ? 'إضافة ملاحظة أو تعديل للمطبخ:' : 'Add Kitchen Modifier / Note:'}</span>
            <button onClick={() => setEditingNoteItem(null)}>
              <X className="w-4 h-4 text-amber-700" />
            </button>
          </div>
          <div className="flex gap-1.5">
            <input
              type="text"
              placeholder={language === 'ar' ? 'مثال: استواء متوسط، الصوص جانبي، بدون ملح...' : 'e.g. Medium rare, dressing on side...'}
              value={noteInput}
              onChange={(e) => setNoteInput(e.target.value)}
              className="flex-1 px-2.5 py-1.5 bg-white border border-amber-300 rounded-lg text-xs"
              autoFocus
            />
            <button
              onClick={() => {
                updateItemNotes(editingNoteItem, noteInput);
                setEditingNoteItem(null);
              }}
              className="px-3 py-1.5 bg-amber-600 text-white rounded-lg font-bold text-xs hover:bg-amber-700"
            >
              {language === 'ar' ? 'حفظ' : 'Save'}
            </button>
          </div>
        </div>
      )}

      {/* Bill Breakdown & Totals */}
      <div className="p-3 bg-white border-t border-slate-200 space-y-2 text-xs">
        {/* Quick Tools: Discount & Split Bill */}
        <div className="flex items-center justify-between gap-2 pb-1 border-b border-slate-100">
          <button
            onClick={() => setShowDiscountModal(true)}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold border ${
              discountPercent > 0
                ? 'bg-amber-50 text-amber-800 border-amber-200'
                : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'
            }`}
          >
            <Percent className="w-3 h-3" />
            <span>
              {discountPercent > 0 ? `${discountPercent}% ${discountReason}` : t.pos.discount}
            </span>
          </button>

          <button
            onClick={() => setShowSplitModal(true)}
            className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold bg-slate-50 text-slate-600 border border-slate-200 hover:bg-slate-100"
          >
            <Split className="w-3 h-3" />
            <span>{language === 'ar' ? 'تقسيم الحساب' : 'Split Bill'}</span>
          </button>

          {cart.length > 0 && (
            <button
              onClick={clearCart}
              className="text-xs text-rose-600 font-semibold hover:underline"
            >
              {t.pos.clearCart}
            </button>
          )}
        </div>

        {/* Lines */}
        <div className="space-y-1 text-slate-600 text-[11px]">
          <div className="flex justify-between">
            <span>{t.pos.subtotal}</span>
            <span className="font-mono text-slate-800">
              {settings.currencySymbol} {cartSubtotal.toFixed(2)}
            </span>
          </div>

          {discountPercent > 0 && (
            <div className="flex justify-between text-amber-700 font-medium">
              <span>{t.pos.discount} ({discountPercent}%)</span>
              <span className="font-mono">
                -{settings.currencySymbol} {cartDiscountAmount.toFixed(2)}
              </span>
            </div>
          )}

          <div className="flex justify-between">
            <span>{t.pos.tax} ({settings.taxRatePercent}%)</span>
            <span className="font-mono text-slate-800">
              {settings.currencySymbol} {cartTax.toFixed(2)}
            </span>
          </div>

          {orderType === 'dine-in' && (
            <div className="flex justify-between">
              <span>{t.pos.serviceCharge} ({settings.serviceChargePercent}%)</span>
              <span className="font-mono text-slate-800">
                {settings.currencySymbol} {cartServiceCharge.toFixed(2)}
              </span>
            </div>
          )}

          <div className="flex justify-between text-base font-extrabold text-slate-900 pt-1.5 border-t border-slate-200">
            <span>{t.pos.total}</span>
            <span className="font-mono text-orange-600">
              {settings.currencySymbol} {cartTotal.toFixed(2)}
            </span>
          </div>
        </div>

        {/* POS Action Buttons */}
        <div className="grid grid-cols-2 gap-2 pt-2">
          <button
            disabled={cart.length === 0}
            onClick={handleSendToKitchen}
            className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl font-bold text-xs bg-slate-800 text-white hover:bg-slate-900 disabled:opacity-40 disabled:cursor-not-allowed transition-all shadow-xs"
          >
            <ChefHat className="w-4 h-4 text-amber-400" />
            <span>{t.pos.sendToKitchen}</span>
          </button>

          <button
            disabled={cart.length === 0}
            onClick={onOpenPayment}
            className="flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-xl font-bold text-xs bg-gradient-to-r from-orange-500 to-amber-500 text-white hover:from-orange-600 hover:to-amber-600 disabled:opacity-40 disabled:cursor-not-allowed transition-all shadow-md shadow-orange-200"
          >
            <CreditCard className="w-4 h-4" />
            <span>{t.pos.payAndPrint}</span>
          </button>
        </div>
      </div>

      {/* Discount Modal */}
      {showDiscountModal && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-2xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-4 shadow-xl border border-slate-200">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 mb-3">
              <h4 className="font-bold text-slate-900 text-sm">{language === 'ar' ? 'تطبيق خصم على الفاتورة' : 'Apply Bill Discount'}</h4>
              <button onClick={() => setShowDiscountModal(false)}>
                <X className="w-4 h-4 text-slate-400" />
              </button>
            </div>

            <div className="grid grid-cols-2 gap-2 mb-3">
              {[
                { label: language === 'ar' ? '5% وجبة موظف' : '5% Staff Meal', val: 5, reason: language === 'ar' ? 'موظف 5%' : 'Staff 5%' },
                { label: language === 'ar' ? '10% عروض خاصة' : '10% Happy Hour', val: 10, reason: language === 'ar' ? 'عروض 10%' : 'Happy Hour 10%' },
                { label: language === 'ar' ? '15% عملاء VIP' : '15% VIP Platinum', val: 15, reason: language === 'ar' ? 'كبار الشخصيات 15%' : 'VIP 15%' },
                { label: language === 'ar' ? '20% ضيافة إدارة' : '20% Management', val: 20, reason: language === 'ar' ? 'ضيافة إدارة 20%' : 'Manager Courtesy 20%' },
              ].map((d) => (
                <button
                  key={d.val}
                  onClick={() => handleApplyTierDiscount(d.val, d.reason)}
                  className="p-2.5 rounded-xl border border-slate-200 hover:border-orange-500 hover:bg-orange-50/50 text-start transition-all"
                >
                  <span className="font-bold text-xs text-slate-900 block">{d.label}</span>
                  <span className="text-[10px] text-slate-500">{language === 'ar' ? `خصم ${d.val}% من المجموع` : `Save ${d.val}% on subtotal`}</span>
                </button>
              ))}
            </div>

            <button
              onClick={() => {
                setDiscountPercent(0);
                setDiscountReason('');
                setShowDiscountModal(false);
              }}
              className="w-full py-2 rounded-xl text-xs font-bold text-rose-600 border border-rose-200 hover:bg-rose-50"
            >
              {language === 'ar' ? 'إلغاء الخصم' : 'Remove Discount'}
            </button>
          </div>
        </div>
      )}

      {/* Split Bill Calculator Modal */}
      {showSplitModal && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-2xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl max-w-sm w-full p-4 shadow-xl border border-slate-200 text-center">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100 mb-3">
              <h4 className="font-bold text-slate-900 text-sm">{language === 'ar' ? 'تقسيم الحساب بالتساوي' : 'Split Bill Evenly'}</h4>
              <button onClick={() => setShowSplitModal(false)}>
                <X className="w-4 h-4 text-slate-400" />
              </button>
            </div>

            <p className="text-xs text-slate-500 mb-3">
              {language === 'ar' ? 'إجمالي الحساب:' : 'Total Check:'}{' '}
              <strong className="text-slate-900 font-mono">{settings.currencySymbol} {cartTotal.toFixed(2)}</strong>
            </p>

            <div className="flex items-center justify-center gap-3 mb-4">
              <button
                onClick={() => setSplitGuests(Math.max(2, splitGuests - 1))}
                className="w-8 h-8 rounded-lg bg-slate-100 text-slate-700 font-bold hover:bg-slate-200"
              >
                -
              </button>
              <span className="text-lg font-bold text-slate-900">{splitGuests} {language === 'ar' ? 'أشخاص' : 'Guests'}</span>
              <button
                onClick={() => setSplitGuests(splitGuests + 1)}
                className="w-8 h-8 rounded-lg bg-slate-100 text-slate-700 font-bold hover:bg-slate-200"
              >
                +
              </button>
            </div>

            <div className="p-3 rounded-xl bg-orange-50 border border-orange-200 mb-4">
              <span className="text-xs text-orange-900 block font-medium">{language === 'ar' ? 'نصيب كل شخص:' : 'Per Person Amount:'}</span>
              <span className="text-2xl font-black text-orange-600 font-mono">
                {settings.currencySymbol} {(cartTotal / splitGuests).toFixed(2)}
              </span>
            </div>

            <button
              onClick={() => setShowSplitModal(false)}
              className="w-full py-2 bg-slate-900 text-white rounded-xl text-xs font-bold hover:bg-slate-800"
            >
              {language === 'ar' ? 'تم' : 'Done'}
            </button>
          </div>
        </div>
      )}
    </aside>
  );
};
