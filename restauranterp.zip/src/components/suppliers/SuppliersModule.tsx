import React, { useState } from 'react';
import { useRestaurant } from '../../context/RestaurantContext';
import { Supplier } from '../../types/erp';
import {
  Building2,
  Phone,
  Mail,
  Plus,
  DollarSign,
  CheckCircle2,
  Clock,
  ArrowRight,
  X,
  CreditCard,
} from 'lucide-react';

export const SuppliersModule: React.FC = () => {
  const { suppliers, addSupplier, paySupplierBalance, settings, language, t } = useRestaurant();
  const [showAddModal, setShowAddModal] = useState<boolean>(false);
  const [payModalSupplier, setPayModalSupplier] = useState<Supplier | null>(null);
  const [payAmount, setPayAmount] = useState<number>(500);
  const [feedback, setFeedback] = useState<string | null>(null);

  // Form states
  const [name, setName] = useState<string>('');
  const [contactPerson, setContactPerson] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [category, setCategory] = useState<string>('Meat & Poultry');
  const [paymentTerms, setPaymentTerms] = useState<string>('Net 30');

  const getCategoryLabel = (cat: string) => {
    if (language !== 'ar') return cat;
    switch (cat) {
      case 'Meat & Poultry': return 'اللحوم والدواجن';
      case 'Dairy & Cheese': return 'الألبان والأجبان';
      case 'Produce': return 'الخضروات والفواكه';
      case 'Bakery & Flour': return 'المخبوزات والدقيق';
      case 'Beverages & Spirits': return 'المشروبات والقهوة';
      default: return cat;
    }
  };

  const getTermsLabel = (terms: string) => {
    if (language !== 'ar') return terms;
    switch (terms) {
      case 'Net 15': return 'آجل 15 يوم (Net 15)';
      case 'Net 30': return 'آجل 30 يوم (Net 30)';
      case 'Net 45': return 'آجل 45 يوم (Net 45)';
      case 'Cash on Delivery': return 'الدفع عند الاستلام (COD)';
      default: return terms;
    }
  };

  const totalPayables = suppliers.reduce((sum, s) => sum + (s.balancePayable ?? s.balanceOwed ?? 0), 0);

  const handleCreateSupplier = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !contactPerson) return;

    addSupplier({
      name,
      contactPerson,
      email,
      phone,
      category,
      paymentTerms,
      address: 'Industrial Supply Quarter, Metro Zone',
    });

    setShowAddModal(false);
    setFeedback(
      language === 'ar'
        ? `تم تسجيل المورد الجديد (${name}) بنجاح وإضافته لدليل الموردين.`
        : `New vendor profile registered for ${name}.`
    );
    setName('');
    setContactPerson('');
    setEmail('');
    setPhone('');
    setTimeout(() => setFeedback(null), 4000);
  };

  const handlePaySupplier = (e: React.FormEvent) => {
    e.preventDefault();
    if (!payModalSupplier || payAmount <= 0) return;

    paySupplierBalance(payModalSupplier.id, payAmount);
    setFeedback(
      language === 'ar'
        ? `تم صرف دفعة بقيمة ${settings.currencySymbol} ${payAmount.toFixed(2)} لصالح (${payModalSupplier.name}). وتم تحديث دفتر حسابات الموردين.`
        : `Disbursed payment of ${settings.currencySymbol} ${payAmount.toFixed(2)} to ${payModalSupplier.name}. AP Ledger updated.`
    );
    setPayModalSupplier(null);
    setTimeout(() => setFeedback(null), 4000);
  };

  return (
    <div className="flex-1 flex flex-col p-4 md:p-6 overflow-y-auto bg-slate-100">
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight">
            {t.suppliers.title}
          </h2>
          <p className="text-xs text-slate-500">
            {t.suppliers.subtitle}
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs shadow-md shadow-orange-200 transition-colors"
        >
          <Plus className="w-4 h-4" />
          <span>{t.suppliers.addSupplier}</span>
        </button>
      </div>

      {feedback && (
        <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 rounded-2xl text-emerald-800 text-xs font-semibold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{feedback}</span>
        </div>
      )}

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-6">
        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-xs text-slate-500 font-semibold block mb-1">
            {t.suppliers.activeSuppliers}
          </span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black text-slate-900 font-mono">{suppliers.length}</span>
            <span className="text-xs text-slate-400 font-medium">{language === 'ar' ? 'مورد معتمد' : 'Active Partners'}</span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-xs text-slate-500 font-semibold block mb-1">
            {t.suppliers.totalPayables}
          </span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black text-rose-600 font-mono">
              {settings.currencySymbol} {totalPayables.toFixed(2)}
            </span>
            <span className="text-xs font-bold text-rose-700 bg-rose-50 px-2 py-0.5 rounded-md">
              {language === 'ar' ? 'ذمم دائنة مستحقة' : 'Accounts Payable'}
            </span>
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-2xs">
          <span className="text-xs text-slate-500 font-semibold block mb-1">
            {language === 'ar' ? 'فترات السداد المعتمدة' : 'Standard Terms'}
          </span>
          <div className="flex items-baseline justify-between">
            <span className="text-2xl font-black text-slate-900 font-mono">{language === 'ar' ? 'آجل 15 - 30 يوم' : 'Net 15 - 30'}</span>
            <span className="text-xs text-slate-400 font-medium">{language === 'ar' ? 'تسهيلات ائتمانية' : 'Revolving Credit'}</span>
          </div>
        </div>
      </div>

      {/* Suppliers Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {suppliers.map((sup) => (
          <div
            key={sup.id}
            className="bg-white rounded-2xl border border-slate-200 p-5 shadow-2xs flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-[10px] font-bold text-orange-600 uppercase tracking-wider block">
                    {getCategoryLabel(sup.category)}
                  </span>
                  <h3 className="font-extrabold text-base text-slate-900">{sup.name}</h3>
                </div>
                <div className="w-9 h-9 rounded-xl bg-slate-100 flex items-center justify-center text-slate-600">
                  <Building2 className="w-5 h-5" />
                </div>
              </div>

              <div className="space-y-1 text-xs text-slate-600 pt-1">
                <div className="flex items-center gap-2">
                  <span className="text-slate-400 font-medium">{t.suppliers.contactPerson}:</span>
                  <span className="font-semibold text-slate-800">{sup.contactPerson}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="w-3.5 h-3.5 text-slate-400" />
                  <span className="font-mono">{sup.phone}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Mail className="w-3.5 h-3.5 text-slate-400" />
                  <span>{sup.email}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                  <span>{t.suppliers.paymentTerms}: {getTermsLabel(sup.paymentTerms)}</span>
                </div>
              </div>
            </div>

            <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between bg-slate-50 p-2.5 rounded-xl border border-slate-200/80">
              <div>
                <span className="text-[10px] text-slate-500 font-medium block">{t.suppliers.balanceOwed}</span>
                <span className="font-mono font-black text-sm text-rose-600">
                  {settings.currencySymbol} {(sup.balancePayable ?? sup.balanceOwed ?? 0).toFixed(2)}
                </span>
              </div>

              {(sup.balancePayable ?? sup.balanceOwed ?? 0) > 0 ? (
                <button
                  onClick={() => {
                    const bal = sup.balancePayable ?? sup.balanceOwed ?? 0;
                    setPayModalSupplier(sup);
                    setPayAmount(bal);
                  }}
                  className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs flex items-center gap-1 shadow-xs transition-colors"
                >
                  <CreditCard className="w-3.5 h-3.5" />
                  <span>{t.suppliers.makePayment}</span>
                </button>
              ) : (
                <span className="text-[11px] font-bold text-emerald-700 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> {language === 'ar' ? 'مسدد بالكامل' : 'All Settled'}
                </span>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Pay Supplier Modal */}
      {payModalSupplier && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h3 className="font-extrabold text-base text-slate-900">
                {language === 'ar' ? `صرف دفعة مالية للمورد: ${payModalSupplier.name}` : `Disburse Payment to ${payModalSupplier.name}`}
              </h3>
              <button onClick={() => setPayModalSupplier(null)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handlePaySupplier} className="space-y-3.5 text-xs">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200">
                <div className="flex justify-between text-slate-600 mb-1">
                  <span>{language === 'ar' ? 'الرصيد المستحق الحالي:' : 'Current Outstanding Invoice:'}</span>
                  <span className="font-mono font-bold text-rose-600">
                    {settings.currencySymbol} {(payModalSupplier.balancePayable ?? payModalSupplier.balanceOwed ?? 0).toFixed(2)}
                  </span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>{language === 'ar' ? 'حساب الدفع:' : 'Payment Source:'}</span>
                  <span className="font-semibold text-slate-900">
                    {language === 'ar' ? '1020 الحساب البنكي الجاري للمطعم' : '1020 Operating Bank Account'}
                  </span>
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  {language === 'ar' ? `مبلغ السداد (${settings.currencySymbol}):` : `Disbursement Amount (${settings.currencySymbol}):`}
                </label>
                <input
                  type="number"
                  step="0.01"
                  max={payModalSupplier.balancePayable ?? payModalSupplier.balanceOwed ?? 0}
                  value={payAmount}
                  onChange={(e) => setPayAmount(parseFloat(e.target.value) || 0)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-mono text-sm text-end"
                  required
                />
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setPayModalSupplier(null)}
                  className="flex-1 py-2.5 border rounded-xl font-bold text-slate-600"
                >
                  {t.common.cancel}
                </button>
                <button
                  type="submit"
                  className="flex-2 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl font-bold flex items-center justify-center gap-1.5"
                >
                  <span>{language === 'ar' ? 'تأكيد السداد والتحويل' : 'Confirm Wire / Check Disbursement'}</span>
                  <ArrowRight className="w-3.5 h-3.5 rtl:rotate-180" />
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Supplier Modal */}
      {showAddModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 mb-4">
              <h3 className="font-extrabold text-base text-slate-900">{t.suppliers.addSupplier}</h3>
              <button onClick={() => setShowAddModal(false)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateSupplier} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">{t.suppliers.supplierName}:</label>
                <input
                  type="text"
                  placeholder={language === 'ar' ? 'مثال: شركة المراعي الغذائية' : 'e.g. Sonoma Valley Farm Fresh'}
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-start"
                  required
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">{t.suppliers.contactPerson}:</label>
                <input
                  type="text"
                  placeholder={language === 'ar' ? 'مثال: أحمد الشمري' : 'e.g. Marcus Vance'}
                  value={contactPerson}
                  onChange={(e) => setContactPerson(e.target.value)}
                  className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-start"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">{t.suppliers.phone}:</label>
                  <input
                    type="tel"
                    placeholder={language === 'ar' ? '0112345678' : '+1 (555) 000-0000'}
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl font-mono text-start"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">{language === 'ar' ? 'البريد الإلكتروني:' : 'Email:'}</label>
                  <input
                    type="email"
                    placeholder="orders@vendor.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-start"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">{t.suppliers.category}:</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-start"
                  >
                    <option value="Meat & Poultry">{language === 'ar' ? 'اللحوم والدواجن' : 'Meat & Poultry'}</option>
                    <option value="Dairy & Cheese">{language === 'ar' ? 'الألبان والأجبان' : 'Dairy & Cheese'}</option>
                    <option value="Produce">{language === 'ar' ? 'الخضروات والفواكه' : 'Produce'}</option>
                    <option value="Bakery & Flour">{language === 'ar' ? 'المخبوزات والدقيق' : 'Bakery & Flour'}</option>
                    <option value="Beverages & Spirits">{language === 'ar' ? 'المشروبات والقهوة' : 'Beverages & Spirits'}</option>
                  </select>
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">{t.suppliers.paymentTerms}:</label>
                  <select
                    value={paymentTerms}
                    onChange={(e) => setPaymentTerms(e.target.value)}
                    className="w-full p-2 bg-slate-50 border border-slate-200 rounded-xl text-start"
                  >
                    <option value="Net 15">{language === 'ar' ? 'آجل 15 يوم (Net 15)' : 'Net 15'}</option>
                    <option value="Net 30">{language === 'ar' ? 'آجل 30 يوم (Net 30)' : 'Net 30'}</option>
                    <option value="Net 45">{language === 'ar' ? 'آجل 45 يوم (Net 45)' : 'Net 45'}</option>
                    <option value="Cash on Delivery">{language === 'ar' ? 'الدفع عند الاستلام (COD)' : 'Cash on Delivery'}</option>
                  </select>
                </div>
              </div>

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="flex-1 py-2.5 border rounded-xl font-bold text-slate-600"
                >
                  {t.common.cancel}
                </button>
                <button
                  type="submit"
                  className="flex-2 py-2.5 bg-orange-500 hover:bg-orange-600 text-white rounded-xl font-bold"
                >
                  {language === 'ar' ? 'تسجيل المورد' : 'Register Vendor'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
