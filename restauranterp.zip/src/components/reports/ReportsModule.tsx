import React, { useState } from 'react';
import { useRestaurant } from '../../context/RestaurantContext';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
} from 'recharts';
import {
  TrendingUp,
  Download,
  Calendar,
  DollarSign,
  Utensils,
  Award,
  Sparkles,
  PieChart as PieChartIcon,
  BarChart3,
  Layers,
} from 'lucide-react';

export const ReportsModule: React.FC = () => {
  const { orders, menuItems, employees, settings, language, t } = useRestaurant();
  const [timeRange, setTimeRange] = useState<'today' | 'week' | 'month'>('today');

  const getCategoryLabel = (cat: string) => {
    if (language !== 'ar') return cat;
    switch (cat) {
      case 'Mains': return 'الأطباق الرئيسية';
      case 'Starters': return 'المقبلات والشوربات';
      case 'Steaks & Grills': return 'الستيك والمشويات';
      case 'Desserts': return 'الحلويات والمخبوزات';
      case 'Beverages': return 'المشروبات والعصائر';
      case 'Seafood': return 'المأكولات البحرية';
      default: return cat;
    }
  };

  const getRoleLabel = (r: string) => {
    if (language !== 'ar') return r;
    switch (r) {
      case 'Manager': return 'مدير صالة';
      case 'Chef': return 'شيف رئيسي';
      case 'Waiter': return 'مقدم طلبات';
      case 'Cashier': return 'كاشير';
      case 'Bartender': return 'باريستا';
      default: return r;
    }
  };

  const getItemDisplayName = (name: string) => {
    if (language !== 'ar') return name;
    const match = menuItems.find((m) => m.name === name);
    return match?.nameAr || name;
  };

  // Sales by Category
  const categorySalesMap: Record<string, number> = {};
  orders
    .filter((o) => o.status === 'completed' || o.paymentStatus === 'paid')
    .forEach((o) => {
      o.items.forEach((item) => {
        const menuItem = menuItems.find((m) => m.id === item.menuItemId);
        const cat = item.category || menuItem?.category || 'Mains';
        const localizedCat = getCategoryLabel(cat);
        categorySalesMap[localizedCat] = (categorySalesMap[localizedCat] || 0) + item.price * item.quantity;
      });
    });

  const categoryData = Object.entries(categorySalesMap).map(([name, value]) => ({
    name,
    value: parseFloat(value.toFixed(2)),
  }));

  const COLORS = ['#ea580c', '#f59e0b', '#10b981', '#6366f1', '#ec4899', '#8b5cf6'];

  // Top Dishes
  const itemCounts: Record<string, { count: number; revenue: number; originalName: string }> = {};
  orders.forEach((o) => {
    o.items.forEach((item) => {
      if (!itemCounts[item.name]) {
        itemCounts[item.name] = { count: 0, revenue: 0, originalName: item.name };
      }
      itemCounts[item.name].count += item.quantity;
      itemCounts[item.name].revenue += item.price * item.quantity;
    });
  });

  const topDishes = Object.entries(itemCounts)
    .map(([name, data]) => ({
      name: getItemDisplayName(name),
      count: data.count,
      revenue: data.revenue,
    }))
    .sort((a, b) => b.revenue - a.revenue)
    .slice(0, 5);

  // Hourly distribution
  const hourlyData = [
    { hour: language === 'ar' ? '11 ص' : '11 AM', sales: 180, orders: 4 },
    { hour: language === 'ar' ? '12 م' : '12 PM', sales: 480, orders: 12 },
    { hour: language === 'ar' ? '1 م' : '1 PM', sales: 620, orders: 15 },
    { hour: language === 'ar' ? '2 م' : '2 PM', sales: 290, orders: 7 },
    { hour: language === 'ar' ? '5 م' : '5 PM', sales: 340, orders: 8 },
    { hour: language === 'ar' ? '6 م' : '6 PM', sales: 790, orders: 18 },
    { hour: language === 'ar' ? '7 م' : '7 PM', sales: 940, orders: 22 },
    { hour: language === 'ar' ? '8 م' : '8 PM', sales: 860, orders: 19 },
    { hour: language === 'ar' ? '9 م' : '9 PM', sales: 410, orders: 9 },
  ];

  // Export report to CSV
  const handleExportCsv = () => {
    const csvContent =
      'data:text/csv;charset=utf-8,\uFEFF' +
      [
        language === 'ar'
          ? 'رقم_الطلب,النوع,العميل,الموظف,التاريخ,الإجمالي,الحالة'
          : 'OrderNumber,Type,Customer,Server,Date,Total,Status',
      ]
        .concat(
          orders.map(
            (o) =>
              `${o.orderNumber},${o.orderType},"${o.customerName || (language === 'ar' ? 'عميل مباشر' : 'Walk-in')}","${o.serverName}",${o.createdAt},${o.total},${o.status}`
          )
        )
        .join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `RestaurantERP_Report_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getTimeRangeLabel = (r: 'today' | 'week' | 'month') => {
    if (language !== 'ar') return r;
    switch (r) {
      case 'today': return t.reports.today;
      case 'week': return t.reports.thisWeek;
      case 'month': return t.reports.thisMonth;
    }
  };

  return (
    <div className="flex-1 flex flex-col p-4 md:p-6 overflow-y-auto bg-slate-100">
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 mb-6">
        <div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight">
            {t.reports.title}
          </h2>
          <p className="text-xs text-slate-500">
            {t.reports.subtitle}
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Time range switcher */}
          <div className="flex items-center gap-1 bg-white p-1 rounded-xl border border-slate-200 text-xs">
            {(['today', 'week', 'month'] as const).map((r) => (
              <button
                key={r}
                onClick={() => setTimeRange(r)}
                className={`px-3 py-1 rounded-lg font-bold transition-all ${
                  timeRange === r ? 'bg-slate-900 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {getTimeRangeLabel(r)}
              </button>
            ))}
          </div>

          <button
            onClick={handleExportCsv}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs shadow-md shadow-orange-200 transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            <span>{language === 'ar' ? 'تصدير التقرير (CSV)' : 'Export CSV Report'}</span>
          </button>
        </div>
      </div>

      {/* Grid of Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Chart 1: Hourly Sales Trend */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-extrabold text-sm text-slate-900 flex items-center gap-1.5">
                <BarChart3 className="w-4 h-4 text-orange-600" />
                {t.reports.hourlySales}
              </h3>
              <p className="text-[11px] text-slate-400">
                {language === 'ar' ? 'ساعات الذروة التشغيلية وتوزيع الطلبات' : 'Peak dining hours & order distribution'}
              </p>
            </div>
            <span className="text-xs font-mono font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
              {language === 'ar' ? 'الذروة: 7:00 م - 8:00 م' : 'Peak: 7 PM - 8 PM'}
            </span>
          </div>

          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={hourlyData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="hour" tick={{ fontSize: 11, fill: '#64748b' }} axisLine={false} />
                <YAxis
                  tick={{ fontSize: 11, fill: '#64748b' }}
                  axisLine={false}
                  tickFormatter={(val) => `${val}`}
                />
                <Tooltip
                  formatter={(val: any) => [`${settings.currencySymbol} ${val}`, language === 'ar' ? 'إجمالي المبيعات' : 'Gross Revenue']}
                  contentStyle={{
                    borderRadius: 12,
                    fontSize: 12,
                    fontWeight: 'bold',
                    border: '1px solid #e2e8f0',
                    direction: language === 'ar' ? 'rtl' : 'ltr',
                    textAlign: language === 'ar' ? 'right' : 'left',
                  }}
                />
                <Bar dataKey="sales" fill="#ea580c" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Chart 2: Category Mix Breakdown */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-extrabold text-sm text-slate-900 flex items-center gap-1.5">
                <PieChartIcon className="w-4 h-4 text-amber-600" />
                {t.reports.salesByCategory}
              </h3>
              <p className="text-[11px] text-slate-400">
                {language === 'ar' ? 'حصة كل قسم وتصنيف من إجمالي الإيرادات' : 'Share of revenue across departments'}
              </p>
            </div>
          </div>

          <div className="h-64 w-full flex items-center justify-center">
            {categoryData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={categoryData}
                    cx="50%"
                    cy="50%"
                    innerRadius={55}
                    outerRadius={85}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {categoryData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(val: any) => [`${settings.currencySymbol} ${val}`, language === 'ar' ? 'مجموع القسم' : 'Category Total']}
                    contentStyle={{
                      borderRadius: 12,
                      fontSize: 12,
                      fontWeight: 'bold',
                      border: '1px solid #e2e8f0',
                      direction: language === 'ar' ? 'rtl' : 'ltr',
                      textAlign: language === 'ar' ? 'right' : 'left',
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="text-center text-slate-400 text-xs">
                {language === 'ar' ? 'لا توجد بيانات مبيعات بعد' : 'No sales data yet'}
              </div>
            )}
          </div>

          {/* Legend */}
          <div className="flex flex-wrap items-center justify-center gap-3 pt-2 border-t border-slate-100 text-xs">
            {categoryData.map((cat, idx) => (
              <div key={cat.name} className="flex items-center gap-1.5">
                <span
                  className="w-2.5 h-2.5 rounded-full"
                  style={{ backgroundColor: COLORS[idx % COLORS.length] }}
                />
                <span className="text-slate-600 font-medium">
                  {cat.name}: <span className="font-mono font-bold text-slate-900">{settings.currencySymbol} {cat.value}</span>
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Leaderboards */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Dishes */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
          <h3 className="font-extrabold text-sm text-slate-900 mb-3 flex items-center gap-1.5">
            <Utensils className="w-4 h-4 text-emerald-600" />
            {t.reports.topDishes}
          </h3>
          <div className="space-y-2 text-xs">
            {topDishes.map((dish, i) => (
              <div
                key={dish.name}
                className="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl border border-slate-200/70"
              >
                <div className="flex items-center gap-2">
                  <span className="w-5 h-5 rounded-full bg-slate-200 text-slate-700 font-black text-[10px] flex items-center justify-center">
                    {i + 1}
                  </span>
                  <div>
                    <span className="font-bold text-slate-900 block">{dish.name}</span>
                    <span className="text-[10px] text-slate-500 font-mono">
                      {dish.count} {language === 'ar' ? 'طلب منجز' : 'orders fulfilled'}
                    </span>
                  </div>
                </div>
                <span className="font-mono font-extrabold text-slate-900">
                  {settings.currencySymbol} {dish.revenue.toFixed(2)}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Server Leaderboard */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
          <h3 className="font-extrabold text-sm text-slate-900 mb-3 flex items-center gap-1.5">
            <Award className="w-4 h-4 text-indigo-600" />
            {t.reports.serverPerformance}
          </h3>
          <div className="space-y-2 text-xs">
            {[...employees]
              .sort((a, b) => b.totalSalesToday - a.totalSalesToday)
              .map((emp, i) => (
                <div
                  key={emp.id}
                  className="flex items-center justify-between p-2.5 bg-slate-50 rounded-xl border border-slate-200/70"
                >
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-indigo-100 text-indigo-800 font-black text-[10px] flex items-center justify-center">
                      {i + 1}
                    </span>
                    <div>
                      <span className="font-bold text-slate-900 block">{emp.name}</span>
                      <span className="text-[10px] text-slate-500">
                        {getRoleLabel(emp.role)} &bull; {emp.tablesServedToday} {language === 'ar' ? 'طاولة مخدومة' : 'tables served'}
                      </span>
                    </div>
                  </div>
                  <div className="text-end">
                    <span className="font-mono font-black text-slate-900 block">
                      {settings.currencySymbol} {emp.totalSalesToday.toFixed(2)}
                    </span>
                    <span className="text-[10px] text-emerald-700 font-semibold">
                      {emp.isClockedIn || emp.status === 'clocked_in'
                        ? (language === 'ar' ? 'على رأس العمل' : 'On Shift')
                        : (language === 'ar' ? 'غير متواجد' : 'Clocked Out')}
                    </span>
                  </div>
                </div>
              ))}
          </div>
        </div>
      </div>
    </div>
  );
};
