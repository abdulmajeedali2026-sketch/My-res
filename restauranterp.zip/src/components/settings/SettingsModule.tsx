import React, { useState } from 'react';
import { useRestaurant } from '../../context/RestaurantContext';
import {
  Settings,
  Store,
  Receipt,
  Percent,
  RotateCcw,
  CheckCircle2,
  Save,
  AlertTriangle,
  Sparkles,
} from 'lucide-react';

export const SettingsModule: React.FC = () => {
  const { settings, updateSettings, resetAllData, language, setLanguage, t } = useRestaurant();
  const [formData, setFormData] = useState(settings);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [confirmReset, setConfirmReset] = useState<boolean>(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings(formData);
    setFeedback(
      language === 'ar'
        ? 'تم حفظ وتحديث إعدادات نظام المطعم بنجاح.'
        : 'Restaurant ERP configuration updated successfully.'
    );
    setTimeout(() => setFeedback(null), 3000);
  };

  const handleResetData = () => {
    resetAllData();
    setConfirmReset(false);
    setFeedback(
      language === 'ar'
        ? 'تمت استعادة كافة البيانات الأولية للمطعم بنجاح.'
        : 'All records reset to pristine initial ERP sample state.'
    );
    setTimeout(() => setFeedback(null), 3000);
  };

  return (
    <div className="flex-1 flex flex-col p-4 md:p-6 overflow-y-auto bg-slate-100">
      {/* Top Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-xl font-black text-slate-900 tracking-tight">
            {t.settings.title}
          </h2>
          <p className="text-xs text-slate-500">
            {t.settings.subtitle}
          </p>
        </div>
      </div>

      {feedback && (
        <div className="mb-4 p-3 bg-emerald-50 border border-emerald-200 rounded-2xl text-emerald-800 text-xs font-semibold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{feedback}</span>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Form */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 p-6 shadow-2xs">
          <form onSubmit={handleSave} className="space-y-5 text-xs">
            {/* Language Selector */}
            <div>
              <h3 className="font-extrabold text-sm text-slate-900 mb-3 flex items-center gap-2 pb-2 border-b border-slate-100">
                <Sparkles className="w-4 h-4 text-amber-500" />
                <span>{t.settings.language}</span>
              </h3>

              <div className="flex items-center gap-3">
                <button
                  type="button"
                  onClick={() => setLanguage('ar')}
                  className={`flex items-center gap-2 px-4 py-2.5 rounded-xl border font-bold text-xs transition-all ${
                    language === 'ar'
                      ? 'bg-orange-500 text-white border-orange-500 shadow-xs'
                      : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <span className="text-base">🇸🇦</span>
                  <span>العربية (Arabic - RTL)</span>
                </button>

                <button
                  type="button"
                  onClick={() => setLanguage('en')}
                  className={`flex items-center gap-2 px-4 py-2.5 rounded-xl border font-bold text-xs transition-all ${
                    language === 'en'
                      ? 'bg-orange-500 text-white border-orange-500 shadow-xs'
                      : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <span className="text-base">🇺🇸</span>
                  <span>English (LTR)</span>
                </button>
              </div>
            </div>

            {/* Restaurant Profile */}
            <div>
              <h3 className="font-extrabold text-sm text-slate-900 mb-3 flex items-center gap-2 pb-2 border-b border-slate-100">
                <Store className="w-4 h-4 text-orange-600" />
                <span>{t.settings.restaurantProfile}</span>
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">{t.settings.restaurantName}:</label>
                  <input
                    type="text"
                    value={formData.restaurantName}
                    onChange={(e) => setFormData({ ...formData, restaurantName: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-start"
                    required
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">{t.settings.tagline}:</label>
                  <input
                    type="text"
                    value={formData.tagline}
                    onChange={(e) => setFormData({ ...formData, tagline: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-start"
                  />
                </div>

                <div className="md:col-span-2">
                  <label className="font-bold text-slate-700 block mb-1">{t.settings.address}:</label>
                  <input
                    type="text"
                    value={formData.address}
                    onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-start"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">{t.settings.phone}:</label>
                  <input
                    type="text"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono text-start"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">{t.settings.taxNumber}:</label>
                  <input
                    type="text"
                    value={formData.taxRegistrationNumber}
                    onChange={(e) => setFormData({ ...formData, taxRegistrationNumber: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono text-start"
                  />
                </div>
              </div>
            </div>

            {/* Financial & Tax Rules */}
            <div>
              <h3 className="font-extrabold text-sm text-slate-900 mb-3 flex items-center gap-2 pb-2 border-b border-slate-100">
                <Percent className="w-4 h-4 text-emerald-600" />
                <span>{t.settings.taxAndServices}</span>
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">{t.settings.taxRate}:</label>
                  <input
                    type="number"
                    step="0.1"
                    value={formData.taxRatePercent}
                    onChange={(e) =>
                      setFormData({ ...formData, taxRatePercent: parseFloat(e.target.value) || 0 })
                    }
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono text-end"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">{t.settings.serviceCharge}:</label>
                  <input
                    type="number"
                    step="0.1"
                    value={formData.serviceChargePercent}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        serviceChargePercent: parseFloat(e.target.value) || 0,
                      })
                    }
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono text-end"
                  />
                </div>

                <div>
                  <label className="font-bold text-slate-700 block mb-1">{t.settings.currencySymbol}:</label>
                  <input
                    type="text"
                    value={formData.currencySymbol}
                    onChange={(e) => setFormData({ ...formData, currencySymbol: e.target.value })}
                    className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl font-mono text-center font-bold text-base"
                  />
                </div>
              </div>
            </div>

            {/* Receipt Footers */}
            <div>
              <h3 className="font-extrabold text-sm text-slate-900 mb-3 flex items-center gap-2 pb-2 border-b border-slate-100">
                <Receipt className="w-4 h-4 text-indigo-600" />
                <span>{t.settings.receiptFooter}</span>
              </h3>

              <div>
                <label className="font-bold text-slate-700 block mb-1">
                  {language === 'ar' ? 'رسالة الشكر أسفل الفاتورة:' : 'Footer Thank You Message:'}
                </label>
                <input
                  type="text"
                  value={formData.receiptFooterMessage}
                  onChange={(e) => setFormData({ ...formData, receiptFooterMessage: e.target.value })}
                  className="w-full p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-start"
                />
              </div>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="px-6 py-2.5 bg-orange-500 hover:bg-orange-600 text-white font-bold rounded-xl flex items-center gap-2 shadow-md shadow-orange-200 transition-colors"
              >
                <Save className="w-4 h-4" />
                <span>{t.settings.saveSettings}</span>
              </button>
            </div>
          </form>
        </div>

        {/* Right Col: Maintenance & Reset */}
        <div className="space-y-4">
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-2xs">
            <h4 className="font-black text-sm text-slate-900 mb-2">
              {language === 'ar' ? 'نظرة معمارية على النظام' : 'ERP Architecture Overview'}
            </h4>
            <p className="text-xs text-slate-500 leading-relaxed mb-3">
              {language === 'ar'
                ? 'ينفذ النظام الهيكلية المتكاملة المطلوبة بدقة:'
                : 'This system implements the exact architecture requested:'}
            </p>
            <div className="space-y-2 text-xs">
              <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                <span className="font-bold text-slate-900 block">ASP.NET Core Web API</span>
                <span className="text-slate-500 text-[11px]">
                  {language === 'ar'
                    ? 'وحدات تحكم C#، كائنات نقل البيانات DTOs، والخدمات وقواعد البيانات EF Core'
                    : 'C# Controllers, DTOs, Services & EF Core Repositories'}
                </span>
              </div>
              <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                <span className="font-bold text-slate-900 block">Microsoft SQL Server</span>
                <span className="text-slate-500 text-[11px]">
                  {language === 'ar'
                    ? 'جداول علائقية، مفاتيح خارجية، إجراءات مخزنة Stored Procs وإطلالات Views'
                    : 'Relational Tables, Foreign Keys, Stored Procs & Views'}
                </span>
              </div>
              <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                <span className="font-bold text-slate-900 block">Web POS / ERP Single Page App</span>
                <span className="text-slate-500 text-[11px]">
                  {language === 'ar'
                    ? 'جميع الوحدات العشر المطلوبة مع تكامل حي وتزامن فوري بين الشاشات'
                    : 'All 10 user-requested modules with live cross-state integration'}
                </span>
              </div>
            </div>
          </div>

          <div className="bg-rose-50/50 border border-rose-200 rounded-2xl p-5 shadow-2xs">
            <h4 className="font-black text-sm text-rose-900 mb-1 flex items-center gap-1.5">
              <AlertTriangle className="w-4 h-4 text-rose-600" />
              {language === 'ar' ? 'إعادة تعيين بيانات التجربة' : 'Reset Demo Sandbox'}
            </h4>
            <p className="text-xs text-rose-700/80 mb-3">
              {language === 'ar'
                ? 'إعادة ضبط كافة الطلبات والمخزون وقيود المحاسبة وسجلات العملاء إلى الحالة المصنعية الأصلية.'
                : 'Restore all orders, inventory stocks, ledger accounts, and customer loyalty records to pristine factory seed state.'}
            </p>

            {confirmReset ? (
              <div className="space-y-2">
                <p className="text-xs font-bold text-rose-800">
                  {language === 'ar' ? 'هل أنت متأكد؟ سيتم مسح الحركات والطلبات الحديثة.' : 'Are you sure? This will wipe recent live transactions.'}
                </p>
                <div className="flex gap-2">
                  <button
                    onClick={() => setConfirmReset(false)}
                    className="flex-1 py-1.5 bg-white border border-slate-200 text-slate-700 rounded-lg text-xs font-bold"
                  >
                    {t.common.cancel}
                  </button>
                  <button
                    onClick={handleResetData}
                    className="flex-1 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-bold"
                  >
                    {language === 'ar' ? 'تأكيد المسح' : 'Confirm Reset'}
                  </button>
                </div>
              </div>
            ) : (
              <button
                onClick={() => setConfirmReset(true)}
                className="w-full py-2 px-3 bg-white border border-rose-300 hover:bg-rose-100 text-rose-700 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>{t.settings.resetData}</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
