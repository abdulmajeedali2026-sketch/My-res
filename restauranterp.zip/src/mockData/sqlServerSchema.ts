export interface SchemaColumn {
  name: string;
  dataType: string;
  maxLength?: number | null;
  precision?: number | null;
  scale?: number | null;
  isNullable: boolean;
  isPrimaryKey: boolean;
  isForeignKey: boolean;
  refTable?: string;
  refColumn?: string;
}

export interface SchemaTable {
  name: string;
  schema: string;
  module: 'POS & Sales' | 'Kitchen & KDS' | 'Inventory & BOM' | 'Purchasing' | 'Accounting & Cash' | 'CRM & Delivery' | 'System & Security';
  moduleAr: string;
  description: string;
  descriptionAr: string;
  columns: SchemaColumn[];
}

export const sqlServerTables: SchemaTable[] = [
  // POS & Sales
  {
    name: 'Sales',
    schema: 'dbo',
    module: 'POS & Sales',
    moduleAr: 'نقاط البيع والمبيعات',
    description: 'Header table for all restaurant sales invoices across Dine-in, Takeaway and Delivery orders.',
    descriptionAr: 'جدول رأس فواتير المبيعات لكافة الطلبات المحلية والسفري والتوصيل.',
    columns: [
      { name: 'SaleID', dataType: 'bigint', isNullable: false, isPrimaryKey: true, isForeignKey: false },
      { name: 'CompanyID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Companies', refColumn: 'CompanyID' },
      { name: 'BranchID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Branches', refColumn: 'BranchID' },
      { name: 'POSTerminalID', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: true, refTable: 'POSTerminals', refColumn: 'POSTerminalID' },
      { name: 'POSShiftID', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: true, refTable: 'POSShifts', refColumn: 'POSShiftID' },
      { name: 'CustomerID', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: true, refTable: 'Customers', refColumn: 'CustomerID' },
      { name: 'TableID', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: true, refTable: 'RestaurantTables', refColumn: 'TableID' },
      { name: 'InvoiceNo', dataType: 'nvarchar', maxLength: 50, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'SaleDate', dataType: 'datetime2', isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'OrderType', dataType: 'nvarchar', maxLength: 30, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'Status', dataType: 'nvarchar', maxLength: 30, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'SubTotal', dataType: 'decimal', precision: 18, scale: 2, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'DiscountAmount', dataType: 'decimal', precision: 18, scale: 2, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'TaxAmount', dataType: 'decimal', precision: 18, scale: 2, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'TotalAmount', dataType: 'decimal', precision: 18, scale: 2, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'Notes', dataType: 'nvarchar', maxLength: 500, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'CreatedBy', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'CreatedAt', dataType: 'datetime2', isNullable: false, isPrimaryKey: false, isForeignKey: false }
    ]
  },
  {
    name: 'SaleDetails',
    schema: 'dbo',
    module: 'POS & Sales',
    moduleAr: 'نقاط البيع والمبيعات',
    description: 'Line items of sales invoices including item pricing, quantities, discounts, and cost amounts.',
    descriptionAr: 'بنود وتفاصيل الفاتورة من وجبات، كميات، أسعار، خصومات وتكلفة.',
    columns: [
      { name: 'SaleDetailID', dataType: 'bigint', isNullable: false, isPrimaryKey: true, isForeignKey: false },
      { name: 'SaleID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Sales', refColumn: 'SaleID' },
      { name: 'ItemID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Items', refColumn: 'ItemID' },
      { name: 'UnitID', dataType: 'int', isNullable: true, isPrimaryKey: false, isForeignKey: true, refTable: 'Units', refColumn: 'UnitID' },
      { name: 'Quantity', dataType: 'decimal', precision: 18, scale: 6, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'UnitPrice', dataType: 'decimal', precision: 18, scale: 6, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'DiscountAmount', dataType: 'decimal', precision: 18, scale: 2, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'TaxAmount', dataType: 'decimal', precision: 18, scale: 2, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'TotalAmount', dataType: 'decimal', precision: 18, scale: 2, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'CostAmount', dataType: 'decimal', precision: 18, scale: 2, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'Notes', dataType: 'nvarchar', maxLength: 500, isNullable: true, isPrimaryKey: false, isForeignKey: false }
    ]
  },
  {
    name: 'SalePayments',
    schema: 'dbo',
    module: 'POS & Sales',
    moduleAr: 'نقاط البيع والمبيعات',
    description: 'Split or multiple tender payments attached to a sale invoice (Cash, Mada, Visa, etc.).',
    descriptionAr: 'مدفوعات الفاتورة وطرق السداد المتعددة (نقدي، مدى، فيزا، حساب آجل).',
    columns: [
      { name: 'SalePaymentID', dataType: 'bigint', isNullable: false, isPrimaryKey: true, isForeignKey: false },
      { name: 'SaleID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Sales', refColumn: 'SaleID' },
      { name: 'PaymentMethod', dataType: 'nvarchar', maxLength: 30, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'Amount', dataType: 'decimal', precision: 18, scale: 2, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'CashboxID', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: true, refTable: 'Cashboxes', refColumn: 'CashboxID' },
      { name: 'ReferenceNo', dataType: 'nvarchar', maxLength: 100, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'PaymentDate', dataType: 'datetime2', isNullable: false, isPrimaryKey: false, isForeignKey: false }
    ]
  },
  {
    name: 'SaleAddons',
    schema: 'dbo',
    module: 'POS & Sales',
    moduleAr: 'نقاط البيع والمبيعات',
    description: 'Add-on modifiers attached to order items (Extra cheese, sauces, toppings).',
    descriptionAr: 'الإضافات والتعديلات على بنود الطلب (جبنة إضافية، صلصات، نكهات).',
    columns: [
      { name: 'SaleAddonID', dataType: 'bigint', isNullable: false, isPrimaryKey: true, isForeignKey: false },
      { name: 'SaleDetailID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'SaleDetails', refColumn: 'SaleDetailID' },
      { name: 'AddonID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Addons', refColumn: 'AddonID' },
      { name: 'Quantity', dataType: 'decimal', precision: 18, scale: 6, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'UnitPrice', dataType: 'decimal', precision: 18, scale: 6, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'TotalPrice', dataType: 'decimal', precision: 18, scale: 2, isNullable: false, isPrimaryKey: false, isForeignKey: false }
    ]
  },
  {
    name: 'SalesReturns',
    schema: 'dbo',
    module: 'POS & Sales',
    moduleAr: 'نقاط البيع والمبيعات',
    description: 'Sales returns and refund transactions linked to original sales.',
    descriptionAr: 'مردودات المبيعات وسندات الإرجاع المرتبطة بالفواتير الأصلية.',
    columns: [
      { name: 'SalesReturnID', dataType: 'bigint', isNullable: false, isPrimaryKey: true, isForeignKey: false },
      { name: 'OriginalSaleID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Sales', refColumn: 'SaleID' },
      { name: 'BranchID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Branches', refColumn: 'BranchID' },
      { name: 'ReturnNo', dataType: 'nvarchar', maxLength: 50, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'ReturnDate', dataType: 'datetime2', isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'Reason', dataType: 'nvarchar', maxLength: 500, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'TotalAmount', dataType: 'decimal', precision: 18, scale: 2, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'Status', dataType: 'nvarchar', maxLength: 30, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'CreatedBy', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: false }
    ]
  },
  {
    name: 'SalesReturnDetails',
    schema: 'dbo',
    module: 'POS & Sales',
    moduleAr: 'نقاط البيع والمبيعات',
    description: 'Specific line items and quantities returned from a customer.',
    descriptionAr: 'الأصناف والكميات المعادة من الزبون.',
    columns: [
      { name: 'SalesReturnDetailID', dataType: 'bigint', isNullable: false, isPrimaryKey: true, isForeignKey: false },
      { name: 'SalesReturnID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'SalesReturns', refColumn: 'SalesReturnID' },
      { name: 'SaleDetailID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'SaleDetails', refColumn: 'SaleDetailID' },
      { name: 'ItemID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Items', refColumn: 'ItemID' },
      { name: 'Quantity', dataType: 'decimal', precision: 18, scale: 6, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'UnitPrice', dataType: 'decimal', precision: 18, scale: 6, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'TotalAmount', dataType: 'decimal', precision: 18, scale: 2, isNullable: false, isPrimaryKey: false, isForeignKey: false }
    ]
  },
  {
    name: 'POSTerminals',
    schema: 'dbo',
    module: 'POS & Sales',
    moduleAr: 'نقاط البيع والمبيعات',
    description: 'POS hardware machines / stations deployed in dining areas and drive-thrus.',
    descriptionAr: 'محطات وأجهزة نقاط البيع المنتشرة في الصالات والفروع.',
    columns: [
      { name: 'POSTerminalID', dataType: 'bigint', isNullable: false, isPrimaryKey: true, isForeignKey: false },
      { name: 'BranchID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Branches', refColumn: 'BranchID' },
      { name: 'TerminalCode', dataType: 'nvarchar', maxLength: 30, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'TerminalName', dataType: 'nvarchar', maxLength: 100, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'ReceiptPrinterID', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: true, refTable: 'Printers', refColumn: 'PrinterID' },
      { name: 'IsActive', dataType: 'bit', isNullable: false, isPrimaryKey: false, isForeignKey: false }
    ]
  },
  {
    name: 'POSTerminalSettings',
    schema: 'dbo',
    module: 'POS & Sales',
    moduleAr: 'نقاط البيع والمبيعات',
    description: 'Configurable behavior for a POS terminal (default warehouse, cashbox, auto-print, discount limits).',
    descriptionAr: 'خصائص وإعدادات طرفية نقطة البيع (الصندوق الافتراضي، المخزن، الطباعة التلقائية).',
    columns: [
      { name: 'POSTerminalSettingID', dataType: 'bigint', isNullable: false, isPrimaryKey: true, isForeignKey: false },
      { name: 'POSTerminalID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'POSTerminals', refColumn: 'POSTerminalID' },
      { name: 'ReceiptPrinterID', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: true, refTable: 'Printers', refColumn: 'PrinterID' },
      { name: 'DefaultCashboxID', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: true, refTable: 'Cashboxes', refColumn: 'CashboxID' },
      { name: 'DefaultWarehouseID', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: true, refTable: 'Warehouses', refColumn: 'WarehouseID' },
      { name: 'DefaultCustomerID', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: true, refTable: 'Customers', refColumn: 'CustomerID' },
      { name: 'AutoPrintReceipt', dataType: 'bit', isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'AutoPrintKitchen', dataType: 'bit', isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'AllowCreditSales', dataType: 'bit', isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'AllowDiscount', dataType: 'bit', isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'MaxDiscountPercent', dataType: 'decimal', precision: 9, scale: 4, isNullable: false, isPrimaryKey: false, isForeignKey: false }
    ]
  },
  {
    name: 'POSShifts',
    schema: 'dbo',
    module: 'POS & Sales',
    moduleAr: 'نقاط البيع والمبيعات',
    description: 'Cashier shifts tracking opening float, expected vs actual till counts and blind drops.',
    descriptionAr: 'ورديات الكاشير، رصيد الافتتاح، المبيعات وإقفال الدرج الفعلي.',
    columns: [
      { name: 'POSShiftID', dataType: 'bigint', isNullable: false, isPrimaryKey: true, isForeignKey: false },
      { name: 'POSTerminalID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'POSTerminals', refColumn: 'POSTerminalID' },
      { name: 'CashboxID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Cashboxes', refColumn: 'CashboxID' },
      { name: 'UserID', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'OpenedAt', dataType: 'datetime2', isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'ClosedAt', dataType: 'datetime2', isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'OpeningBalance', dataType: 'decimal', precision: 18, scale: 2, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'ExpectedCash', dataType: 'decimal', precision: 18, scale: 2, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'ActualCash', dataType: 'decimal', precision: 18, scale: 2, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'DifferenceAmount', dataType: 'decimal', precision: 18, scale: 2, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'Status', dataType: 'nvarchar', maxLength: 20, isNullable: false, isPrimaryKey: false, isForeignKey: false }
    ]
  },
  {
    name: 'POSShiftTransactions',
    schema: 'dbo',
    module: 'POS & Sales',
    moduleAr: 'نقاط البيع والمبيعات',
    description: 'Pay-ins, payouts, cash drops, and shift movements.',
    descriptionAr: 'حركات الإيداع والسحب والمصروفات النثرية أثناء الوردية.',
    columns: [
      { name: 'POSShiftTransactionID', dataType: 'bigint', isNullable: false, isPrimaryKey: true, isForeignKey: false },
      { name: 'POSShiftID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'POSShifts', refColumn: 'POSShiftID' },
      { name: 'TransactionDate', dataType: 'datetime2', isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'TransactionType', dataType: 'nvarchar', maxLength: 30, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'Amount', dataType: 'decimal', precision: 18, scale: 2, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'PaymentMethod', dataType: 'nvarchar', maxLength: 30, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'ReferenceNumber', dataType: 'nvarchar', maxLength: 100, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'Description', dataType: 'nvarchar', maxLength: 500, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'CreatedBy', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: true, refTable: 'Users', refColumn: 'UserID' },
      { name: 'CreatedAt', dataType: 'datetime2', isNullable: false, isPrimaryKey: false, isForeignKey: false }
    ]
  },

  // Kitchen & KDS
  {
    name: 'Kitchens',
    schema: 'dbo',
    module: 'Kitchen & KDS',
    moduleAr: 'المطبخ وشاشات KDS',
    description: 'Preparation kitchens or production areas within a restaurant branch.',
    descriptionAr: 'مطابخ التحضير ومناطق الطهي داخل الفرع.',
    columns: [
      { name: 'KitchenID', dataType: 'bigint', isNullable: false, isPrimaryKey: true, isForeignKey: false },
      { name: 'BranchID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Branches', refColumn: 'BranchID' },
      { name: 'KitchenCode', dataType: 'nvarchar', maxLength: 30, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'KitchenName', dataType: 'nvarchar', maxLength: 150, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'IsActive', dataType: 'bit', isNullable: false, isPrimaryKey: false, isForeignKey: false }
    ]
  },
  {
    name: 'KitchenStations',
    schema: 'dbo',
    module: 'Kitchen & KDS',
    moduleAr: 'المطبخ وشاشات KDS',
    description: 'Specific prep stations (Grill, Salad, Fryer, Beverage, Bakery, Expediter).',
    descriptionAr: 'محطات التحضير المحددة (مشويات، مقبلات، مقالي، مشروبات، منسق التسليم).',
    columns: [
      { name: 'KitchenStationID', dataType: 'bigint', isNullable: false, isPrimaryKey: true, isForeignKey: false },
      { name: 'KitchenID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Kitchens', refColumn: 'KitchenID' },
      { name: 'StationCode', dataType: 'nvarchar', maxLength: 30, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'StationName', dataType: 'nvarchar', maxLength: 150, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'IsActive', dataType: 'bit', isNullable: false, isPrimaryKey: false, isForeignKey: false }
    ]
  },
  {
    name: 'KitchenOrders',
    schema: 'dbo',
    module: 'Kitchen & KDS',
    moduleAr: 'المطبخ وشاشات KDS',
    description: 'KDS tickets routed to kitchen stations with lifecycle timestamps.',
    descriptionAr: 'تذاكر المطبخ الرقمية الموجهة لمحطات الطهي مع أوقات التجهيز والتسليم.',
    columns: [
      { name: 'KitchenOrderID', dataType: 'bigint', isNullable: false, isPrimaryKey: true, isForeignKey: false },
      { name: 'SaleID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Sales', refColumn: 'SaleID' },
      { name: 'KitchenID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Kitchens', refColumn: 'KitchenID' },
      { name: 'KitchenStationID', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: true, refTable: 'KitchenStations', refColumn: 'KitchenStationID' },
      { name: 'OrderNo', dataType: 'nvarchar', maxLength: 50, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'RevisionNo', dataType: 'int', isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'Status', dataType: 'nvarchar', maxLength: 30, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'SentAt', dataType: 'datetime2', isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'PreparingAt', dataType: 'datetime2', isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'ReadyAt', dataType: 'datetime2', isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'DeliveredAt', dataType: 'datetime2', isNullable: true, isPrimaryKey: false, isForeignKey: false }
    ]
  },
  {
    name: 'KitchenOrderDetails',
    schema: 'dbo',
    module: 'Kitchen & KDS',
    moduleAr: 'المطبخ وشاشات KDS',
    description: 'Food items on the kitchen ticket with special cooking instructions.',
    descriptionAr: 'الأطباق في تذكرة المطبخ مع الملاحظات والتعليمات الخاصة للشيف.',
    columns: [
      { name: 'KitchenOrderDetailID', dataType: 'bigint', isNullable: false, isPrimaryKey: true, isForeignKey: false },
      { name: 'KitchenOrderID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'KitchenOrders', refColumn: 'KitchenOrderID' },
      { name: 'SaleDetailID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'SaleDetails', refColumn: 'SaleDetailID' },
      { name: 'ItemID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Items', refColumn: 'ItemID' },
      { name: 'Quantity', dataType: 'decimal', precision: 18, scale: 6, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'Notes', dataType: 'nvarchar', maxLength: 500, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'IsPrinted', dataType: 'bit', isNullable: false, isPrimaryKey: false, isForeignKey: false }
    ]
  },
  {
    name: 'KitchenOrderStatus',
    schema: 'dbo',
    module: 'Kitchen & KDS',
    moduleAr: 'المطبخ وشاشات KDS',
    description: 'Audit history of ticket status transitions (Queued, Preparing, Ready, Served).',
    descriptionAr: 'سجل تدقيق وتتبع تغير حالات تذكرة المطبخ بدقة.',
    columns: [
      { name: 'KitchenOrderStatusID', dataType: 'bigint', isNullable: false, isPrimaryKey: true, isForeignKey: false },
      { name: 'KitchenOrderID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'KitchenOrders', refColumn: 'KitchenOrderID' },
      { name: 'StatusCode', dataType: 'nvarchar', maxLength: 30, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'StatusDate', dataType: 'datetime2', isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'UserID', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: true, refTable: 'Users', refColumn: 'UserID' },
      { name: 'Notes', dataType: 'nvarchar', maxLength: 500, isNullable: true, isPrimaryKey: false, isForeignKey: false }
    ]
  },
  {
    name: 'Printers',
    schema: 'dbo',
    module: 'Kitchen & KDS',
    moduleAr: 'المطبخ وشاشات KDS',
    description: 'Thermal POS and Kitchen network receipt printers (ESC/POS, LAN, USB).',
    descriptionAr: 'طابعات الفواتير والمطبخ الحرارية المتصلة عبر الشبكة.',
    columns: [
      { name: 'PrinterID', dataType: 'bigint', isNullable: false, isPrimaryKey: true, isForeignKey: false },
      { name: 'BranchID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Branches', refColumn: 'BranchID' },
      { name: 'PrinterCode', dataType: 'nvarchar', maxLength: 30, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'PrinterName', dataType: 'nvarchar', maxLength: 150, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'PrinterType', dataType: 'nvarchar', maxLength: 30, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'ConnectionType', dataType: 'nvarchar', maxLength: 30, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'IPAddress', dataType: 'nvarchar', maxLength: 50, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'Port', dataType: 'int', isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'PaperWidth', dataType: 'int', isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'CopiesCount', dataType: 'int', isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'IsBackup', dataType: 'bit', isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'IsActive', dataType: 'bit', isNullable: false, isPrimaryKey: false, isForeignKey: false }
    ]
  },
  {
    name: 'PrinterRoutes',
    schema: 'dbo',
    module: 'Kitchen & KDS',
    moduleAr: 'المطبخ وشاشات KDS',
    description: 'Routing logic sending items to designated kitchen printers by Category or Department.',
    descriptionAr: 'قواعد توجيه طباعة الأطباق إلى طابعة المطبخ المناسبة حسب القسم.',
    columns: [
      { name: 'PrinterRouteID', dataType: 'bigint', isNullable: false, isPrimaryKey: true, isForeignKey: false },
      { name: 'PrinterID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Printers', refColumn: 'PrinterID' },
      { name: 'DepartmentID', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: true, refTable: 'Departments', refColumn: 'DepartmentID' },
      { name: 'CategoryID', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: true, refTable: 'Categories', refColumn: 'CategoryID' },
      { name: 'ItemID', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: true, refTable: 'Items', refColumn: 'ItemID' },
      { name: 'PriorityNo', dataType: 'int', isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'CopiesCount', dataType: 'int', isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'IsActive', dataType: 'bit', isNullable: false, isPrimaryKey: false, isForeignKey: false }
    ]
  },

  // Inventory & BOM
  {
    name: 'Items',
    schema: 'dbo',
    module: 'Inventory & BOM',
    moduleAr: 'المستودعات والوصفات (BOM)',
    description: 'Catalog of sale dishes, beverage items, raw ingredients, and packaging materials.',
    descriptionAr: 'دليل المنتجات الشامل من أطباق البيع، المواد الأولية، ومواد التعبئة.',
    columns: [
      { name: 'ItemID', dataType: 'bigint', isNullable: false, isPrimaryKey: true, isForeignKey: false },
      { name: 'CompanyID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Companies', refColumn: 'CompanyID' },
      { name: 'DepartmentID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Departments', refColumn: 'DepartmentID' },
      { name: 'CategoryID', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: true, refTable: 'Categories', refColumn: 'CategoryID' },
      { name: 'ItemCode', dataType: 'nvarchar', maxLength: 50, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'Barcode', dataType: 'nvarchar', maxLength: 100, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'ItemName', dataType: 'nvarchar', maxLength: 200, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'ShortName', dataType: 'nvarchar', maxLength: 100, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'ItemType', dataType: 'nvarchar', maxLength: 30, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'ImagePath', dataType: 'nvarchar', maxLength: 500, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'CostPrice', dataType: 'decimal', precision: 18, scale: 6, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'TaxRate', dataType: 'decimal', precision: 9, scale: 4, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'MinStock', dataType: 'decimal', precision: 18, scale: 6, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'MaxStock', dataType: 'decimal', precision: 18, scale: 6, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'DisplayOrder', dataType: 'int', isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'IsActive', dataType: 'bit', isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'CreatedAt', dataType: 'datetime2', isNullable: false, isPrimaryKey: false, isForeignKey: false }
    ]
  },
  {
    name: 'Recipes',
    schema: 'dbo',
    module: 'Inventory & BOM',
    moduleAr: 'المستودعات والوصفات (BOM)',
    description: 'Standard recipe formulas and yield specifications for kitchen dishes.',
    descriptionAr: 'معادلات الطبخ والمقادير القياسية لكل طبق ومخرجات التحضير.',
    columns: [
      { name: 'RecipeID', dataType: 'bigint', isNullable: false, isPrimaryKey: true, isForeignKey: false },
      { name: 'ItemID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Items', refColumn: 'ItemID' },
      { name: 'RecipeName', dataType: 'nvarchar', maxLength: 200, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'VersionNo', dataType: 'int', isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'IsActive', dataType: 'bit', isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'CreatedAt', dataType: 'datetime2', isNullable: false, isPrimaryKey: false, isForeignKey: false }
    ]
  },
  {
    name: 'RecipeDetails',
    schema: 'dbo',
    module: 'Inventory & BOM',
    moduleAr: 'المستودعات والوصفات (BOM)',
    description: 'Ingredient components, portion quantities and waste/shrinkage allowances (BOM).',
    descriptionAr: 'مكونات الطبق من المواد الخام، كميات المقدار، ونسبة الهدر والفاقد.',
    columns: [
      { name: 'RecipeDetailID', dataType: 'bigint', isNullable: false, isPrimaryKey: true, isForeignKey: false },
      { name: 'RecipeID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Recipes', refColumn: 'RecipeID' },
      { name: 'IngredientItemID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Items', refColumn: 'ItemID' },
      { name: 'Quantity', dataType: 'decimal', precision: 18, scale: 6, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'UnitID', dataType: 'int', isNullable: true, isPrimaryKey: false, isForeignKey: true, refTable: 'Units', refColumn: 'UnitID' },
      { name: 'WastePercent', dataType: 'decimal', precision: 9, scale: 4, isNullable: false, isPrimaryKey: false, isForeignKey: false }
    ]
  },
  {
    name: 'Warehouses',
    schema: 'dbo',
    module: 'Inventory & BOM',
    moduleAr: 'المستودعات والوصفات (BOM)',
    description: 'Central and branch storerooms, cold storage, bar stores and dry pantries.',
    descriptionAr: 'المستودعات الرئيسية ومخازن التبريد والجافة في الفروع.',
    columns: [
      { name: 'WarehouseID', dataType: 'bigint', isNullable: false, isPrimaryKey: true, isForeignKey: false },
      { name: 'BranchID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Branches', refColumn: 'BranchID' },
      { name: 'WarehouseCode', dataType: 'nvarchar', maxLength: 30, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'WarehouseName', dataType: 'nvarchar', maxLength: 150, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'IsMain', dataType: 'bit', isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'IsActive', dataType: 'bit', isNullable: false, isPrimaryKey: false, isForeignKey: false }
    ]
  },
  {
    name: 'WarehouseItems',
    schema: 'dbo',
    module: 'Inventory & BOM',
    moduleAr: 'المستودعات والوصفات (BOM)',
    description: 'Real-time on-hand stock quantities and moving weighted average costs per warehouse.',
    descriptionAr: 'الرصيد الفعلي الحالي في المستودع ومتوسط التكلفة المرجح.',
    columns: [
      { name: 'WarehouseItemID', dataType: 'bigint', isNullable: false, isPrimaryKey: true, isForeignKey: false },
      { name: 'WarehouseID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Warehouses', refColumn: 'WarehouseID' },
      { name: 'ItemID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Items', refColumn: 'ItemID' },
      { name: 'Quantity', dataType: 'decimal', precision: 18, scale: 6, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'AverageCost', dataType: 'decimal', precision: 18, scale: 6, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'LastUpdatedAt', dataType: 'datetime2', isNullable: false, isPrimaryKey: false, isForeignKey: false }
    ]
  },
  {
    name: 'InventoryTransactions',
    schema: 'dbo',
    module: 'Inventory & BOM',
    moduleAr: 'المستودعات والوصفات (BOM)',
    description: 'Immutable ledger of stock movements (Sales depletion, Inbound POs, Spoilage, Transfers).',
    descriptionAr: 'سجل حركات المخزون (خصم مبيعات، استلام مشتريات، تالف، تحويلات).',
    columns: [
      { name: 'InventoryTransactionID', dataType: 'bigint', isNullable: false, isPrimaryKey: true, isForeignKey: false },
      { name: 'BranchID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Branches', refColumn: 'BranchID' },
      { name: 'WarehouseID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Warehouses', refColumn: 'WarehouseID' },
      { name: 'TransactionDate', dataType: 'datetime2', isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'TransactionType', dataType: 'nvarchar', maxLength: 30, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'DocumentType', dataType: 'nvarchar', maxLength: 50, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'DocumentID', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'DocumentNo', dataType: 'nvarchar', maxLength: 50, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'UserID', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'Notes', dataType: 'nvarchar', maxLength: 500, isNullable: true, isPrimaryKey: false, isForeignKey: false }
    ]
  },
  {
    name: 'StocktakeSessions',
    schema: 'dbo',
    module: 'Inventory & BOM',
    moduleAr: 'المستودعات والوصفات (BOM)',
    description: 'Periodic physical inventory stocktaking audits and variance reconciliation.',
    descriptionAr: 'جلسات الجرد الدوري الفعلي واكتشاف الفروقات والتسوية.',
    columns: [
      { name: 'StocktakeSessionID', dataType: 'bigint', isNullable: false, isPrimaryKey: true, isForeignKey: false },
      { name: 'CompanyID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Companies', refColumn: 'CompanyID' },
      { name: 'BranchID', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: true, refTable: 'Branches', refColumn: 'BranchID' },
      { name: 'WarehouseID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Warehouses', refColumn: 'WarehouseID' },
      { name: 'StocktakeNumber', dataType: 'nvarchar', maxLength: 100, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'StocktakeDate', dataType: 'datetime2', isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'Status', dataType: 'nvarchar', maxLength: 20, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'Notes', dataType: 'nvarchar', maxLength: 1000, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'CreatedBy', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: true, refTable: 'Users', refColumn: 'UserID' },
      { name: 'CreatedAt', dataType: 'datetime2', isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'ApprovedBy', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: true, refTable: 'Users', refColumn: 'UserID' },
      { name: 'ApprovedAt', dataType: 'datetime2', isNullable: true, isPrimaryKey: false, isForeignKey: false }
    ]
  },

  // Purchasing
  {
    name: 'Suppliers',
    schema: 'dbo',
    module: 'Purchasing',
    moduleAr: 'المشتريات والموردين',
    description: 'Approved vendor catalog, tax numbers, credit limits, and linked AP GL account.',
    descriptionAr: 'دليل الموردين المعتمدين، الأرقام الضريبية، شروط الائتمان وحساب الأستاذ العام.',
    columns: [
      { name: 'SupplierID', dataType: 'bigint', isNullable: false, isPrimaryKey: true, isForeignKey: false },
      { name: 'CompanyID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Companies', refColumn: 'CompanyID' },
      { name: 'SupplierCode', dataType: 'nvarchar', maxLength: 50, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'SupplierName', dataType: 'nvarchar', maxLength: 200, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'Phone', dataType: 'nvarchar', maxLength: 50, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'Address', dataType: 'nvarchar', maxLength: 300, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'TaxNumber', dataType: 'nvarchar', maxLength: 100, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'AccountID', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: true, refTable: 'Accounts', refColumn: 'AccountID' },
      { name: 'CreditLimit', dataType: 'decimal', precision: 18, scale: 2, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'IsActive', dataType: 'bit', isNullable: false, isPrimaryKey: false, isForeignKey: false }
    ]
  },
  {
    name: 'PurchaseInvoices',
    schema: 'dbo',
    module: 'Purchasing',
    moduleAr: 'المشتريات والموردين',
    description: 'Inbound supplier purchase invoices and stock receiving documents.',
    descriptionAr: 'فواتير مشتريات الموردين وسندات استلام الشحنات إلى المستودع.',
    columns: [
      { name: 'PurchaseInvoiceID', dataType: 'bigint', isNullable: false, isPrimaryKey: true, isForeignKey: false },
      { name: 'CompanyID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Companies', refColumn: 'CompanyID' },
      { name: 'BranchID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Branches', refColumn: 'BranchID' },
      { name: 'SupplierID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Suppliers', refColumn: 'SupplierID' },
      { name: 'WarehouseID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Warehouses', refColumn: 'WarehouseID' },
      { name: 'InvoiceNo', dataType: 'nvarchar', maxLength: 50, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'InvoiceDate', dataType: 'datetime2', isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'SubTotal', dataType: 'decimal', precision: 18, scale: 2, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'DiscountAmount', dataType: 'decimal', precision: 18, scale: 2, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'TaxAmount', dataType: 'decimal', precision: 18, scale: 2, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'TotalAmount', dataType: 'decimal', precision: 18, scale: 2, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'Status', dataType: 'nvarchar', maxLength: 30, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'JournalEntryID', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: true, refTable: 'JournalEntries', refColumn: 'JournalEntryID' },
      { name: 'Notes', dataType: 'nvarchar', maxLength: 500, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'CreatedBy', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: false }
    ]
  },
  {
    name: 'PurchaseDetails',
    schema: 'dbo',
    module: 'Purchasing',
    moduleAr: 'المشتريات والموردين',
    description: 'Raw ingredients and items received on a purchase invoice.',
    descriptionAr: 'الأصناف والمواد الأولية المستلمة في فاتورة الشراء وتكلفتها.',
    columns: [
      { name: 'PurchaseDetailID', dataType: 'bigint', isNullable: false, isPrimaryKey: true, isForeignKey: false },
      { name: 'PurchaseInvoiceID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'PurchaseInvoices', refColumn: 'PurchaseInvoiceID' },
      { name: 'ItemID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Items', refColumn: 'ItemID' },
      { name: 'UnitID', dataType: 'int', isNullable: true, isPrimaryKey: false, isForeignKey: true, refTable: 'Units', refColumn: 'UnitID' },
      { name: 'Quantity', dataType: 'decimal', precision: 18, scale: 6, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'UnitCost', dataType: 'decimal', precision: 18, scale: 6, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'DiscountAmount', dataType: 'decimal', precision: 18, scale: 2, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'TaxAmount', dataType: 'decimal', precision: 18, scale: 2, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'TotalAmount', dataType: 'decimal', precision: 18, scale: 2, isNullable: false, isPrimaryKey: false, isForeignKey: false }
    ]
  },
  {
    name: 'SupplierPayments',
    schema: 'dbo',
    module: 'Purchasing',
    moduleAr: 'المشتريات والموردين',
    description: 'Payments disbursed to suppliers against outstanding purchase invoices.',
    descriptionAr: 'سندات صرف دفعات للموردين لتسوية الأرصدة المستحقة.',
    columns: [
      { name: 'SupplierPaymentID', dataType: 'bigint', isNullable: false, isPrimaryKey: true, isForeignKey: false },
      { name: 'SupplierID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Suppliers', refColumn: 'SupplierID' },
      { name: 'BranchID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Branches', refColumn: 'BranchID' },
      { name: 'PaymentDate', dataType: 'datetime2', isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'Amount', dataType: 'decimal', precision: 18, scale: 2, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'CashboxID', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: true, refTable: 'Cashboxes', refColumn: 'CashboxID' },
      { name: 'BankID', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: true, refTable: 'Banks', refColumn: 'BankID' },
      { name: 'ReferenceNo', dataType: 'nvarchar', maxLength: 100, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'JournalEntryID', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: true, refTable: 'JournalEntries', refColumn: 'JournalEntryID' },
      { name: 'Notes', dataType: 'nvarchar', maxLength: 500, isNullable: true, isPrimaryKey: false, isForeignKey: false }
    ]
  },

  // Accounting & Cash
  {
    name: 'Accounts',
    schema: 'dbo',
    module: 'Accounting & Cash',
    moduleAr: 'المحاسبة والشجرة المالية',
    description: 'Multi-level Chart of Accounts tree (Assets, Liabilities, Equity, Revenues, Expenses).',
    descriptionAr: 'شجرة ودليل الحسابات متعدد المستويات (أصول، خصوم، ملكية، إيرادات، مصروفات).',
    columns: [
      { name: 'AccountID', dataType: 'bigint', isNullable: false, isPrimaryKey: true, isForeignKey: false },
      { name: 'CompanyID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Companies', refColumn: 'CompanyID' },
      { name: 'ParentAccountID', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: true, refTable: 'Accounts', refColumn: 'AccountID' },
      { name: 'AccountTypeID', dataType: 'int', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'AccountTypes', refColumn: 'AccountTypeID' },
      { name: 'AccountCode', dataType: 'nvarchar', maxLength: 50, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'AccountName', dataType: 'nvarchar', maxLength: 200, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'LevelNo', dataType: 'int', isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'IsPosting', dataType: 'bit', isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'IsActive', dataType: 'bit', isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'CreatedAt', dataType: 'datetime2', isNullable: false, isPrimaryKey: false, isForeignKey: false }
    ]
  },
  {
    name: 'JournalEntries',
    schema: 'dbo',
    module: 'Accounting & Cash',
    moduleAr: 'المحاسبة والشجرة المالية',
    description: 'General Ledger double-entry transactions generated automatically by POS and operations.',
    descriptionAr: 'القيود اليومية المحاسبية المزدوجة المتولدة تلقائياً من العمليات.',
    columns: [
      { name: 'JournalEntryID', dataType: 'bigint', isNullable: false, isPrimaryKey: true, isForeignKey: false },
      { name: 'CompanyID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Companies', refColumn: 'CompanyID' },
      { name: 'BranchID', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: true, refTable: 'Branches', refColumn: 'BranchID' },
      { name: 'EntryNo', dataType: 'nvarchar', maxLength: 50, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'EntryDate', dataType: 'datetime2', isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'SourceType', dataType: 'nvarchar', maxLength: 50, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'SourceID', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'Description', dataType: 'nvarchar', maxLength: 500, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'Status', dataType: 'nvarchar', maxLength: 30, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'CreatedBy', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'CreatedAt', dataType: 'datetime2', isNullable: false, isPrimaryKey: false, isForeignKey: false }
    ]
  },
  {
    name: 'JournalEntryDetails',
    schema: 'dbo',
    module: 'Accounting & Cash',
    moduleAr: 'المحاسبة والشجرة المالية',
    description: 'Debit and credit lines ensuring zero variance balance in the general ledger.',
    descriptionAr: 'أطراف القيد المزدوج (مدين / دائن) لضمان التوازن المحاسبي.',
    columns: [
      { name: 'JournalEntryDetailID', dataType: 'bigint', isNullable: false, isPrimaryKey: true, isForeignKey: false },
      { name: 'JournalEntryID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'JournalEntries', refColumn: 'JournalEntryID' },
      { name: 'AccountID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Accounts', refColumn: 'AccountID' },
      { name: 'CostCenterID', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: true, refTable: 'CostCenters', refColumn: 'CostCenterID' },
      { name: 'Description', dataType: 'nvarchar', maxLength: 500, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'Debit', dataType: 'decimal', precision: 18, scale: 2, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'Credit', dataType: 'decimal', precision: 18, scale: 2, isNullable: false, isPrimaryKey: false, isForeignKey: false }
    ]
  },
  {
    name: 'Cashboxes',
    schema: 'dbo',
    module: 'Accounting & Cash',
    moduleAr: 'المحاسبة والشجرة المالية',
    description: 'Cash drawers, petty cash vaults and safes assigned to branches and terminals.',
    descriptionAr: 'صناديق النقدية، خزن الفروع وعهد الكاشير.',
    columns: [
      { name: 'CashboxID', dataType: 'bigint', isNullable: false, isPrimaryKey: true, isForeignKey: false },
      { name: 'BranchID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Branches', refColumn: 'BranchID' },
      { name: 'CashboxCode', dataType: 'nvarchar', maxLength: 30, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'CashboxName', dataType: 'nvarchar', maxLength: 100, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'AccountID', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: true, refTable: 'Accounts', refColumn: 'AccountID' },
      { name: 'IsActive', dataType: 'bit', isNullable: false, isPrimaryKey: false, isForeignKey: false }
    ]
  },
  {
    name: 'Expenses',
    schema: 'dbo',
    module: 'Accounting & Cash',
    moduleAr: 'المحاسبة والشجرة المالية',
    description: 'Operating expenses and cash payment vouchers directly linked to GL accounts.',
    descriptionAr: 'المصروفات التشغيلية وسندات الصرف النثري المرتبطة بالحسابات.',
    columns: [
      { name: 'ExpenseID', dataType: 'bigint', isNullable: false, isPrimaryKey: true, isForeignKey: false },
      { name: 'CompanyID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Companies', refColumn: 'CompanyID' },
      { name: 'BranchID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Branches', refColumn: 'BranchID' },
      { name: 'ExpenseDate', dataType: 'datetime2', isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'AccountID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Accounts', refColumn: 'AccountID' },
      { name: 'CostCenterID', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: true, refTable: 'CostCenters', refColumn: 'CostCenterID' },
      { name: 'CashboxID', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: true, refTable: 'Cashboxes', refColumn: 'CashboxID' },
      { name: 'Amount', dataType: 'decimal', precision: 18, scale: 2, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'Description', dataType: 'nvarchar', maxLength: 500, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'JournalEntryID', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: true, refTable: 'JournalEntries', refColumn: 'JournalEntryID' },
      { name: 'CreatedBy', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: false }
    ]
  },

  // CRM & Delivery
  {
    name: 'Customers',
    schema: 'dbo',
    module: 'CRM & Delivery',
    moduleAr: 'العملاء وخدمة التوصيل',
    description: 'Guest master directory, phone, address, credit accounts, and loyalty rewards.',
    descriptionAr: 'قاعدة بيانات العملاء، أرقام الجوال، العناوين، الأرصدة الآجلة ونقاط الولاء.',
    columns: [
      { name: 'CustomerID', dataType: 'bigint', isNullable: false, isPrimaryKey: true, isForeignKey: false },
      { name: 'CompanyID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Companies', refColumn: 'CompanyID' },
      { name: 'CustomerCode', dataType: 'nvarchar', maxLength: 50, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'CustomerName', dataType: 'nvarchar', maxLength: 200, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'Phone', dataType: 'nvarchar', maxLength: 50, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'Address', dataType: 'nvarchar', maxLength: 300, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'AccountID', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: true, refTable: 'Accounts', refColumn: 'AccountID' },
      { name: 'CreditLimit', dataType: 'decimal', precision: 18, scale: 2, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'IsActive', dataType: 'bit', isNullable: false, isPrimaryKey: false, isForeignKey: false }
    ]
  },
  {
    name: 'RestaurantTables',
    schema: 'dbo',
    module: 'CRM & Delivery',
    moduleAr: 'العملاء وخدمة التوصيل',
    description: 'Physical dining tables, seat capacities, dining halls, and occupancy statuses.',
    descriptionAr: 'طاولات الصالة، سعة المقاعد، قاعات الطعام وحالات الإشغال الحية.',
    columns: [
      { name: 'TableID', dataType: 'bigint', isNullable: false, isPrimaryKey: true, isForeignKey: false },
      { name: 'DiningHallID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'DiningHalls', refColumn: 'DiningHallID' },
      { name: 'TableCode', dataType: 'nvarchar', maxLength: 30, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'TableName', dataType: 'nvarchar', maxLength: 100, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'SeatsCount', dataType: 'int', isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'Status', dataType: 'nvarchar', maxLength: 30, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'DisplayOrder', dataType: 'int', isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'IsActive', dataType: 'bit', isNullable: false, isPrimaryKey: false, isForeignKey: false }
    ]
  },
  {
    name: 'DeliveryOrders',
    schema: 'dbo',
    module: 'CRM & Delivery',
    moduleAr: 'العملاء وخدمة التوصيل',
    description: 'Delivery dispatch orders, customer address, assigned driver, zone fees and status.',
    descriptionAr: 'طلبات التوصيل الخارجي، عنوان الزبون، السائق المعين، ورسوم المنطقة.',
    columns: [
      { name: 'DeliveryOrderID', dataType: 'bigint', isNullable: false, isPrimaryKey: true, isForeignKey: false },
      { name: 'SaleID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Sales', refColumn: 'SaleID' },
      { name: 'CustomerID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Customers', refColumn: 'CustomerID' },
      { name: 'DeliveryZoneID', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: true, refTable: 'DeliveryZones', refColumn: 'DeliveryZoneID' },
      { name: 'DeliveryDriverID', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: true, refTable: 'DeliveryDrivers', refColumn: 'DeliveryDriverID' },
      { name: 'Address', dataType: 'nvarchar', maxLength: 500, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'DeliveryFee', dataType: 'decimal', precision: 18, scale: 2, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'Status', dataType: 'nvarchar', maxLength: 30, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'AssignedAt', dataType: 'datetime2', isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'DeliveredAt', dataType: 'datetime2', isNullable: true, isPrimaryKey: false, isForeignKey: false }
    ]
  },

  // System & Security
  {
    name: 'Companies',
    schema: 'dbo',
    module: 'System & Security',
    moduleAr: 'النظام والأمان',
    description: 'Multi-tenant parent company entity, legal registration, tax number and base currency.',
    descriptionAr: 'الشركة المالكة، السجل التجاري، الرقم الضريبي والعملة الأساسية.',
    columns: [
      { name: 'CompanyID', dataType: 'bigint', isNullable: false, isPrimaryKey: true, isForeignKey: false },
      { name: 'CompanyCode', dataType: 'nvarchar', maxLength: 30, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'CompanyName', dataType: 'nvarchar', maxLength: 200, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'Address', dataType: 'nvarchar', maxLength: 300, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'Phone', dataType: 'nvarchar', maxLength: 50, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'Email', dataType: 'nvarchar', maxLength: 150, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'TaxNumber', dataType: 'nvarchar', maxLength: 100, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'CurrencyCode', dataType: 'nvarchar', maxLength: 10, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'LogoPath', dataType: 'nvarchar', maxLength: 500, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'IsActive', dataType: 'bit', isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'CreatedAt', dataType: 'datetime2', isNullable: false, isPrimaryKey: false, isForeignKey: false }
    ]
  },
  {
    name: 'Branches',
    schema: 'dbo',
    module: 'System & Security',
    moduleAr: 'النظام والأمان',
    description: 'Restaurant operating branches, locations, phones, and warehouse links.',
    descriptionAr: 'فروع المطعم التشغيلية ومواقعها الجغرافية وبيانات الاتصال.',
    columns: [
      { name: 'BranchID', dataType: 'bigint', isNullable: false, isPrimaryKey: true, isForeignKey: false },
      { name: 'CompanyID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Companies', refColumn: 'CompanyID' },
      { name: 'BranchCode', dataType: 'nvarchar', maxLength: 30, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'BranchName', dataType: 'nvarchar', maxLength: 200, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'Address', dataType: 'nvarchar', maxLength: 300, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'Phone', dataType: 'nvarchar', maxLength: 50, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'IsActive', dataType: 'bit', isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'CreatedAt', dataType: 'datetime2', isNullable: false, isPrimaryKey: false, isForeignKey: false }
    ]
  },
  {
    name: 'Users',
    schema: 'dbo',
    module: 'System & Security',
    moduleAr: 'النظام والأمان',
    description: 'System operators, managers, cashiers and servers with hashed security credentials.',
    descriptionAr: 'مستخدمو النظام من كاشيرية، مدراء وموظفين مع تشفير كلمات المرور.',
    columns: [
      { name: 'UserID', dataType: 'bigint', isNullable: false, isPrimaryKey: true, isForeignKey: false },
      { name: 'CompanyID', dataType: 'bigint', isNullable: false, isPrimaryKey: false, isForeignKey: true, refTable: 'Companies', refColumn: 'CompanyID' },
      { name: 'Username', dataType: 'nvarchar', maxLength: 100, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'PasswordHash', dataType: 'nvarchar', maxLength: 500, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'FullName', dataType: 'nvarchar', maxLength: 200, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'IsActive', dataType: 'bit', isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'CreatedAt', dataType: 'datetime2', isNullable: false, isPrimaryKey: false, isForeignKey: false }
    ]
  },
  {
    name: 'AuditLogs',
    schema: 'dbo',
    module: 'System & Security',
    moduleAr: 'النظام والأمان',
    description: 'Complete change audit trail logging user actions, old values, new values and IP address.',
    descriptionAr: 'سجل التتبع والرقابة الشامل لكل عمليات التعديل والحذف وتغيير البيانات.',
    columns: [
      { name: 'AuditLogID', dataType: 'bigint', isNullable: false, isPrimaryKey: true, isForeignKey: false },
      { name: 'UserID', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: true, refTable: 'Users', refColumn: 'UserID' },
      { name: 'TableName', dataType: 'nvarchar', maxLength: 128, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'RecordID', dataType: 'bigint', isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'ActionType', dataType: 'nvarchar', maxLength: 30, isNullable: false, isPrimaryKey: false, isForeignKey: false },
      { name: 'OldValues', dataType: 'nvarchar', maxLength: -1, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'NewValues', dataType: 'nvarchar', maxLength: -1, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'IPAddress', dataType: 'nvarchar', maxLength: 50, isNullable: true, isPrimaryKey: false, isForeignKey: false },
      { name: 'CreatedAt', dataType: 'datetime2', isNullable: false, isPrimaryKey: false, isForeignKey: false }
    ]
  }
];

export function generateCreateTableSql(table: SchemaTable): string {
  const colDefs = table.columns.map((c) => {
    let typeStr = c.dataType.toUpperCase();
    if (c.maxLength && c.maxLength > 0) {
      typeStr += `(${c.maxLength})`;
    } else if (c.maxLength === -1) {
      typeStr += `(MAX)`;
    } else if (c.precision && c.scale !== undefined) {
      typeStr += `(${c.precision}, ${c.scale})`;
    }
    const nullStr = c.isNullable ? 'NULL' : 'NOT NULL';
    const pkStr = c.isPrimaryKey ? ' IDENTITY(1,1)' : '';
    return `    [${c.name}] ${typeStr}${pkStr} ${nullStr}`;
  });

  const pks = table.columns.filter((c) => c.isPrimaryKey).map((c) => `[${c.name}]`);
  const pkDef = pks.length > 0 ? `    CONSTRAINT [PK_${table.name}] PRIMARY KEY CLUSTERED (${pks.join(', ')})` : '';

  const fkDefs = table.columns
    .filter((c) => c.isForeignKey && c.refTable && c.refColumn)
    .map(
      (c) =>
        `    CONSTRAINT [FK_${table.name}_${c.refTable}_${c.name}] FOREIGN KEY ([${c.name}]) REFERENCES [dbo].[${c.refTable}] ([${c.refColumn}])`
    );

  const allItems = [...colDefs];
  if (pkDef) allItems.push(pkDef);
  if (fkDefs.length > 0) allItems.push(...fkDefs);

  return `CREATE TABLE [${table.schema}].[${table.name}] (\n${allItems.join(',\n')}\n);`;
}
