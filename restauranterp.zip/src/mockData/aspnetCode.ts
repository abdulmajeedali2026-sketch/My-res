export interface CodeFile {
  name: string;
  category: 'Controllers' | 'Models' | 'DTOs' | 'Services' | 'Repositories' | 'Data' | 'Program';
  path: string;
  language: string;
  description: string;
  content: string;
}

export interface SqlObject {
  name: string;
  type: 'Table' | 'View' | 'Stored Procedure' | 'Function' | 'Foreign Key';
  schema: string;
  description: string;
  sqlDefinition: string;
  columns?: { name: string; type: string; nullable: boolean; isPk?: boolean; isFk?: boolean; ref?: string }[];
}

export const aspNetCodeFiles: CodeFile[] = [
  {
    name: 'Program.cs',
    category: 'Program',
    path: 'Backend/ASP.NET Core Web API/Program.cs',
    language: 'csharp',
    description: 'Application bootstrap, Dependency Injection, CORS, Swagger OpenAPI, and Entity Framework Core DbContext registration.',
    content: `using Microsoft.EntityFrameworkCore;
using RestaurantERP.Data;
using RestaurantERP.Repositories;
using RestaurantERP.Services;
using Serilog;

var builder = WebApplication.CreateBuilder(args);

// 1. Configure Serilog for enterprise structured audit logging
Log.Logger = new LoggerConfiguration()
    .ReadFrom.Configuration(builder.Configuration)
    .Enrich.FromLogContext()
    .WriteTo.Console()
    .CreateLogger();

builder.Host.UseSerilog();

// 2. Add SQL Server Entity Framework Core DbContext
builder.Services.AddDbContext<RestaurantDbContext>(options =>
    options.UseSqlServer(
        builder.Configuration.GetConnectionString("RestaurantERPConnection"),
        sqlOptions => sqlOptions.EnableRetryOnFailure(5, TimeSpan.FromSeconds(10), null)
    ));

// 3. Register Domain Repositories & Business Logic Services (Scoped)
builder.Services.AddScoped<IUnitOfWork, UnitOfWork>();
builder.Services.AddScoped<IPosService, PosService>();
builder.Services.AddScoped<IInventoryService, InventoryService>();
builder.Services.AddScoped<IAccountingService, AccountingService>();
builder.Services.AddScoped<IPurchaseOrderService, PurchaseOrderService>();
builder.Services.AddScoped<IReportingService, ReportingService>();

// 4. API Controllers & JSON Options
builder.Services.AddControllers()
    .AddJsonOptions(opts => opts.JsonSerializerOptions.ReferenceHandler = System.Text.Json.Serialization.ReferenceHandler.IgnoreCycles);

// 5. CORS for Web POS Client
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowWebPos", policy =>
    {
        policy.WithOrigins("https://pos.grandosteria.com", "http://localhost:3000")
              .AllowAnyHeader()
              .AllowAnyMethod()
              .AllowCredentials();
    });
});

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new() { Title = "RestaurantERP API", Version = "v1", Description = "Enterprise Web POS & Operations API" });
});

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseSerilogRequestLogging();
app.UseHttpsRedirection();
app.UseCors("AllowWebPos");
app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.Run();`
  },
  {
    name: 'PosController.cs',
    category: 'Controllers',
    path: 'Backend/ASP.NET Core Web API/Controllers/PosController.cs',
    language: 'csharp',
    description: 'Handles POS order creation, table assignments, payment settlement, and atomic inventory deductions.',
    content: `using Microsoft.AspNetCore.Mvc;
using RestaurantERP.DTOs;
using RestaurantERP.Services;

namespace RestaurantERP.Controllers
{
    [ApiController]
    [Route("api/v1/[controller]")]
    [Produces("application/json")]
    public class PosController : ControllerBase
    {
        private readonly IPosService _posService;
        private readonly ILogger<PosController> _logger;

        public PosController(IPosService posService, ILogger<PosController> logger)
        {
            _posService = posService;
            _logger = logger;
        }

        [HttpGet("tables")]
        public async Task<IActionResult> GetTableLayoutAsync([FromQuery] string? zone)
        {
            var tables = await _posService.GetTablesAsync(zone);
            return Ok(tables);
        }

        [HttpPost("orders")]
        public async Task<IActionResult> CreateOrderAsync([FromBody] CreateOrderDto dto)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            var order = await _posService.CreateOrderAsync(dto);
            _logger.LogInformation("Order {OrderNumber} created by server {ServerId}", order.OrderNumber, dto.ServerId);
            return CreatedAtAction(nameof(GetOrderByIdAsync), new { id = order.Id }, order);
        }

        [HttpGet("orders/{id}")]
        public async Task<IActionResult> GetOrderByIdAsync(Guid id)
        {
            var order = await _posService.GetOrderByIdAsync(id);
            if (order == null) return NotFound(new { message = $"Order {id} not found" });
            return Ok(order);
        }

        [HttpPost("orders/{id}/settle")]
        public async Task<IActionResult> SettlePaymentAsync(Guid id, [FromBody] SettlePaymentDto dto)
        {
            var result = await _posService.SettlePaymentAndDeductInventoryAsync(id, dto);
            if (!result.Success) return BadRequest(new { error = result.ErrorMessage });
            return Ok(result.Receipt);
        }

        [HttpPost("orders/{id}/void")]
        public async Task<IActionResult> VoidOrderAsync(Guid id, [FromBody] VoidOrderDto dto)
        {
            var success = await _posService.VoidOrderAsync(id, dto.Reason, dto.AuthorizedByPin);
            if (!success) return Forbid();
            return NoContent();
        }
    }
}`
  },
  {
    name: 'InventoryService.cs',
    category: 'Services',
    path: 'Backend/ASP.NET Core Web API/Services/InventoryService.cs',
    language: 'csharp',
    description: 'Core logic for atomic Bill of Materials (BOM) deduction on order checkout, batch reorders, and stock variance audits.',
    content: `using Microsoft.EntityFrameworkCore;
using RestaurantERP.Data;
using RestaurantERP.Models;

namespace RestaurantERP.Services
{
    public class InventoryService : IInventoryService
    {
        private readonly RestaurantDbContext _context;
        private readonly ILogger<InventoryService> _logger;

        public InventoryService(RestaurantDbContext context, ILogger<InventoryService> logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task DeductBomForOrderAsync(Guid orderId)
        {
            using var transaction = await _context.Database.BeginTransactionAsync();
            try
            {
                var order = await _context.Orders
                    .Include(o => o.Items)
                        .ThenInclude(i => i.MenuItem)
                            .ThenInclude(m => m.RecipeBoms)
                    .FirstOrDefaultAsync(o => o.Id == orderId);

                if (order == null) throw new KeyNotFoundException($"Order {orderId} not found");

                foreach (var item in order.Items)
                {
                    foreach (var bom in item.MenuItem.RecipeBoms)
                    {
                        var ingredient = await _context.Ingredients
                            .FirstOrDefaultAsync(ing => ing.Id == bom.IngredientId);

                        if (ingredient != null)
                        {
                            var totalDeduction = bom.QuantityRequired * item.Quantity;
                            ingredient.CurrentStock -= totalDeduction;

                            // Record inventory ledger transaction
                            _context.InventoryTransactions.Add(new InventoryTransaction
                            {
                                Id = Guid.NewGuid(),
                                IngredientId = ingredient.Id,
                                QuantityDelta = -totalDeduction,
                                Unit = ingredient.Unit,
                                UnitCost = ingredient.CostPerUnit,
                                Type = "sale_deduction",
                                ReferenceId = order.OrderNumber,
                                Reason = $"POS Order Item: {item.MenuItem.Name} x{item.Quantity}",
                                CreatedAt = DateTime.UtcNow
                            });
                        }
                    }
                }

                await _context.SaveChangesAsync();
                await transaction.CommitAsync();
            }
            catch (Exception ex)
            {
                await transaction.RollbackAsync();
                _logger.LogError(ex, "Failed to deduct BOM for order {OrderId}", orderId);
                throw;
            }
        }
    }
}`
  },
  {
    name: 'Order.cs',
    category: 'Models',
    path: 'Backend/ASP.NET Core Web API/Models/Order.cs',
    language: 'csharp',
    description: 'Entity Framework domain entity for customer orders with table foreign keys, order items, and audit timestamps.',
    content: `using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RestaurantERP.Models
{
    [Table("Orders")]
    public class Order
    {
        [Key]
        public Guid Id { get; set; } = Guid.NewGuid();

        [Required, MaxLength(32)]
        public string OrderNumber { get; set; } = string.Empty;

        [Required, MaxLength(16)]
        public string OrderType { get; set; } = "dine-in"; // dine-in, takeaway, delivery

        public Guid? TableId { get; set; }
        [ForeignKey(nameof(TableId))]
        public virtual RestaurantTable? Table { get; set; }

        public Guid? CustomerId { get; set; }
        [ForeignKey(nameof(CustomerId))]
        public virtual Customer? Customer { get; set; }

        public Guid ServerId { get; set; }
        [ForeignKey(nameof(ServerId))]
        public virtual Employee Server { get; set; } = null!;

        public int GuestCount { get; set; } = 1;

        [Column(TypeName = "decimal(18,2)")]
        public decimal Subtotal { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal TaxAmount { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal ServiceChargeAmount { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal DiscountAmount { get; set; }

        [Column(TypeName = "decimal(18,2)")]
        public decimal Total { get; set; }

        [Required, MaxLength(20)]
        public string Status { get; set; } = "pending";

        [Required, MaxLength(20)]
        public string PaymentStatus { get; set; } = "unpaid";

        [MaxLength(20)]
        public string? PaymentMethod { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
        public DateTime? CompletedAt { get; set; }

        public virtual ICollection<OrderItem> Items { get; set; } = new List<OrderItem>();
    }
}`
  },
  {
    name: 'CreateOrderDto.cs',
    category: 'DTOs',
    path: 'Backend/ASP.NET Core Web API/DTOs/CreateOrderDto.cs',
    language: 'csharp',
    description: 'Strongly-typed contract for incoming POS checkout requests.',
    content: `using System.ComponentModel.DataAnnotations;

namespace RestaurantERP.DTOs
{
    public class CreateOrderDto
    {
        [Required]
        public string OrderType { get; set; } = "dine-in";

        public Guid? TableId { get; set; }
        public Guid? CustomerId { get; set; }

        [Required]
        public Guid ServerId { get; set; }

        [Range(1, 100)]
        public int GuestCount { get; set; } = 1;

        [Required, MinLength(1)]
        public List<CreateOrderItemDto> Items { get; set; } = new();

        public decimal DiscountAmount { get; set; } = 0;
        public string? DiscountReason { get; set; }
    }

    public class CreateOrderItemDto
    {
        [Required]
        public Guid MenuItemId { get; set; }

        [Range(1, 99)]
        public int Quantity { get; set; } = 1;

        public List<string>? Modifiers { get; set; }
        public string? KitchenNotes { get; set; }
    }
}`
  },
  {
    name: 'RestaurantDbContext.cs',
    category: 'Data',
    path: 'Backend/ASP.NET Core Web API/Data/RestaurantDbContext.cs',
    language: 'csharp',
    description: 'Entity Framework Core context defining tables, precision constraints, and composite indexes.',
    content: `using Microsoft.EntityFrameworkCore;
using RestaurantERP.Models;

namespace RestaurantERP.Data
{
    public class RestaurantDbContext : DbContext
    {
        public RestaurantDbContext(DbContextOptions<RestaurantDbContext> options) : base(options) { }

        public DbSet<Order> Orders => Set<Order>();
        public DbSet<OrderItem> OrderItems => Set<OrderItem>();
        public DbSet<MenuItem> MenuItems => Set<MenuItem>();
        public DbSet<Ingredient> Ingredients => Set<Ingredient>();
        public DbSet<RecipeBom> RecipeBoms => Set<RecipeBom>();
        public DbSet<InventoryTransaction> InventoryTransactions => Set<InventoryTransaction>();
        public DbSet<RestaurantTable> Tables => Set<RestaurantTable>();
        public DbSet<Customer> Customers => Set<Customer>();
        public DbSet<Supplier> Suppliers => Set<Supplier>();
        public DbSet<PurchaseOrder> PurchaseOrders => Set<PurchaseOrder>();
        public DbSet<PurchaseOrderItem> PurchaseOrderItems => Set<PurchaseOrderItem>();
        public DbSet<Employee> Employees => Set<Employee>();
        public DbSet<Account> Accounts => Set<Account>();
        public DbSet<JournalEntry> JournalEntries => Set<JournalEntry>();

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Composite Key for Recipe BOM (MenuItemId + IngredientId)
            modelBuilder.Entity<RecipeBom>()
                .HasKey(b => new { b.MenuItemId, b.IngredientId });

            modelBuilder.Entity<Order>()
                .HasIndex(o => o.OrderNumber)
                .IsUnique();

            modelBuilder.Entity<Ingredient>()
                .Property(i => i.CurrentStock)
                .HasPrecision(18, 4);

            modelBuilder.Entity<Ingredient>()
                .Property(i => i.CostPerUnit)
                .HasPrecision(18, 2);
        }
    }
}`
  }
];

export const sqlServerObjects: SqlObject[] = [
  {
    name: 'Orders',
    type: 'Table',
    schema: 'dbo',
    description: 'Primary customer orders table capturing dining orders, table links, pricing, and lifecycle statuses.',
    columns: [
      { name: 'Id', type: 'uniqueidentifier', nullable: false, isPk: true },
      { name: 'OrderNumber', type: 'nvarchar(32)', nullable: false },
      { name: 'OrderType', type: 'nvarchar(16)', nullable: false },
      { name: 'TableId', type: 'uniqueidentifier', nullable: true, isFk: true, ref: 'Tables(Id)' },
      { name: 'CustomerId', type: 'uniqueidentifier', nullable: true, isFk: true, ref: 'Customers(Id)' },
      { name: 'ServerId', type: 'uniqueidentifier', nullable: false, isFk: true, ref: 'Employees(Id)' },
      { name: 'GuestCount', type: 'int', nullable: false },
      { name: 'Subtotal', type: 'decimal(18,2)', nullable: false },
      { name: 'TaxAmount', type: 'decimal(18,2)', nullable: false },
      { name: 'ServiceChargeAmount', type: 'decimal(18,2)', nullable: false },
      { name: 'DiscountAmount', type: 'decimal(18,2)', nullable: false },
      { name: 'Total', type: 'decimal(18,2)', nullable: false },
      { name: 'Status', type: 'nvarchar(20)', nullable: false },
      { name: 'PaymentStatus', type: 'nvarchar(20)', nullable: false },
      { name: 'PaymentMethod', type: 'nvarchar(20)', nullable: true },
      { name: 'CreatedAt', type: 'datetime2', nullable: false },
      { name: 'CompletedAt', type: 'datetime2', nullable: true }
    ],
    sqlDefinition: `CREATE TABLE dbo.Orders (
    Id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID(),
    OrderNumber NVARCHAR(32) NOT NULL,
    OrderType NVARCHAR(16) NOT NULL DEFAULT 'dine-in',
    TableId UNIQUEIDENTIFIER NULL,
    CustomerId UNIQUEIDENTIFIER NULL,
    ServerId UNIQUEIDENTIFIER NOT NULL,
    GuestCount INT NOT NULL DEFAULT 1,
    Subtotal DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    TaxAmount DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    ServiceChargeAmount DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    DiscountAmount DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    Total DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    Status NVARCHAR(20) NOT NULL DEFAULT 'pending',
    PaymentStatus NVARCHAR(20) NOT NULL DEFAULT 'unpaid',
    PaymentMethod NVARCHAR(20) NULL,
    CreatedAt DATETIME2 NOT NULL DEFAULT SYSUTCDATETIME(),
    CompletedAt DATETIME2 NULL,
    CONSTRAINT PK_Orders PRIMARY KEY CLUSTERED (Id),
    CONSTRAINT UQ_Orders_OrderNumber UNIQUE (OrderNumber),
    CONSTRAINT FK_Orders_Tables FOREIGN KEY (TableId) REFERENCES dbo.Tables(Id),
    CONSTRAINT FK_Orders_Customers FOREIGN KEY (CustomerId) REFERENCES dbo.Customers(Id),
    CONSTRAINT FK_Orders_Employees FOREIGN KEY (ServerId) REFERENCES dbo.Employees(Id)
);`
  },
  {
    name: 'Ingredients',
    type: 'Table',
    schema: 'dbo',
    description: 'Raw kitchen ingredients and pantry stock ledger with live inventory tracking and automated reorder points.',
    columns: [
      { name: 'Id', type: 'uniqueidentifier', nullable: false, isPk: true },
      { name: 'Code', type: 'nvarchar(32)', nullable: false },
      { name: 'Name', type: 'nvarchar(128)', nullable: false },
      { name: 'Category', type: 'nvarchar(64)', nullable: false },
      { name: 'CurrentStock', type: 'decimal(18,4)', nullable: false },
      { name: 'Unit', type: 'nvarchar(16)', nullable: false },
      { name: 'ReorderLevel', type: 'decimal(18,4)', nullable: false },
      { name: 'CostPerUnit', type: 'decimal(18,2)', nullable: false },
      { name: 'SupplierId', type: 'uniqueidentifier', nullable: false, isFk: true, ref: 'Suppliers(Id)' },
      { name: 'LastRestocked', type: 'datetime2', nullable: true }
    ],
    sqlDefinition: `CREATE TABLE dbo.Ingredients (
    Id UNIQUEIDENTIFIER NOT NULL DEFAULT NEWSEQUENTIALID(),
    Code NVARCHAR(32) NOT NULL,
    Name NVARCHAR(128) NOT NULL,
    Category NVARCHAR(64) NOT NULL,
    CurrentStock DECIMAL(18,4) NOT NULL DEFAULT 0,
    Unit NVARCHAR(16) NOT NULL,
    ReorderLevel DECIMAL(18,4) NOT NULL DEFAULT 0,
    CostPerUnit DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    SupplierId UNIQUEIDENTIFIER NOT NULL,
    LastRestocked DATETIME2 NULL,
    CONSTRAINT PK_Ingredients PRIMARY KEY CLUSTERED (Id),
    CONSTRAINT UQ_Ingredients_Code UNIQUE (Code),
    CONSTRAINT FK_Ingredients_Suppliers FOREIGN KEY (SupplierId) REFERENCES dbo.Suppliers(Id)
);`
  },
  {
    name: 'RecipeBOM',
    type: 'Table',
    schema: 'dbo',
    description: 'Bill of Materials linking finished dishes to raw ingredient quantities for exact COGS calculation.',
    columns: [
      { name: 'MenuItemId', type: 'uniqueidentifier', nullable: false, isPk: true, isFk: true, ref: 'MenuItems(Id)' },
      { name: 'IngredientId', type: 'uniqueidentifier', nullable: false, isPk: true, isFk: true, ref: 'Ingredients(Id)' },
      { name: 'QuantityRequired', type: 'decimal(18,4)', nullable: false }
    ],
    sqlDefinition: `CREATE TABLE dbo.RecipeBOM (
    MenuItemId UNIQUEIDENTIFIER NOT NULL,
    IngredientId UNIQUEIDENTIFIER NOT NULL,
    QuantityRequired DECIMAL(18,4) NOT NULL,
    CONSTRAINT PK_RecipeBOM PRIMARY KEY CLUSTERED (MenuItemId, IngredientId),
    CONSTRAINT FK_RecipeBOM_MenuItems FOREIGN KEY (MenuItemId) REFERENCES dbo.MenuItems(Id) ON DELETE CASCADE,
    CONSTRAINT FK_RecipeBOM_Ingredients FOREIGN KEY (IngredientId) REFERENCES dbo.Ingredients(Id)
);`
  },
  {
    name: 'sp_ProcessSaleAndDeductInventory',
    type: 'Stored Procedure',
    schema: 'dbo',
    description: 'Transactional procedure that finalizes payment, closes table occupancy, deducts ingredient stocks, and generates journal entries.',
    sqlDefinition: `CREATE PROCEDURE dbo.sp_ProcessSaleAndDeductInventory
    @OrderId UNIQUEIDENTIFIER,
    @PaymentMethod NVARCHAR(20),
    @AmountTendered DECIMAL(18,2),
    @CashierId UNIQUEIDENTIFIER
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    BEGIN TRANSACTION;
    TRY
        -- 1. Validate Order
        DECLARE @OrderTotal DECIMAL(18,2), @TableId UNIQUEIDENTIFIER;
        SELECT @OrderTotal = Total, @TableId = TableId FROM dbo.Orders WHERE Id = @OrderId;

        IF @OrderTotal IS NULL
            THROW 50001, 'Order not found.', 1;

        -- 2. Mark Order as Paid
        UPDATE dbo.Orders
        SET PaymentStatus = 'paid',
            Status = 'completed',
            PaymentMethod = @PaymentMethod,
            CompletedAt = SYSUTCDATETIME()
        WHERE Id = @OrderId;

        -- 3. Release Table if Dine-in
        IF @TableId IS NOT NULL
        BEGIN
            UPDATE dbo.Tables
            SET Status = 'available', CurrentOrderId = NULL, GuestCount = 0
            WHERE Id = @TableId;
        END

        -- 4. Deduct Raw Ingredients based on RecipeBOM
        UPDATE ing
        SET ing.CurrentStock = ing.CurrentStock - (bom.QuantityRequired * oi.Quantity)
        FROM dbo.Ingredients ing
        INNER JOIN dbo.RecipeBOM bom ON ing.Id = bom.IngredientId
        INNER JOIN dbo.OrderItems oi ON bom.MenuItemId = oi.MenuItemId
        WHERE oi.OrderId = @OrderId;

        -- 5. Commit Transaction
        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END;`
  },
  {
    name: 'vw_DailySalesSummary',
    type: 'View',
    schema: 'dbo',
    description: 'Materialized aggregation view for executive reporting and real-time revenue KPIs.',
    sqlDefinition: `CREATE VIEW dbo.vw_DailySalesSummary
AS
SELECT 
    CAST(o.CreatedAt AS DATE) AS SalesDate,
    COUNT(o.Id) AS TotalOrders,
    SUM(o.Subtotal) AS GrossRevenue,
    SUM(o.DiscountAmount) AS TotalDiscounts,
    SUM(o.TaxAmount) AS TotalTax,
    SUM(o.ServiceChargeAmount) AS TotalServiceCharges,
    SUM(o.Total) AS NetRevenue,
    SUM(CASE WHEN o.PaymentMethod = 'cash' THEN o.Total ELSE 0 END) AS CashTotal,
    SUM(CASE WHEN o.PaymentMethod = 'card' THEN o.Total ELSE 0 END) AS CardTotal
FROM dbo.Orders o
WHERE o.PaymentStatus = 'paid'
GROUP BY CAST(o.CreatedAt AS DATE);`
  },
  {
    name: 'vw_FoodCostVariance',
    type: 'View',
    schema: 'dbo',
    description: 'Calculates theoretical food cost vs selling price across active menu items to monitor kitchen margins.',
    sqlDefinition: `CREATE VIEW dbo.vw_FoodCostVariance
AS
SELECT 
    m.Id AS MenuItemId,
    m.Name AS DishName,
    m.Category,
    m.Price AS SellingPrice,
    ISNULL(SUM(bom.QuantityRequired * ing.CostPerUnit), 0) AS CalculatedCost,
    m.Price - ISNULL(SUM(bom.QuantityRequired * ing.CostPerUnit), 0) AS GrossProfitAmount,
    CASE 
        WHEN m.Price > 0 THEN 
            ROUND((ISNULL(SUM(bom.QuantityRequired * ing.CostPerUnit), 0) / m.Price) * 100, 2)
        ELSE 0 
    END AS FoodCostPercentage
FROM dbo.MenuItems m
LEFT JOIN dbo.RecipeBOM bom ON m.Id = bom.MenuItemId
LEFT JOIN dbo.Ingredients ing ON bom.IngredientId = ing.Id
GROUP BY m.Id, m.Name, m.Category, m.Price;`
  }
];
