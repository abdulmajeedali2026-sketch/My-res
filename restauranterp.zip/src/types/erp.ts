export type ErpModule =
  | 'pos'
  | 'sales'
  | 'purchases'
  | 'inventory'
  | 'accounting'
  | 'customers'
  | 'suppliers'
  | 'employees'
  | 'reports'
  | 'settings'
  | 'architecture';

export type OrderType = 'dine-in' | 'takeaway' | 'delivery';
export type OrderStatus = 'pending' | 'preparing' | 'ready' | 'served' | 'completed' | 'voided';
export type PaymentMethod = 'cash' | 'card' | 'mobile_pay' | 'customer_credit';
export type PaymentStatus = 'unpaid' | 'paid' | 'partially_paid' | 'refunded';

export type TableStatus = 'available' | 'occupied' | 'reserved' | 'cleaning';
export type TableZone = 'Main Dining' | 'Patio Terrace' | 'Bar Lounge' | 'Private Dining';

export interface RestaurantTable {
  id: string;
  number: string;
  zone: TableZone;
  capacity: number;
  status: TableStatus;
  currentOrderId?: string;
  guestCount?: number;
  occupiedSince?: string;
}

export interface MenuItemModifier {
  id: string;
  name: string;
  priceDelta: number;
}

export interface MenuItem {
  id: string;
  code: string;
  name: string;
  nameAr?: string;
  category: 'Starters' | 'Steaks & Grills' | 'Pizza & Pasta' | 'Seafood' | 'Desserts' | 'Beverages';
  categoryAr?: string;
  price: number;
  cost: number;
  description: string;
  descriptionAr?: string;
  imageUrl: string;
  inStock: boolean;
  preparationTimeMinutes: number;
  dietary?: ('Vegetarian' | 'Gluten-Free' | 'Chef Special' | 'Spicy')[];
  recipeBom: {
    ingredientId: string;
    quantity: number; // in ingredient's unit
  }[];
}

export interface OrderItem {
  id: string;
  menuItemId: string;
  name: string;
  category?: string;
  price: number;
  cost: number;
  quantity: number;
  selectedModifiers?: string[];
  kitchenNotes?: string;
  isReady?: boolean;
}

export interface Order {
  id: string;
  orderNumber: string;
  orderType: OrderType;
  tableId?: string;
  tableNumber?: string;
  guestCount: number;
  customerName?: string;
  customerId?: string;
  serverName: string;
  serverId: string;
  items: OrderItem[];
  subtotal: number;
  taxAmount: number;
  serviceChargeAmount: number;
  discountAmount: number;
  discountReason?: string;
  total: number;
  status: OrderStatus;
  paymentStatus: PaymentStatus;
  paymentMethod?: PaymentMethod;
  amountTendered?: number;
  changeGiven?: number;
  createdAt: string;
  completedAt?: string;
  kdsStatus: 'queued' | 'cooking' | 'ready' | 'bumped';
}

export interface Ingredient {
  id: string;
  code: string;
  name: string;
  nameAr?: string;
  category: 'Meat & Poultry' | 'Dairy & Cheese' | 'Produce' | 'Dry Goods & Pantry' | 'Beverages & Spirits' | 'Bakery & Dough' | 'Seafood';
  categoryAr?: string;
  currentStock: number;
  unit: 'kg' | 'g' | 'L' | 'ml' | 'pcs' | 'pack';
  unitAr?: string;
  reorderLevel: number;
  costPerUnit: number;
  supplierId: string;
  supplierName: string;
  lastRestocked: string;
}

export interface InventoryTransaction {
  id: string;
  ingredientId: string;
  ingredientName: string;
  type: 'sale_deduction' | 'purchase_receipt' | 'waste_spoilage' | 'manual_adjustment';
  quantityDelta: number;
  unit: string;
  unitCost: number;
  reason: string;
  referenceId?: string; // Order # or PO #
  createdAt: string;
  staffName: string;
}

export interface PurchaseOrderItem {
  ingredientId: string;
  ingredientName: string;
  quantity: number;
  unit: string;
  unitPrice: number;
  totalPrice: number;
}

export interface PurchaseOrder {
  id: string;
  poNumber: string;
  supplierId: string;
  supplierName: string;
  items: PurchaseOrderItem[];
  totalAmount: number;
  status: 'draft' | 'submitted' | 'received' | 'cancelled';
  orderDate: string;
  expectedDeliveryDate: string;
  receivedDate?: string;
  notes?: string;
}

export interface Supplier {
  id: string;
  name: string;
  contactPerson: string;
  email: string;
  phone: string;
  category: string;
  paymentTerms: string;
  balancePayable: number;
  balanceOwed?: number;
  address: string;
}

export interface Customer {
  id: string;
  name: string;
  phone: string;
  email: string;
  tier: 'Bronze' | 'Silver' | 'Gold' | 'Platinum';
  loyaltyPoints: number;
  totalSpent: number;
  visitCount: number;
  creditBalance: number;
  notes?: string;
  joinedDate: string;
}

export interface Employee {
  id: string;
  name: string;
  role: 'Manager' | 'Head Chef' | 'Line Cook' | 'Floor Supervisor' | 'Head Waiter' | 'Waiter' | 'Bartender' | 'Cashier';
  pin: string;
  phone: string;
  email: string;
  hourlyRate: number;
  hourlyWage?: number;
  isClockedIn: boolean;
  status?: 'clocked_in' | 'clocked_out' | 'on_break';
  clockInTime?: string;
  currentShiftStarted?: string;
  totalSalesToday: number;
  tablesServedToday: number;
}

export interface CashRegisterSession {
  id: string;
  date: string;
  openedAt: string;
  closedAt?: string;
  cashierName: string;
  openingFloat: number;
  cashSales: number;
  cashIn: number;
  cashOut: number;
  paidOut?: number;
  expectedCash: number;
  actualCashCounted?: number;
  discrepancy?: number;
  isClosed: boolean;
  notes?: string;
}

export interface Account {
  code: string;
  name: string;
  type: 'Asset' | 'Liability' | 'Equity' | 'Revenue' | 'Expense';
  subCategory: string;
  balance: number;
}

export interface JournalEntryLine {
  accountCode: string;
  accountName: string;
  debit: number;
  credit: number;
}

export interface JournalEntry {
  id: string;
  entryNumber: string;
  date: string;
  description: string;
  referenceType: 'POS_SALE' | 'PURCHASE_ORDER' | 'EXPENSE_VOUCHER' | 'STOCK_ADJUSTMENT' | 'MANUAL';
  referenceId?: string;
  lines: JournalEntryLine[];
  totalDebit: number;
  totalCredit: number;
  createdBy: string;
}

export interface RestaurantSettings {
  restaurantName: string;
  tagline: string;
  address: string;
  phone: string;
  email: string;
  taxRegistrationNumber: string;
  currencySymbol: string;
  currencyCode: string;
  taxRatePercent: number; // e.g., 10%
  serviceChargePercent: number; // e.g., 5%
  enableKdsSound: boolean;
  receiptFooterMessage: string;
  language?: 'ar' | 'en';
}

export interface Currency {
  id: string;
  code: string; // e.g. 'SAR', 'USD', 'EUR', 'AED', 'KWD', 'EGP', 'GBP'
  name: string;
  nameAr: string;
  symbol: string;
  exchangeRate: number; // relative to base currency (base = 1.0)
  isBaseCurrency: boolean;
  decimalPlaces: number;
  isActive: boolean;
}

export type PaymentVoucherType = 'supplier_payment' | 'expense' | 'salary' | 'custody' | 'general';
export type ReceiptVoucherType = 'customer_receipt' | 'revenue' | 'cash_deposit' | 'general';

export interface PaymentVoucher {
  id: string;
  voucherNumber: string;
  date: string;
  voucherType: PaymentVoucherType;
  beneficiaryName: string;
  supplierId?: string;
  expenseAccountCode: string;
  paymentAccountCode: string; // '1010' for cash, '1020' for bank
  currencyCode: string;
  exchangeRate: number;
  amountForeign: number;
  amountBase: number;
  description: string;
  journalEntryId?: string;
  createdBy: string;
  createdAt: string;
  status: 'posted' | 'draft';
}

export interface ReceiptVoucher {
  id: string;
  voucherNumber: string;
  date: string;
  voucherType: ReceiptVoucherType;
  receivedFrom: string;
  customerId?: string;
  receiptAccountCode: string; // '1010' cash, '1020' bank
  creditAccountCode: string; // '4010' sales revenue, '1200' customer receivables, etc.
  currencyCode: string;
  exchangeRate: number;
  amountForeign: number;
  amountBase: number;
  description: string;
  journalEntryId?: string;
  createdBy: string;
  createdAt: string;
  status: 'posted' | 'draft';
}

export interface StockVoucherItem {
  ingredientId: string;
  ingredientName: string;
  unit: string;
  quantity: number;
  unitCost: number;
  totalCost: number;
}

export interface StockVoucher {
  id: string;
  voucherNumber: string;
  date: string;
  type: 'receipt' | 'issue'; // receipt = سند استلام / توريد, issue = سند صرف للمطبخ
  departmentOrKitchen: string;
  referenceNumber?: string;
  items: StockVoucherItem[];
  totalAmount: number;
  reason: string;
  issuedBy: string;
  receivedBy: string;
  createdAt: string;
}

