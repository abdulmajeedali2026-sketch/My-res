/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { RestaurantProvider, useRestaurant } from './context/RestaurantContext';
import { Header } from './components/layout/Header';
import { Sidebar } from './components/layout/Sidebar';
import { PosModule } from './components/pos/PosModule';
import { SalesModule } from './components/sales/SalesModule';
import { PurchasesModule } from './components/purchases/PurchasesModule';
import { InventoryModule } from './components/inventory/InventoryModule';
import { AccountingModule } from './components/accounting/AccountingModule';
import { CustomersModule } from './components/customers/CustomersModule';
import { SuppliersModule } from './components/suppliers/SuppliersModule';
import { EmployeesModule } from './components/employees/EmployeesModule';
import { ReportsModule } from './components/reports/ReportsModule';
import { SettingsModule } from './components/settings/SettingsModule';
import { ArchitectureModule } from './components/architecture/ArchitectureModule';
import { KdsModal } from './components/pos/KdsModal';
import { RegisterModal } from './components/layout/RegisterModal';
import { ErpModule } from './types/erp';

const AppContent: React.FC = () => {
  const { activeModule, language } = useRestaurant();
  const [isKdsOpen, setIsKdsOpen] = useState<boolean>(false);
  const [isRegisterOpen, setIsRegisterOpen] = useState<boolean>(false);

  const renderModule = () => {
    switch (activeModule) {
      case 'pos':
        return <PosModule />;
      case 'sales':
        return <SalesModule />;
      case 'purchases':
        return <PurchasesModule />;
      case 'inventory':
        return <InventoryModule />;
      case 'accounting':
        return <AccountingModule />;
      case 'customers':
        return <CustomersModule />;
      case 'suppliers':
        return <SuppliersModule />;
      case 'employees':
        return <EmployeesModule />;
      case 'reports':
        return <ReportsModule />;
      case 'settings':
        return <SettingsModule />;
      case 'architecture':
        return <ArchitectureModule />;
      default:
        return <PosModule />;
    }
  };

  return (
    <div
      dir={language === 'ar' ? 'rtl' : 'ltr'}
      className="flex h-screen w-screen overflow-hidden bg-slate-900 font-sans select-none antialiased"
    >
      {/* Sidebar Navigation */}
      <Sidebar onOpenKds={() => setIsKdsOpen(true)} />

      {/* Main App Canvas */}
      <div className="flex-1 flex flex-col h-screen overflow-hidden">
        {/* Top Header Bar */}
        <Header
          onOpenKds={() => setIsKdsOpen(true)}
          onOpenRegister={() => setIsRegisterOpen(true)}
        />

        {/* Dynamic Content Module */}
        <main className="flex-1 flex overflow-hidden relative">
          {renderModule()}
        </main>
      </div>

      {/* Global Kitchen Display System Modal */}
      <KdsModal isOpen={isKdsOpen} onClose={() => setIsKdsOpen(false)} />

      {/* Global Cash Register Float & End-of-Day Reconciliation Modal */}
      <RegisterModal isOpen={isRegisterOpen} onClose={() => setIsRegisterOpen(false)} />
    </div>
  );
};

export default function App() {
  return (
    <RestaurantProvider>
      <AppContent />
    </RestaurantProvider>
  );
}
